// loader.js
(function(){
  (function ensureVersionCheckScript(){
    if(document.querySelector('script[data-wp-version-check="1"]')) return;
    const script = document.createElement('script');
    script.src = '/version-check.js?v=' + Date.now();
    script.defer = true;
    script.dataset.wpVersionCheck = '1';
    document.head.appendChild(script);
  })();

  var PAGE_APP_MODES_CACHE_KEY = "wp_page_app_modes_v1";
  var pageAppModesCache = null;

  function getCurrentPath() {
    try {
      return (window.location && window.location.pathname) || "/";
    } catch (err) {
      return "/";
    }
  }

  function hasNativeStandaloneDisplayMode() {
    return !!(window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true;
  }

  function getDeclaredAppScope() {
    try {
      var meta = document.querySelector('meta[name="wp-app-scope"]');
      var scope = meta ? String(meta.getAttribute("content") || "").trim().toLowerCase() : "";
      return scope === "admin" ? "admin" : "main";
    } catch (err) {
      return "main";
    }
  }

  function getExpectedAppSource() {
    return getDeclaredAppScope() === "admin" ? "admin-app" : "pwa";
  }

  function getActiveAppSource() {
    try {
      var source = (new URL(window.location.href).searchParams.get("source") || "").toLowerCase();
      if (source === "pwa" || source === "admin-app") {
        return source;
      }
    } catch (err) {
      // ignore URL parsing issues
    }

    if (hasNativeStandaloneDisplayMode()) {
      return getExpectedAppSource();
    }

    return "";
  }

  function getCurrentPageAppKey() {
    var path = getCurrentPath().toLowerCase();
    if (path === "/" || path === "/index.html") return "landing";
    if (path === "/main.html") return "main";
    if (path === "/song_view.html") return "song";
    if (path === "/favorites.html") return "favorites";
    if (path === "/setlists.html" || path === "/setlist_view.html" || path === "/setlist_public.html") return "setlists";
    if (path === "/account.html") return "account";
    if (path === "/news.html") return "news";
    if (
      path === "/loginuser.php" ||
      path === "/registeruser.php" ||
      path === "/forgot_password.php" ||
      path === "/forgot_password_sent.php" ||
      path === "/reset_password.php" ||
      path === "/verify_email_confirm.php"
    ) {
      return "auth";
    }
    return "";
  }

  function normalizePageAppModes(raw) {
    if (!raw || typeof raw !== "object") return null;
    var keys = ["landing", "main", "song", "favorites", "setlists", "account", "news", "auth"];
    var normalized = {};
    var hasAny = false;
    keys.forEach(function(key) {
      if (Object.prototype.hasOwnProperty.call(raw, key)) {
        normalized[key] = !!raw[key];
        hasAny = true;
      }
    });
    return hasAny ? normalized : null;
  }

  function readStoredPageAppModes() {
    if (pageAppModesCache !== null) {
      return pageAppModesCache;
    }

    try {
      var raw = window.localStorage.getItem(PAGE_APP_MODES_CACHE_KEY);
      pageAppModesCache = normalizePageAppModes(raw ? JSON.parse(raw) : null);
    } catch (err) {
      pageAppModesCache = null;
    }

    return pageAppModesCache;
  }

  function persistPageAppModes(raw) {
    var normalized = normalizePageAppModes(raw);
    if (!normalized) return;
    pageAppModesCache = normalized;
    try {
      window.localStorage.setItem(PAGE_APP_MODES_CACHE_KEY, JSON.stringify(normalized));
    } catch (err) {
      // ignore storage issues
    }
  }

  function refreshPageAppModesFromManifest() {
    try {
      fetch("/version_manifest.php", { credentials: "same-origin", cache: "no-store" })
        .then(function(response) {
          if (!response.ok) throw new Error("manifest");
          return response.json();
        })
        .then(function(payload) {
          persistPageAppModes(payload && payload.page_app_modes ? payload.page_app_modes : null);
          if (!isPageAppEnabled()) {
            syncManifestForPageMode();
          }
        })
        .catch(function() {
          // ignore manifest read issues
        });
    } catch (err) {
      // ignore fetch support issues
    }
  }

  function isStandaloneAppMode() {
    if (!isPageAppEnabled()) {
      return false;
    }
    return getActiveAppSource() !== "";
  }

  function getPageAppModeSetting() {
    try {
      var meta = document.querySelector('meta[name="wp-app-enabled"]');
      if (meta) {
        return String(meta.getAttribute("content") || "").trim().toLowerCase();
      }
    } catch (err) {
      // ignore meta issues
    }

    var storedModes = readStoredPageAppModes();
    var pageKey = getCurrentPageAppKey();
    if (storedModes && pageKey && Object.prototype.hasOwnProperty.call(storedModes, pageKey)) {
      return storedModes[pageKey] ? "on" : "off";
    }

    return "";
  }

  function isPageAppEnabled() {
    var mode = getPageAppModeSetting();
    return mode !== "off" && mode !== "false" && mode !== "0" && mode !== "disabled";
  }

  function syncManifestForPageMode() {
    if (isPageAppEnabled()) return;
    try {
      document.querySelectorAll('link[rel="manifest"]').forEach(function(link) {
        link.setAttribute('data-wp-manifest-disabled', '1');
        link.removeAttribute('href');
      });
    } catch (err) {
      // ignore manifest adjustments
    }
  }

  function isAuthProgramPage() {
    var path = getCurrentPath();
    return path === "/loginuser.php" ||
      path === "/registeruser.php" ||
      path === "/forgot_password.php" ||
      path === "/forgot_password_sent.php" ||
      path === "/reset_password.php" ||
      path === "/verify_email_confirm.php";
  }

  function getFloatingOverlayBottomOffset() {
    var safeArea = 16;
    try {
      safeArea = Math.max(16, parseInt(getComputedStyle(document.body).paddingBottom || "16", 10) || 16);
    } catch (err) {}

    var dock = document.getElementById("wpAppDock");
    if (!dock) return safeArea;

    var rect = dock.getBoundingClientRect();
    if (!rect || !rect.height) return safeArea;

    return Math.max(safeArea, Math.round(window.innerHeight - rect.top + 12));
  }

  function isLikelyPhoneBrowser() {
    try {
      var ua = window.navigator.userAgent || "";
      var isPhoneUa = /iphone|ipod|android.+mobile|windows phone/i.test(ua);
      if (!isPhoneUa) return false;
      if (window.matchMedia && !window.matchMedia("(max-width: 900px)").matches) return false;
      return true;
    } catch (err) {
      return false;
    }
  }

  function ensureStandaloneAppChrome() {
    if (!isStandaloneAppMode()) return;

    var apply = function() {
      if (!document.body) return;

      document.documentElement.classList.add("wp-standalone-app");
      document.body.classList.add("wp-standalone-app", "wp-main-app");
      document.body.dataset.wpAppScope = "main";

      if (!document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]')) {
        var statusMeta = document.createElement("meta");
        statusMeta.name = "apple-mobile-web-app-status-bar-style";
        statusMeta.content = "black-translucent";
        document.head.appendChild(statusMeta);
      }

      var themeMeta = document.querySelector('meta[name="theme-color"]');
      if (themeMeta) {
        themeMeta.setAttribute("content", "#070910");
      }

      if (document.getElementById("wpStandaloneChromeStyles")) return;
      var style = document.createElement("style");
      style.id = "wpStandaloneChromeStyles";
      style.textContent =
        "html.wp-standalone-app{background:#05070d;color-scheme:dark}" +
        "body.wp-standalone-app{min-height:100svh;padding-top:max(10px,env(safe-area-inset-top));padding-right:max(10px,env(safe-area-inset-right));padding-bottom:max(18px,env(safe-area-inset-bottom));padding-left:max(10px,env(safe-area-inset-left));background:radial-gradient(circle at top left,rgba(107,124,255,.18),transparent 28%),radial-gradient(circle at top right,rgba(87,214,195,.14),transparent 24%),linear-gradient(180deg,#05070d 0%,#0b1020 100%);overscroll-behavior-y:contain}" +
        "body.wp-standalone-app::before{content:'';position:fixed;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(255,255,255,.03),transparent 22%),radial-gradient(circle at 20% 0%,rgba(255,255,255,.05),transparent 24%);z-index:0}" +
        "body.wp-standalone-app>*{position:relative;z-index:1}" +
        "body.wp-standalone-app .container,body.wp-standalone-app .shell,body.wp-standalone-app .auth-shell,body.wp-standalone-app .card,body.wp-standalone-app main{max-width:min(1480px,calc(100vw - 2px));margin-inline:auto}" +
        "body.wp-standalone-app .header,body.wp-standalone-app .search-card,body.wp-standalone-app .table-card,body.wp-standalone-app .theme-btn,body.wp-standalone-app .link-modern,body.wp-standalone-app .table-header{backdrop-filter:blur(20px) saturate(140%)}" +
        "body.wp-standalone-app .header{border:1px solid rgba(255,255,255,.07);border-radius:24px;box-shadow:0 20px 44px rgba(0,0,0,.28);background:rgba(11,16,32,.28)}" +
        "body.wp-standalone-app .section{padding-bottom:max(28px,env(safe-area-inset-bottom))}" +
        "body.wp-standalone-app #wpInstallBanner,body.wp-standalone-app .wp-install{display:none!important}" +
        "@media (max-width:720px){body.wp-standalone-app{padding-top:max(8px,env(safe-area-inset-top));padding-right:max(8px,env(safe-area-inset-right));padding-bottom:max(16px,env(safe-area-inset-bottom));padding-left:max(8px,env(safe-area-inset-left))}body.wp-standalone-app .header{border-radius:18px}}";
      document.head.appendChild(style);
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", apply, { once: true });
    } else {
      apply();
    }
  }

  syncManifestForPageMode();
  refreshPageAppModesFromManifest();
  ensureStandaloneAppChrome();

  function writeAppContextCookie(value) {
    try {
      if (!value) {
        document.cookie = "wp_app_context=; path=/; max-age=0; SameSite=Lax";
        return;
      }
      document.cookie = "wp_app_context=" + encodeURIComponent(value) + "; path=/; max-age=" + (7 * 24 * 60 * 60) + "; SameSite=Lax";
    } catch (err) {
      // ignore cookie errors
    }
  }

  function syncAppContextCookie() {
    writeAppContextCookie(getActiveAppSource());
  }

  syncAppContextCookie();

  if (isStandaloneAppMode()) {
    writeAppContextCookie(getActiveAppSource());
  }

  function getStandalonePageMeta() {
    var path = (window.location.pathname || "/").toLowerCase();
    if (path === "/" || path === "/index.html") {
      return {
        key: "landing",
        title: "Worship ծրագիր",
        subtitle: "Արագ մուտք երգերի գրադարան",
      };
    }
    if (path === "/main.html") {
      return {
        key: "songs",
        title: "Երգերի գրադարան",
        subtitle: "Որոնում, բառեր, ակորդներ և օֆֆլայն աշխատանք",
      };
    }
    if (path === "/favorites.html") {
      return {
        key: "favorites",
        title: "Պահպանված երգեր",
        subtitle: "Արագ մուտք քո ընտրված երգերին",
      };
    }
    if (path === "/setlists.html" || path === "/setlist_view.html" || path === "/setlist_public.html") {
      return {
        key: "setlists",
        title: "Սեթլիստներ",
        subtitle: "Ծառայության երգացանկ և աշխատանքային հերթականություն",
      };
    }
    if (path === "/account.html") {
      return {
        key: "account",
        title: "Իմ հաշիվը",
        subtitle: "Կարգավորումներ, push և պրոֆիլ",
      };
    }
    if (
      path === "/loginuser.php" ||
      path === "/registeruser.php" ||
      path === "/forgot_password.php" ||
      path === "/forgot_password_sent.php" ||
      path === "/reset_password.php" ||
      path === "/verify_email_confirm.php"
    ) {
      return {
        key: "account",
        title: "Մուտք և հաշիվ",
        subtitle: "Ծրագրային մուտք, գրանցում և հաշվի վերականգնում",
      };
    }
    if (path === "/song_view.html") {
      return {
        key: "song",
        title: "Երգի դիտում",
        subtitle: "Ակորդներ, transpose և պահպանում",
      };
    }
    if (path === "/news.html") {
      return {
        key: "news",
        title: "Նորություններ",
        subtitle: "Վերջին հայտարարություններն ու թարմացումները",
      };
    }
    return {
      key: "app",
      title: "Worship ծրագիր",
      subtitle: "Արագ և հարմար worship աշխատանքային տարածք",
    };
  }

  function redirectStandaloneLandingToAppHome() {
    if (!isStandaloneAppMode()) return;
    var path = (window.location.pathname || "/").toLowerCase();
    if (path !== "/" && path !== "/index.html") return;
    try {
      var target = new URL("/main.html", window.location.origin);
      target.searchParams.set("source", "pwa");
      if (window.location.href !== target.toString()) {
        window.location.replace(target.toString());
      }
    } catch (err) {
      // ignore redirect errors
    }
  }

  function preserveStandaloneNavigationContext() {
    if (!isStandaloneAppMode()) return;

    function buildAppUrl(rawUrl) {
      var source = getActiveAppSource() || getExpectedAppSource();
      if (!source || !rawUrl) return null;
      try {
        var url = new URL(rawUrl, window.location.href);
        if (url.origin !== window.location.origin) return null;
        url.searchParams.set("source", source);
        return url;
      } catch (err) {
        return null;
      }
    }

    document.addEventListener("click", function(event) {
      var anchor = event.target && event.target.closest ? event.target.closest("a[href]") : null;
      if (!anchor) return;
      if (anchor.hasAttribute("download")) return;
      if ((anchor.getAttribute("target") || "").toLowerCase() === "_blank") return;

      var href = anchor.getAttribute("href") || "";
      if (!href || href.charAt(0) === "#" || /^(mailto:|tel:|javascript:)/i.test(href)) return;

      var nextUrl = buildAppUrl(href);
      if (!nextUrl) return;
      anchor.href = nextUrl.toString();
    }, true);

    document.addEventListener("submit", function(event) {
      var form = event.target;
      if (!form || !form.tagName || form.tagName.toLowerCase() !== "form") return;

      var nextUrl = buildAppUrl(form.getAttribute("action") || window.location.href);
      var source = getActiveAppSource() || getExpectedAppSource();
      if (!nextUrl || !source) return;

      form.setAttribute("action", nextUrl.toString());

      var hidden = form.querySelector('input[name="source"]');
      if (!hidden) {
        hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "source";
        form.appendChild(hidden);
      }
      hidden.value = source;
    }, true);
  }

  window.WP = window.WP || {};
  window.WP.withAppSource = function(rawUrl) {
    var source = getActiveAppSource();
    if (!source || !rawUrl) return rawUrl;
    try {
      var url = new URL(rawUrl, window.location.href);
      if (url.origin !== window.location.origin) return rawUrl;
      url.searchParams.set("source", source);
      return url.toString();
    } catch (err) {
      return rawUrl;
    }
  };

  function ensureStandaloneAppInterface() {
    if (!isStandaloneAppMode()) return;

    var apply = function() {
      if (!document.body) return;

      var pageMeta = getStandalonePageMeta();
      document.body.dataset.wpAppPage = pageMeta.key;

      if (!document.getElementById("wpStandaloneAppUiStyles")) {
        var style = document.createElement("style");
        style.id = "wpStandaloneAppUiStyles";
        style.textContent =
          "body.wp-main-app nav:not(#wpAppDock){display:none!important}" +
          "body.wp-main-app #menu,body.wp-main-app .hamburger{display:none!important}" +
          "body.wp-main-app footer.worship-footer{display:none!important}" +
          "body.wp-main-app .container>br{display:none!important}" +
          "body.wp-main-app .container{padding-bottom:122px}" +
          "body.wp-main-app #wpAppPagebar{display:flex;align-items:center;justify-content:space-between;gap:18px;margin:0 auto 18px;max-width:min(1480px,calc(100vw - 2px));padding:20px 22px;border:1px solid rgba(255,255,255,.08);border-radius:28px;background:linear-gradient(180deg,rgba(10,16,32,.74),rgba(10,16,32,.54));box-shadow:0 24px 60px rgba(0,0,0,.26)}" +
          "body.wp-main-app .wp-app-pagebar-copy{display:flex;flex-direction:column;gap:6px;min-width:0}" +
          "body.wp-main-app .wp-app-pagebar-kicker{font:800 12px/1.1 Inter,system-ui,sans-serif;letter-spacing:.18em;text-transform:uppercase;color:#8ea1ff}" +
          "body.wp-main-app .wp-app-pagebar-title{font:800 clamp(22px,3vw,30px)/1.05 Inter,system-ui,sans-serif;color:#eef3ff;letter-spacing:-.03em}" +
          "body.wp-main-app .wp-app-pagebar-subtitle{font:600 13px/1.45 Inter,system-ui,sans-serif;color:#9aa7bf;max-width:560px}" +
          "body.wp-main-app .wp-app-pagebar-side{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end}" +
          "body.wp-main-app .wp-app-chip{display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:#eef3ff;font:700 12px/1 Inter,system-ui,sans-serif;white-space:nowrap}" +
          "body.wp-main-app .wp-app-chip.status-online{background:rgba(96,211,148,.14);color:#bff0cf;border-color:rgba(96,211,148,.24)}" +
          "body.wp-main-app .wp-app-chip.status-offline{background:rgba(255,107,122,.14);color:#ffd4da;border-color:rgba(255,107,122,.24)}" +
          "body.wp-main-app #wpAppDock{position:fixed;top:auto;right:auto;left:50%;bottom:max(16px,env(safe-area-inset-bottom));width:min(536px,calc(100vw - 64px));transform:translateX(-50%);z-index:100010;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));align-items:center;justify-content:stretch;gap:6px;padding:6px;border-radius:22px;background:linear-gradient(180deg,rgba(13,18,31,.94),rgba(9,13,23,.92));border:1px solid rgba(255,255,255,.07);box-shadow:0 20px 36px rgba(0,0,0,.3),0 6px 16px rgba(0,0,0,.16);backdrop-filter:blur(18px) saturate(124%);-webkit-backdrop-filter:blur(18px) saturate(124%);overflow:hidden;isolation:isolate;transition:transform .12s ease,box-shadow .12s ease,opacity .12s ease}" +
          "body.wp-main-app #wpAppDock::before{content:'';position:absolute;inset:0;border-radius:inherit;background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,0));pointer-events:none;z-index:0}" +
          "body.wp-main-app #wpAppDock::after{display:none}" +
          "body.wp-main-app #wpAppDockIndicator{position:absolute;top:0;left:0;width:122px;height:56px;border-radius:17px;background:linear-gradient(180deg,rgba(104,126,255,.2),rgba(104,126,255,.1));border:1px solid rgba(122,142,255,.18);box-shadow:inset 0 1px 0 rgba(255,255,255,.07),0 8px 16px rgba(18,24,43,.14);transform:translate3d(0,0,0);transition:transform .16s cubic-bezier(.2,.9,.25,1),width .16s cubic-bezier(.2,.9,.25,1),height .16s cubic-bezier(.2,.9,.25,1),opacity .12s ease;opacity:0;z-index:1;pointer-events:none;overflow:hidden;will-change:transform,width,height}" +
          "body.wp-main-app #wpAppDockIndicator::before{content:'';position:absolute;inset:0;border-radius:inherit;background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,0) 52%);opacity:1}" +
          "body.wp-main-app #wpAppDockIndicator::after{display:none}" +
          "body.wp-main-app #wpAppDockIndicator.ready{opacity:1}" +
          "body.wp-main-app #wpAppTransitionVeil{position:fixed;inset:0;z-index:100009;pointer-events:none;opacity:0;background:radial-gradient(circle at 50% 100%,rgba(103,125,255,.08),transparent 26%),linear-gradient(180deg,rgba(5,7,13,0),rgba(5,7,13,.12));transition:opacity .18s ease}" +
          "body.wp-main-app.wp-app-transitioning #wpAppTransitionVeil{opacity:1}" +
          "body.wp-main-app #wpAppDock.dragging{transform:translateX(-50%) scale(.988);box-shadow:0 16px 30px rgba(0,0,0,.34),0 6px 14px rgba(0,0,0,.2)}" +
          "body.wp-main-app #wpAppDock.dragging #wpAppDockIndicator{transition:none;box-shadow:0 16px 26px rgba(72,93,199,.26),inset 0 1px 0 rgba(255,255,255,.1)}" +
          "body.wp-main-app.wp-app-transitioning #wpAppDock{opacity:.995;transform:translateX(-50%) scale(.988)}" +
          "body.wp-main-app.wp-app-transitioning #wpAppDockIndicator{box-shadow:0 16px 26px rgba(72,93,199,.28),inset 0 1px 0 rgba(255,255,255,.1)}" +
          "body.wp-main-app .wp-app-dock-link{position:relative;z-index:2;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-width:0;min-height:52px;padding:7px 8px 8px;border-radius:16px;color:#97a2b8;text-decoration:none;font:700 10px/1 Inter,system-ui,sans-serif;transition:color .12s ease,transform .12s ease,opacity .12s ease;transform:translateZ(0);overflow:hidden;text-align:center;touch-action:manipulation;-webkit-tap-highlight-color:transparent}" +
          "body.wp-main-app .wp-app-dock-link::before{display:none}" +
          "body.wp-main-app .wp-app-dock-link span{display:flex;align-items:center;justify-content:center;min-height:12px;max-width:100%;width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;transition:opacity .14s ease,color .14s ease;letter-spacing:-.01em}" +
          "body.wp-main-app .wp-app-dock-label-full{display:flex!important}" +
          "body.wp-main-app .wp-app-dock-label-short{display:none!important}" +
          "body.wp-main-app .wp-app-dock-link:hover{color:#f3f6ff}" +
          "body.wp-main-app .wp-app-dock-link.active{color:#dfe6ff}" +
          "body.wp-main-app .wp-app-dock-link.is-preview{color:#dfe6ff}" +
          "body.wp-main-app .wp-app-dock-link.is-pressing{transform:scale(.965)!important}" +
          "body.wp-main-app.wp-app-transitioning .wp-app-dock-link{opacity:.9}" +
          "body.wp-main-app.wp-app-transitioning .wp-app-dock-link.active,body.wp-main-app.wp-app-transitioning .wp-app-dock-link.is-preview{opacity:1}" +
          "body.wp-main-app .wp-app-dock-link svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:1.85;stroke-linecap:round;stroke-linejoin:round;transition:transform .12s ease,stroke .12s ease,opacity .12s ease}" +
          "body.wp-main-app .wp-app-dock-link.active svg,body.wp-main-app .wp-app-dock-link.is-preview svg{transform:translateY(-1px)}" +
          "body.wp-main-app .wp-app-dock-link.active span,body.wp-main-app .wp-app-dock-link.is-preview span{opacity:1}" +
          "body.wp-main-app #wpAppHomeHero{display:grid;grid-template-columns:minmax(0,1.2fr) auto;gap:18px;align-items:end;margin:0 0 18px;padding:24px 24px 22px;border-radius:30px;border:1px solid rgba(255,255,255,.08);background:linear-gradient(140deg,rgba(15,22,44,.92),rgba(10,16,32,.66));box-shadow:0 26px 70px rgba(0,0,0,.28)}" +
          "body.wp-main-app .wp-app-home-copy{display:flex;flex-direction:column;gap:10px}" +
          "body.wp-main-app .wp-app-home-eyebrow{font:800 12px/1.1 Inter,system-ui,sans-serif;letter-spacing:.18em;text-transform:uppercase;color:#f6c87a}" +
          "body.wp-main-app .wp-app-home-title{font:800 clamp(30px,4vw,46px)/.98 Inter,system-ui,sans-serif;color:#eef3ff;letter-spacing:-.05em}" +
          "body.wp-main-app .wp-app-home-text{font:600 14px/1.55 Inter,system-ui,sans-serif;color:#aab6cf;max-width:560px}" +
          "body.wp-main-app .wp-app-home-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:2px}" +
          "body.wp-main-app .wp-app-home-link{display:inline-flex;align-items:center;gap:8px;padding:12px 16px;border-radius:18px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:#eef3ff;text-decoration:none;font:700 13px/1 Inter,system-ui,sans-serif}" +
          "body.wp-main-app .wp-app-home-link.primary{background:linear-gradient(135deg,#6b7cff,#8ea1ff);border-color:transparent;color:#fff;box-shadow:0 14px 30px rgba(107,124,255,.28)}" +
          "body.wp-main-app .wp-app-home-meta{display:grid;grid-template-columns:repeat(2,minmax(120px,1fr));gap:10px;min-width:280px}" +
          "body.wp-main-app .wp-app-home-stat{padding:14px 16px;border-radius:18px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08)}" +
          "body.wp-main-app .wp-app-home-stat strong{display:block;font:800 20px/1 Inter,system-ui,sans-serif;color:#eef3ff;margin-bottom:6px}" +
          "body.wp-main-app .wp-app-home-stat span{display:block;font:700 12px/1.4 Inter,system-ui,sans-serif;color:#9aa7bf}" +
          "body.wp-main-app[data-wp-app-page='songs'] #wpAppHomeHero{display:none!important}" +
          "body.wp-main-app[data-wp-app-page='songs'] #wpAppPagebar{margin-bottom:12px}" +
          "body.wp-main-app[data-wp-app-page='songs'] .header{display:grid;grid-template-columns:minmax(0,200px) minmax(0,1fr);align-items:center;gap:16px;padding:18px 18px 12px;border-radius:24px;border:1px solid rgba(255,255,255,.06);background:rgba(9,16,32,.38);box-shadow:0 18px 50px rgba(0,0,0,.2)}" +
          "body.wp-main-app[data-wp-app-page='songs'] .brand h1{font-size:15px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#f6c87a}" +
          "body.wp-main-app[data-wp-app-page='songs'] .controls{justify-content:space-between;padding-top:0}" +
          "body.wp-main-app[data-wp-app-page='songs'] .search-card{min-width:unset;width:min(720px,100%);padding:10px 12px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.05);box-shadow:none}" +
          "body.wp-main-app[data-wp-app-page='songs'] .table-card{border-radius:28px;border:1px solid rgba(255,255,255,.07);background:linear-gradient(180deg,rgba(11,16,32,.76),rgba(11,16,32,.58));box-shadow:0 24px 60px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='songs'] .table-header{padding:18px 18px 16px}" +
          "body.wp-main-app[data-wp-app-page='songs'] .section,body.wp-main-app[data-wp-app-page='favorites'] .section{padding:12px 0 0}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .header{display:grid;grid-template-columns:minmax(0,200px) minmax(0,1fr);align-items:center;gap:16px;padding:18px 18px 12px;border-radius:24px;border:1px solid rgba(255,255,255,.06);background:rgba(9,16,32,.38);box-shadow:0 18px 50px rgba(0,0,0,.2)}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .brand h1{font-size:15px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#f6c87a}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .controls{justify-content:space-between;padding-top:0}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .search-card{min-width:unset;width:min(720px,100%);padding:10px 12px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.05);box-shadow:none}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .table-card{border-radius:28px;border:1px solid rgba(255,255,255,.07);background:linear-gradient(180deg,rgba(11,16,32,.76),rgba(11,16,32,.58));box-shadow:0 24px 60px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='favorites'] .table-header{padding:18px 18px 16px}" +
          "body.wp-main-app[data-wp-app-page='account'] .container{max-width:1080px;padding:8px 0 122px}" +
          "body.wp-main-app[data-wp-app-page='account'] .grid{gap:12px}" +
          "body.wp-main-app[data-wp-app-page='account'] .card{border-radius:24px;border:1px solid rgba(255,255,255,.08);background:linear-gradient(180deg,rgba(11,16,32,.72),rgba(11,16,32,.56));box-shadow:0 22px 54px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='account'] h1{font-size:18px;margin-bottom:8px}" +
          "body.wp-main-app[data-wp-app-page='account'] .sub{font-size:12px;margin-bottom:12px}" +
          "body.wp-main-app[data-wp-app-page='account'] .panel-card,body.wp-main-app[data-wp-app-page='account'] .card{padding:16px}" +
          "body.wp-main-app[data-wp-app-page='setlists'] .wrap{padding:8px 0 122px;max-width:1320px}" +
          "body.wp-main-app[data-wp-app-page='setlists'] .hero{margin-bottom:12px}" +
          "body.wp-main-app[data-wp-app-page='setlists'] .card{border-radius:24px;background:rgba(11,16,32,.62);border:1px solid rgba(255,255,255,.07);box-shadow:0 22px 54px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='setlists'] .card-body{padding:16px}" +
          "body.wp-main-app[data-wp-app-page='news'] .page-header{padding:6px 8px 18px;text-align:left}" +
          "body.wp-main-app[data-wp-app-page='news'] .page-header h1{font-size:28px;margin-bottom:8px;color:#eef3ff}" +
          "body.wp-main-app[data-wp-app-page='news'] .page-header p{font-size:14px;color:#9aa7bf}" +
          "body.wp-main-app[data-wp-app-page='news'] .news-section{padding:0 0 122px;gap:18px;max-width:1320px}" +
          "body.wp-main-app[data-wp-app-page='news'] .news-card{border-radius:24px;padding:20px;box-shadow:0 22px 54px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='song'] #wpAppPagebar{display:none}" +
          "body.wp-main-app[data-wp-app-page='song'] .app{max-width:min(1320px,100%);margin:0 auto;padding:0 0 122px;min-height:auto}" +
          "body.wp-main-app[data-wp-app-page='song'] .topbar{padding:14px 14px 12px;border-radius:22px;margin:0 0 12px;background:rgba(11,16,32,.62);border:1px solid rgba(255,255,255,.07);box-shadow:0 22px 54px rgba(0,0,0,.24)}" +
          "body.wp-main-app[data-wp-app-page='song'] .main{display:grid;grid-template-columns:minmax(0,1fr) 340px;align-items:start;gap:16px;padding:0;margin:0}" +
          "body.wp-main-app[data-wp-app-page='song'] .content{min-width:0;gap:12px}" +
          "body.wp-main-app[data-wp-app-page='song'] .content>.card{padding:20px}" +
          "body.wp-main-app[data-wp-app-page='song'] .panel{width:auto;max-height:none;position:sticky;top:12px;align-self:start}" +
          "body.wp-main-app[data-wp-app-page='song'] .card,body.wp-main-app[data-wp-app-page='song'] .panel{border-radius:24px;box-shadow:0 22px 54px rgba(0,0,0,.24);background:linear-gradient(180deg,rgba(11,16,32,.76),rgba(11,16,32,.58));border:1px solid rgba(255,255,255,.07)}" +
          "body.wp-main-app[data-wp-app-page='song'] .chords{min-height:240px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05)}" +
          "body.wp-main-app[data-wp-app-page='song'] .setlist-nav{margin:0 0 12px;padding:10px 12px;border-radius:18px;background:rgba(11,16,32,.62);border:1px solid rgba(255,255,255,.07)}" +
          "body.wp-main-app[data-wp-app-page='song'] .fav-nav{bottom:max(calc(env(safe-area-inset-bottom) + 84px),84px)}" +
          "@media (max-width:980px){body.wp-main-app #wpAppPagebar{padding:18px;align-items:flex-start;flex-direction:column}body.wp-main-app .wp-app-pagebar-side{justify-content:flex-start}body.wp-main-app #wpAppHomeHero{grid-template-columns:1fr}body.wp-main-app .wp-app-home-meta{min-width:0}}" +
          "@media (max-width:720px){body.wp-main-app .container{padding-bottom:114px!important}body.wp-main-app #wpAppPagebar{gap:12px;padding:14px 14px 12px;border-radius:20px;margin-bottom:12px}body.wp-main-app .wp-app-pagebar-kicker{font-size:11px;letter-spacing:.14em}body.wp-main-app .wp-app-pagebar-title{font-size:21px;line-height:1.08}body.wp-main-app .wp-app-pagebar-subtitle{font-size:11px;line-height:1.45;max-width:none}body.wp-main-app .wp-app-pagebar-side{width:100%;gap:8px;flex-wrap:nowrap;overflow:auto;padding-bottom:2px}body.wp-main-app .wp-app-chip{padding:8px 10px;font-size:10px;flex:0 0 auto}body.wp-main-app #wpAppDock{width:min(336px,calc(100vw - 22px));gap:5px;padding:8px 8px 9px;bottom:max(10px,env(safe-area-inset-bottom));border-radius:26px;background:linear-gradient(180deg,rgba(14,19,32,.97),rgba(10,14,24,.95));border:1px solid rgba(255,255,255,.07);box-shadow:0 18px 30px rgba(0,0,0,.34),0 6px 16px rgba(0,0,0,.22);backdrop-filter:blur(18px) saturate(124%);-webkit-backdrop-filter:blur(18px) saturate(124%)}body.wp-main-app #wpAppDock::before{inset:0;border-radius:inherit;background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,0))}body.wp-main-app #wpAppDock::after{display:none}body.wp-main-app #wpAppDockIndicator{height:58px;border-radius:18px;background:linear-gradient(180deg,rgba(104,126,255,.2),rgba(104,126,255,.1));border:1px solid rgba(122,142,255,.18);box-shadow:inset 0 1px 0 rgba(255,255,255,.07),0 8px 18px rgba(18,24,43,.16)}body.wp-main-app #wpAppDockIndicator::after{display:none}body.wp-main-app .wp-app-dock-link{min-width:0;min-height:58px;padding:7px 2px 8px;border-radius:18px;gap:4px;color:#a0abc0;font-size:10px;line-height:1}body.wp-main-app .wp-app-dock-label-full{display:none!important}body.wp-main-app .wp-app-dock-label-short{display:flex!important}body.wp-main-app .wp-app-dock-link span{min-height:11px;font-size:9px;line-height:1;text-align:center}body.wp-main-app .wp-app-dock-link svg{width:19px;height:19px;stroke-width:1.9}body.wp-main-app .wp-app-dock-link:hover{color:#f3f6ff;transform:none}body.wp-main-app .wp-app-dock-link.active,body.wp-main-app .wp-app-dock-link.is-preview{color:#edf2ff;transform:none}body.wp-main-app .wp-app-dock-link.active svg,body.wp-main-app .wp-app-dock-link.is-preview svg{transform:none}body.wp-main-app #wpAppHomeHero{padding:16px 14px 16px;border-radius:22px;margin-bottom:12px;gap:14px}body.wp-main-app .wp-app-home-title{font-size:24px;line-height:1.02}body.wp-main-app .wp-app-home-text{font-size:12px;line-height:1.5}body.wp-main-app .wp-app-home-actions{display:grid;grid-template-columns:1fr 1fr;width:100%;gap:8px}body.wp-main-app .wp-app-home-link{justify-content:center;padding:11px 10px;font-size:11px;border-radius:16px}body.wp-main-app .wp-app-home-meta{grid-template-columns:1fr 1fr;gap:8px}body.wp-main-app .wp-app-home-stat{padding:12px 12px;border-radius:16px}body.wp-main-app .wp-app-home-stat strong{font-size:17px}body.wp-main-app .wp-app-home-stat span{font-size:11px}body.wp-main-app[data-wp-app-page='songs'] .header,body.wp-main-app[data-wp-app-page='favorites'] .header{grid-template-columns:1fr;padding:12px;border-radius:18px;gap:12px}body.wp-main-app[data-wp-app-page='songs'] .brand h1,body.wp-main-app[data-wp-app-page='favorites'] .brand h1{font-size:12px}body.wp-main-app[data-wp-app-page='songs'] .controls,body.wp-main-app[data-wp-app-page='favorites'] .controls{gap:10px;width:100%}body.wp-main-app[data-wp-app-page='songs'] .search-card,body.wp-main-app[data-wp-app-page='favorites'] .search-card{width:100%;padding:9px 10px;border-radius:16px}body.wp-main-app[data-wp-app-page='songs'] .search-input,body.wp-main-app[data-wp-app-page='favorites'] .search-input{font-size:15px}body.wp-main-app[data-wp-app-page='songs'] .mode-switch,body.wp-main-app[data-wp-app-page='favorites'] .mode-switch{width:100%;justify-content:space-between;gap:8px;padding:8px 10px;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06)}body.wp-main-app[data-wp-app-page='songs'] .table-card,body.wp-main-app[data-wp-app-page='favorites'] .table-card{border-radius:20px;overflow:hidden}body.wp-main-app[data-wp-app-page='songs'] .table-header,body.wp-main-app[data-wp-app-page='favorites'] .table-header{padding:14px 14px 12px;align-items:flex-start;gap:8px;flex-direction:column}body.wp-main-app[data-wp-app-page='songs'] .table-header h2,body.wp-main-app[data-wp-app-page='favorites'] .table-header h2{font-size:15px}body.wp-main-app[data-wp-app-page='songs'] .songs-count,body.wp-main-app[data-wp-app-page='favorites'] .songs-count{font-size:12px}body.wp-main-app[data-wp-app-page='songs'] .section,body.wp-main-app[data-wp-app-page='favorites'] .section{padding:10px 0 0}body.wp-main-app[data-wp-app-page='songs'] tr,body.wp-main-app[data-wp-app-page='favorites'] tr{padding:10px;border-radius:14px;margin-bottom:10px}body.wp-main-app[data-wp-app-page='songs'] td.title-cell,body.wp-main-app[data-wp-app-page='favorites'] td.title-cell{padding:4px 4px 4px 0;gap:10px}body.wp-main-app[data-wp-app-page='account'] .container{padding:0 0 128px!important}body.wp-main-app[data-wp-app-page='account'] .grid{grid-template-columns:1fr!important;gap:10px}body.wp-main-app[data-wp-app-page='account'] .card{border-radius:18px;padding:14px}body.wp-main-app[data-wp-app-page='account'] .panel-card{padding:14px}body.wp-main-app[data-wp-app-page='account'] input{padding:11px 12px;border-radius:10px}body.wp-main-app[data-wp-app-page='setlists'] .wrap{padding:0 0 128px}body.wp-main-app[data-wp-app-page='setlists'] .grid{grid-template-columns:1fr!important;gap:10px}body.wp-main-app[data-wp-app-page='setlists'] .card{border-radius:20px}body.wp-main-app[data-wp-app-page='setlists'] .hero{gap:10px;margin-bottom:10px}body.wp-main-app[data-wp-app-page='setlists'] .hero-title{font-size:22px}body.wp-main-app[data-wp-app-page='setlists'] .top-actions{width:100%}body.wp-main-app[data-wp-app-page='setlists'] .top-actions>.btn,body.wp-main-app[data-wp-app-page='setlists'] .top-actions>button{width:100%}body.wp-main-app[data-wp-app-page='news'] .page-header{padding:0 0 14px}body.wp-main-app[data-wp-app-page='news'] .page-header h1{font-size:24px}body.wp-main-app[data-wp-app-page='news'] .page-header p{font-size:13px}body.wp-main-app[data-wp-app-page='news'] .news-section{padding:0 0 128px;grid-template-columns:1fr;gap:14px}body.wp-main-app[data-wp-app-page='news'] .news-card{padding:16px;border-radius:20px}body.wp-main-app[data-wp-app-page='song'] .app{padding:0 0 104px}body.wp-main-app[data-wp-app-page='song'] .topbar{padding:12px;border-radius:18px;margin-bottom:10px}body.wp-main-app[data-wp-app-page='song'] .topbar-controls{gap:8px;flex-wrap:wrap}body.wp-main-app[data-wp-app-page='song'] .font-panel{width:100%;justify-content:space-between}body.wp-main-app[data-wp-app-page='song'] .topbar-icons{width:100%;justify-content:space-between}body.wp-main-app[data-wp-app-page='song'] .main{display:flex;flex-direction:column;gap:12px;padding:0}body.wp-main-app[data-wp-app-page='song'] .panel{position:static;width:100%;order:2}body.wp-main-app[data-wp-app-page='song'] .content>.card,body.wp-main-app[data-wp-app-page='song'] .panel.card{padding:14px;border-radius:20px}body.wp-main-app[data-wp-app-page='song'] .song-title{font-size:18px;line-height:1.2}body.wp-main-app[data-wp-app-page='song'] .song-artist{font-size:12px}body.wp-main-app[data-wp-app-page='song'] .info-row{gap:6px}body.wp-main-app[data-wp-app-page='song'] .info-pill{font-size:11px;padding:5px 8px}body.wp-main-app[data-wp-app-page='song'] .view-modes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}body.wp-main-app[data-wp-app-page='song'] .view-modes .theme-btn{width:100%;min-height:40px;padding:8px 6px;font-size:10px;line-height:1.2}body.wp-main-app[data-wp-app-page='song'] .setlist-nav{margin:0 0 10px;padding:8px;border-radius:16px}body.wp-main-app[data-wp-app-page='song'] .setlist-nav-btn{min-width:82px;height:36px;font-size:11px;padding:0 8px}body.wp-main-app[data-wp-app-page='song'] .fav-nav{width:calc(100% - 20px);max-width:420px;bottom:max(calc(env(safe-area-inset-bottom) + 72px),72px)}}";
        document.head.appendChild(style);
      }

      var container =
        document.querySelector(".container") ||
        document.querySelector(".wrap") ||
        document.querySelector(".auth-shell") ||
        document.querySelector(".login-container") ||
        document.querySelector(".card") ||
        document.querySelector(".app") ||
        document.querySelector("main");

      if (container && !isAuthProgramPage() && !document.getElementById("wpAppPagebar")) {
        var pagebar = document.createElement("section");
        pagebar.id = "wpAppPagebar";
        pagebar.innerHTML =
          '<div class="wp-app-pagebar-copy">' +
          '  <span class="wp-app-pagebar-kicker">Worship ծրագիր</span>' +
          '  <strong class="wp-app-pagebar-title">' + pageMeta.title + '</strong>' +
          '  <span class="wp-app-pagebar-subtitle">' + pageMeta.subtitle + '</span>' +
          "</div>" +
          '<div class="wp-app-pagebar-side">' +
          '  <span id="wpAppLibraryChip" class="wp-app-chip">Առցանց գրադարան</span>' +
          '  <span id="wpAppOnlineChip" class="wp-app-chip ' + (navigator.onLine ? "status-online" : "status-offline") + '">' + (navigator.onLine ? "Առցանց" : "Օֆֆլայն") + "</span>" +
          "</div>";
        container.parentNode.insertBefore(pagebar, container);
      }

      if (container && pageMeta.key === "landing" && !document.getElementById("wpAppHomeHero")) {
        var header = container.querySelector(".header");
        var hero = document.createElement("section");
        hero.id = "wpAppHomeHero";
        hero.innerHTML =
          '<div class="wp-app-home-copy">' +
          '  <span class="wp-app-home-eyebrow">Installed Worship App</span>' +
          '  <strong class="wp-app-home-title">Երգերը, պահպանումը և սեթլիստները մեկ հոսքում</strong>' +
          '  <span class="wp-app-home-text">Սա արդեն ծրագրի աշխատային տարբերակն է. արագ որոնիր երգերը, բացիր պահպանվածները, աշխատիր օֆֆլայն և կազմիր ծառայության սեթլիստները առանց կայքի ավելորդ navigation-ի։</span>' +
          '  <div class="wp-app-home-actions">' +
          '    <a class="wp-app-home-link primary" href="/main.html?source=pwa">Բացել երգերը</a>' +
          '    <a class="wp-app-home-link" href="/favorites.html?source=pwa">Պահպանված</a>' +
          '    <a class="wp-app-home-link" href="/setlists.html?source=pwa">Սեթլիստներ</a>' +
          '    <a class="wp-app-home-link" href="/account.html?source=pwa">Կարգավորումներ</a>' +
          "  </div>" +
          "</div>" +
          '<div class="wp-app-home-meta">' +
          '  <div class="wp-app-home-stat"><strong>Օֆֆլայն</strong><span>Երգերը հասանելի են պահված գրադարանից</span></div>' +
          '  <div class="wp-app-home-stat"><strong>Արագ</strong><span>Որոնումը և բացումը մեկ հիմնական workspace-ում</span></div>' +
          '  <div class="wp-app-home-stat"><strong>Push</strong><span>Թարմացումներ և հայտարարություններ հենց ծրագրի մեջ</span></div>' +
          '  <div class="wp-app-home-stat"><strong>Setlist</strong><span>Ծառայության երգացանկը միշտ հասանելի է</span></div>' +
          "</div>";
        if (header) {
          container.insertBefore(hero, header);
        } else {
          container.prepend(hero);
        }
      }

      function placeDockIndicator(dock, link) {
        if (!dock || !link) return;
        var indicator = dock.querySelector("#wpAppDockIndicator");
        if (!indicator) return;
        var dockRect = dock.getBoundingClientRect();
        var linkRect = link.getBoundingClientRect();
        var isCompactMobile = window.matchMedia && window.matchMedia("(max-width:720px)").matches;
        var insetX = isCompactMobile ? 5 : 2;
        var insetY = isCompactMobile ? 6 : 2;
        var width = Math.max(24, Math.round(linkRect.width - insetX * 2));
        var height = Math.max(24, Math.round(linkRect.height - insetY * 2));
        var offsetX = Math.round(linkRect.left - dockRect.left + insetX);
        var offsetY = Math.round(linkRect.top - dockRect.top + insetY);
        indicator.style.width = width + "px";
        indicator.style.height = height + "px";
        indicator.style.transform = "translate3d(" + offsetX + "px," + offsetY + "px,0)";
      }

      function setDockPreview(dock, targetLink) {
        if (!dock) return;
        dock.querySelectorAll(".wp-app-dock-link").forEach(function(link) {
          link.classList.toggle("is-preview", link === targetLink);
        });
      }

      function updateDockIndicator(dock, currentKey) {
        if (!dock) return;
        var indicator = dock.querySelector("#wpAppDockIndicator");
        var activeLink = dock.querySelector('.wp-app-dock-link[data-dock-key="' + currentKey + '"]') || dock.querySelector(".wp-app-dock-link.active");
        if (!indicator || !activeLink) return;

        var previousKey = "";
        try {
          previousKey = localStorage.getItem("wp_app_last_dock_key") || "";
        } catch (err) {}

        var previousLink = previousKey ? dock.querySelector('.wp-app-dock-link[data-dock-key="' + previousKey + '"]') : null;

        if (previousLink && previousLink !== activeLink) {
          placeDockIndicator(dock, previousLink);
          requestAnimationFrame(function() {
            indicator.classList.add("ready");
            requestAnimationFrame(function() {
              placeDockIndicator(dock, activeLink);
            });
          });
        } else {
          placeDockIndicator(dock, activeLink);
          requestAnimationFrame(function() {
            indicator.classList.add("ready");
          });
        }

        dock.querySelectorAll(".wp-app-dock-link").forEach(function(link) {
          link.classList.toggle("active", link === activeLink);
          link.classList.remove("is-preview");
        });

        try {
          localStorage.setItem("wp_app_last_dock_key", currentKey);
        } catch (err) {}
      }

      function bindDockInteractions(dock) {
        if (!dock || dock.dataset.wpBound === "1") return;
        dock.dataset.wpBound = "1";
        var navigating = false;

        var dragState = {
          active: false,
          moved: false,
          pointerId: null,
          startX: 0,
          startLink: null,
          currentLink: null,
          suppressClick: false
        };

        function getDockLinks() {
          return Array.prototype.slice.call(dock.querySelectorAll(".wp-app-dock-link"));
        }

        function getClosestLink(clientX) {
          var links = getDockLinks();
          if (!links.length) return null;

          var closest = links[0];
          var closestDistance = Infinity;
          links.forEach(function(link) {
            var rect = link.getBoundingClientRect();
            var center = rect.left + rect.width / 2;
            var distance = Math.abs(center - clientX);
            if (distance < closestDistance) {
              closestDistance = distance;
              closest = link;
            }
          });
          return closest;
        }

        function preloadDockTargets() {
          getDockLinks().forEach(function(link) {
            var href = link.getAttribute("href") || "";
            if (!href) return;
            var absolute = new URL(href, window.location.origin).toString();
            var existing = document.querySelector('link[rel="prefetch"][href="' + absolute + '"]');
            if (existing) return;
            var prefetch = document.createElement("link");
            prefetch.rel = "prefetch";
            prefetch.href = absolute;
            prefetch.as = "document";
            document.head.appendChild(prefetch);
          });
        }

        function warmDockTarget(href) {
          if (!href || !window.fetch) return;
          try {
            fetch(href, {
              method: "GET",
              credentials: "same-origin",
              cache: "force-cache"
            }).catch(function() {});
          } catch (err) {}
        }

        function beginPageTransition(targetLink) {
          if (!targetLink) return;
          document.body.classList.add("wp-app-transitioning");
          setDockPreview(dock, targetLink);
          placeDockIndicator(dock, targetLink);
          var indicator = dock.querySelector("#wpAppDockIndicator");
          if (indicator) indicator.classList.add("ready");
        }

        function navigateToDockLink(link) {
          if (!link) return;
          if (navigating) return;
          var href = link.getAttribute("href") || "";
          if (!href) return;
          try {
            localStorage.setItem("wp_app_last_dock_key", link.getAttribute("data-dock-key") || "");
          } catch (err) {}
          if (new URL(href, window.location.origin).toString() === window.location.href) return;
          navigating = true;
          warmDockTarget(href);
          beginPageTransition(link);
          window.location.assign(href);
        }

        function beginDrag(link, event) {
          if (!link || !event) return;
          if (typeof event.preventDefault === "function") event.preventDefault();
          dragState.active = true;
          dragState.moved = false;
          dragState.pointerId = event.pointerId;
          dragState.startX = event.clientX;
          dragState.startLink = link;
          dragState.currentLink = link;
          if (typeof link.setPointerCapture === "function" && event.pointerId != null) {
            try { link.setPointerCapture(event.pointerId); } catch (err) {}
          }
          dock.classList.add("dragging");
          link.classList.add("is-pressing");
          setDockPreview(dock, link);
          placeDockIndicator(dock, link);
          var indicator = dock.querySelector("#wpAppDockIndicator");
          if (indicator) indicator.classList.add("ready");
        }

        function moveDrag(clientX) {
          if (!dragState.active) return;
          if (Math.abs(clientX - dragState.startX) > 8) {
            dragState.moved = true;
          }
          var closest = getClosestLink(clientX);
          if (!closest) return;
          dragState.currentLink = closest;
          setDockPreview(dock, closest);
          placeDockIndicator(dock, closest);
        }

        function finishDrag(commit) {
          if (!dragState.active) return;
          var target = dragState.currentLink || dragState.startLink;
          var releaseTarget = dragState.startLink;
          dock.classList.remove("dragging");
          getDockLinks().forEach(function(link) {
            link.classList.remove("is-pressing");
            link.classList.remove("is-preview");
          });
          if (releaseTarget && typeof releaseTarget.releasePointerCapture === "function" && dragState.pointerId != null) {
            try { releaseTarget.releasePointerCapture(dragState.pointerId); } catch (err) {}
          }
          dragState.active = false;
          dragState.pointerId = null;
          dragState.suppressClick = true;
          if (commit && target) {
            navigateToDockLink(target);
          } else {
            updateDockIndicator(dock, pageMeta.key);
          }
        }

        dock.addEventListener("pointermove", function(event) {
          if (!dragState.active) return;
          moveDrag(event.clientX);
        });

        window.addEventListener("pointerup", function(event) {
          if (!dragState.active) return;
          if (dragState.pointerId !== null && event.pointerId !== dragState.pointerId) return;
          finishDrag(true);
        });

        window.addEventListener("pointercancel", function(event) {
          if (!dragState.active) return;
          if (dragState.pointerId !== null && event.pointerId !== dragState.pointerId) return;
          finishDrag(false);
        });

        dock.querySelectorAll(".wp-app-dock-link").forEach(function(link) {
          link.addEventListener("pointerenter", function() {
            warmDockTarget(link.getAttribute("href") || "");
          });
          link.addEventListener("focus", function() {
            warmDockTarget(link.getAttribute("href") || "");
          });
          link.addEventListener("pointerdown", function(event) {
            beginDrag(link, event);
          });
          link.addEventListener("pointerup", function(event) {
            link.classList.remove("is-pressing");
            if (!dragState.active) return;
            if (dragState.pointerId !== null && event && event.pointerId !== dragState.pointerId) return;
            finishDrag(true);
          });
          link.addEventListener("pointercancel", function() {
            link.classList.remove("is-pressing");
          });
          link.addEventListener("mouseleave", function() {
            link.classList.remove("is-pressing");
          });
          link.addEventListener("click", function(event) {
            event.preventDefault();
            if (dragState.suppressClick) {
              dragState.suppressClick = false;
              return;
            }
            navigateToDockLink(link);
          });
        });

        window.addEventListener("resize", function() {
          updateDockIndicator(dock, pageMeta.key);
        });

        if ("requestIdleCallback" in window) {
          window.requestIdleCallback(preloadDockTargets, { timeout: 1200 });
        } else {
          setTimeout(preloadDockTargets, 300);
        }
      }

      var dock = document.getElementById("wpAppDock");
      var transitionVeil = document.getElementById("wpAppTransitionVeil");
      if (!transitionVeil) {
        transitionVeil = document.createElement("div");
        transitionVeil.id = "wpAppTransitionVeil";
        document.body.appendChild(transitionVeil);
      }
      if (!dock) {
        var links = [
          { href: "/main.html?source=pwa", key: "songs", label: "Երգեր", shortLabel: "Երգեր", icon: '<svg viewBox="0 0 24 24"><path d="M8 17.5V6.4a1 1 0 0 1 .76-.97l7.8-1.82a.8.8 0 0 1 .98.78V15"></path><path d="M8 8.2l9.5-2.2"></path><ellipse cx="6.2" cy="18.2" rx="2.7" ry="2.1"></ellipse><ellipse cx="15.8" cy="16.6" rx="2.7" ry="2.1"></ellipse></svg>' },
          { href: "/favorites.html?source=pwa", key: "favorites", label: "Պահպ.", shortLabel: "Պահպ.", icon: '<svg viewBox="0 0 24 24"><path d="M12 20.6c-.26 0-.52-.09-.72-.26C5.85 15.63 3 12.98 3 9.38 3 6.98 4.92 5 7.28 5c1.52 0 2.96.72 3.88 1.95A4.83 4.83 0 0 1 15.04 5C17.5 5 19.5 6.98 19.5 9.38c0 3.6-2.85 6.25-8.28 10.96-.2.17-.46.26-.72.26Z"></path></svg>' },
          { href: "/setlists.html?source=pwa", key: "setlists", label: "Ցանկեր", shortLabel: "Ցանկեր", icon: '<svg viewBox="0 0 24 24"><rect x="4.5" y="5" width="15" height="3.2" rx="1.6"></rect><rect x="4.5" y="10.4" width="15" height="3.2" rx="1.6"></rect><rect x="4.5" y="15.8" width="15" height="3.2" rx="1.6"></rect><path d="M8 6.6h7"></path><path d="M8 12h7"></path><path d="M8 17.4h7"></path></svg>' },
          { href: "/account.html?source=pwa", key: "account", label: "Հաշիվ", shortLabel: "Հաշիվ", icon: '<svg viewBox="0 0 24 24"><path d="M12 13.2a4.1 4.1 0 1 0 0-8.2 4.1 4.1 0 0 0 0 8.2Z"></path><path d="M5 19.2c1.55-2.36 4.13-3.7 7-3.7s5.45 1.34 7 3.7"></path><path d="M19.2 7.8h.01"></path></svg>' }
        ];
        dock = document.createElement("nav");
        dock.id = "wpAppDock";
        dock.setAttribute("aria-label", "App navigation");
        dock.innerHTML = '<span id="wpAppDockIndicator" aria-hidden="true"></span>' + links.map(function(link) {
          var active = pageMeta.key === link.key ? " active" : "";
          return '<a class="wp-app-dock-link' + active + '" data-dock-key="' + link.key + '" href="' + link.href + '">' + link.icon + '<span class="wp-app-dock-label-full">' + link.label + '</span><span class="wp-app-dock-label-short">' + (link.shortLabel || link.label) + "</span></a>";
        }).join("");
        document.body.appendChild(dock);
      }

      bindDockInteractions(dock);
      updateDockIndicator(dock, pageMeta.key);
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", apply, { once: true });
    } else {
      apply();
    }
  }

  redirectStandaloneLandingToAppHome();
  ensureStandaloneAppInterface();
  preserveStandaloneNavigationContext();

  function ensureLoaderStyles() {
    if (document.getElementById("wpPageLoaderStyles")) return;
    var style = document.createElement("style");
    style.id = "wpPageLoaderStyles";
    style.textContent =
      "#pageLoader{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:2147482500;background:radial-gradient(circle at top,rgba(107,78,255,.18),transparent 55%),radial-gradient(circle at 30% 20%,rgba(246,200,122,.10),transparent 55%),rgba(5,7,12,.78);backdrop-filter:blur(10px) saturate(120%);-webkit-backdrop-filter:blur(10px) saturate(120%);transition:opacity .25s ease,visibility .25s ease}" +
      "#pageLoader.hide{opacity:0;visibility:hidden;pointer-events:none}" +
      "#pageLoader .loader-card{width:min(520px,92vw);padding:18px 16px;border-radius:18px;border:1px solid rgba(255,255,255,.10);background:rgba(14,20,28,.55);box-shadow:0 18px 60px rgba(0,0,0,.45);backdrop-filter:blur(12px) saturate(120%)}" +
      "#pageLoader .loader-title{margin:0 0 14px;color:#fff;font:800 18px/1.1 Inter,system-ui,sans-serif}" +
      "#pageLoader .skeleton{height:12px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden;position:relative}" +
      "#pageLoader .skeleton::after{content:'';position:absolute;inset:0;transform:translateX(-100%);background:linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent);animation:wpLoaderShimmer 1.1s infinite}" +
      "#pageLoader .skeleton + .skeleton{margin-top:10px}" +
      "@keyframes wpLoaderShimmer{to{transform:translateX(100%)}}";
    document.head.appendChild(style);
  }

  function ensure(){
    if(document.getElementById('pageLoader')) return;
    ensureLoaderStyles();
    const el = document.createElement('div');
    el.id = 'pageLoader';
    el.innerHTML = `<div class="loader-card">
        <p class="loader-title">Բեռնվում է…</p>
        <div class="skeleton"></div>
        <div class="skeleton" style="width:85%"></div>
        <div class="skeleton" style="width:70%"></div>
      </div>
    `;
    document.body.prepend(el);
  }
  window.PageLoader = { show: ensure, hide(){ document.getElementById('pageLoader')?.classList.add('hide'); } };

  function hidePageLoaderSoon(delay) {
    var timeout = typeof delay === "number" ? delay : 180;
    window.clearTimeout(window.__wpPageLoaderHideTimer);
    window.__wpPageLoaderHideTimer = window.setTimeout(function() {
      window.PageLoader && typeof window.PageLoader.hide === "function" && window.PageLoader.hide();
    }, timeout);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', ensure, { once:true });
  } else {
    ensure();
  }

  if (document.readyState === "complete") {
    hidePageLoaderSoon(80);
  } else {
    window.addEventListener("load", function() {
      hidePageLoaderSoon(120);
    }, { once: true });
  }

  window.addEventListener("pageshow", function() {
    hidePageLoaderSoon(80);
  });

  if ("serviceWorker" in navigator) {
    function isStandaloneMode() {
      return isStandaloneAppMode();
    }

    function ensureStandaloneSourceParam() {
      if (!isStandaloneMode()) return;
      try {
        var url = new URL(window.location.href);
        var expectedSource = getActiveAppSource() || getExpectedAppSource();
        if ((url.searchParams.get("source") || "").toLowerCase() === expectedSource) {
          return;
        }
        url.searchParams.set("source", expectedSource);
        window.history.replaceState(window.history.state, "", url.toString());
      } catch (err) {
        // ignore history/url errors
      }
    }

    function announceAppClient(registration) {
      if (!isStandaloneMode()) return;
      var target = navigator.serviceWorker.controller || (registration && registration.active);
      if (!target || typeof target.postMessage !== "function") return;
      target.postMessage({ type: "REGISTER_APP_CLIENT", scope: "main" });
    }

    function showSyncToast(syncedAt, text) {
      var id = "wpSyncToast";
      var toast = document.getElementById(id);
      if (!toast) {
        toast = document.createElement("div");
        toast.id = id;
        toast.style.position = "fixed";
        toast.style.left = "50%";
        toast.style.bottom = "16px";
        toast.style.transform = "translateX(-50%) translateY(10px)";
        toast.style.opacity = "0";
        toast.style.transition = "opacity .22s ease, transform .22s ease";
        toast.style.zIndex = "100003";
        toast.style.maxWidth = "min(92vw, 460px)";
        toast.style.padding = "10px 14px";
        toast.style.borderRadius = "12px";
        toast.style.background = "rgba(18,24,32,.96)";
        toast.style.color = "#fff";
        toast.style.border = "1px solid rgba(255,255,255,.14)";
        toast.style.boxShadow = "0 10px 24px rgba(0,0,0,.32)";
        toast.style.font = "700 13px/1.35 Inter,system-ui,sans-serif";
        toast.style.textAlign = "center";
        document.body.appendChild(toast);
      }

      toast.textContent = text || "";
      toast.style.opacity = "1";
      toast.style.transform = "translateX(-50%) translateY(0)";
      clearTimeout(window.__wpSyncToastTimer);
      window.__wpSyncToastTimer = setTimeout(function() {
        toast.style.opacity = "0";
        toast.style.transform = "translateX(-50%) translateY(10px)";
      }, 3200);
    }

    window.addEventListener("load", function() {
      ensureStandaloneSourceParam();
      navigator.serviceWorker.register("/sw.js").then(function(reg) {
        announceAppClient(reg);

        function activateWaitingWorker() {
          if (reg.waiting) {
            reg.waiting.postMessage({ type: "SKIP_WAITING" });
          }
        }

        reg.addEventListener("updatefound", function() {
          var newWorker = reg.installing;
          if (!newWorker) return;
          newWorker.addEventListener("statechange", function() {
            if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
              activateWaitingWorker();
            }
          });
        });

        if (navigator.onLine) reg.update();
        window.addEventListener("online", function() {
          reg.update();
          announceAppClient(reg);
        });
      }).catch(function(err) {
        console.error("Service worker registration failed", err);
      });
    });

    navigator.serviceWorker.addEventListener("controllerchange", function() {
      if (window.__wpSwReloading) return;
      window.__wpSwReloading = true;
      window.location.reload();
    });

    window.addEventListener("pageshow", function() {
      if (!isStandaloneMode()) return;
      ensureStandaloneSourceParam();
      navigator.serviceWorker.ready.then(function(reg) {
        announceAppClient(reg);
      }).catch(function() {});
    });

    navigator.serviceWorker.addEventListener("message", function(event) {
      var data = event && event.data ? event.data : null;
      var pendingVersion = null;
      var onlineTransitionAt = 0;
      var onlineTriggered = false;
      var toastKey = "";

      if (data && data.type === "DATA_SYNC" && data.synced_at) {
        try {
          localStorage.setItem("wp_last_sync_at", data.synced_at);
        } catch (e) {
          // ignore localStorage errors
        }
        if (!isStandaloneMode()) return;
        if (!data.full_library) return;

        try {
          pendingVersion = localStorage.getItem("wp_pending_app_version");
        } catch (e) {}

        try {
          onlineTransitionAt = Number(sessionStorage.getItem("wp_last_online_transition_at") || "0");
        } catch (e) {}

        onlineTriggered = !!onlineTransitionAt && (Date.now() - onlineTransitionAt) < 20000;
        if (!pendingVersion && !onlineTriggered) return;

        if (onlineTriggered) {
          try {
            sessionStorage.removeItem("wp_last_online_transition_at");
          } catch (e) {}
        }

        toastKey = "app-full-sync:" + String(data.synced_at);
        if (window.__wpLastSyncToastKey === toastKey) return;
        window.__wpLastSyncToastKey = toastKey;

        showSyncToast(data.synced_at, "Ծրագիրը ամբողջությամբ թարմացվեց օֆֆլայն աշխատանքի համար։");
      }
    });
  }

  (function setupGlobalNetworkNotice() {
    function syncLibraryChip(mode) {
      var chip = document.getElementById("wpAppLibraryChip");
      if (!chip) return;
      chip.textContent = mode === "offline" ? "Օֆֆլայն գրադարան" : "Առցանց գրադարան";
    }

    function syncAppStatusChip(isOnline) {
      var chip = document.getElementById("wpAppOnlineChip");
      if (!chip) return;
      chip.textContent = isOnline ? "Առցանց" : "Օֆֆլայն";
      chip.classList.toggle("status-online", !!isOnline);
      chip.classList.toggle("status-offline", !isOnline);
    }

    function ensureNotice() {
      var existing = document.getElementById("wpNetNotice");
      if (existing) return existing;

      var styleId = "wpNetNoticeStyles";
      if (!document.getElementById(styleId)) {
        var style = document.createElement("style");
        style.id = styleId;
        style.textContent =
          ".wp-net-notice{position:fixed;left:50%;bottom:16px;transform:translateX(-50%) translateY(10px);opacity:0;z-index:100002;background:rgba(18,24,32,.96);color:#fff;border:1px solid rgba(255,255,255,.14);border-radius:12px;padding:10px 14px;font:700 13px/1.35 Inter,system-ui,sans-serif;box-shadow:0 10px 24px rgba(0,0,0,.32);transition:opacity .2s ease,transform .2s ease;max-width:min(92vw,420px);text-align:center}" +
          ".wp-net-notice.show{opacity:1;transform:translateX(-50%) translateY(0)}";
        document.head.appendChild(style);
      }

      var notice = document.createElement("div");
      notice.id = "wpNetNotice";
      notice.className = "wp-net-notice";
      notice.style.bottom = getFloatingOverlayBottomOffset() + "px";
      document.body.appendChild(notice);
      return notice;
    }

    var hideTimer = null;
    function showNotice(text, autoHide) {
      var notice = ensureNotice();
      notice.style.bottom = getFloatingOverlayBottomOffset() + "px";
      notice.textContent = text;
      notice.classList.add("show");
      if (hideTimer) clearTimeout(hideTimer);
      if (autoHide) {
        hideTimer = setTimeout(function() {
          notice.classList.remove("show");
        }, 2500);
      }
    }

    function showOffline() {
      syncAppStatusChip(false);
      showNotice("Ինտերնետ կապը բացակայում է։ Աշխատում եք օֆֆլայն ռեժիմում։", true);
    }

    function showOnline() {
      syncAppStatusChip(true);
      showNotice("Ինտերնետ կապը վերականգնվել է։", true);
    }

    function markOnlineTransition() {
      try {
        sessionStorage.setItem("wp_last_online_transition_at", String(Date.now()));
      } catch (e) {
        // ignore
      }
    }

    window.addEventListener("offline", showOffline);
    window.addEventListener("online", function() {
      markOnlineTransition();
      showOnline();
    });
    if (!navigator.onLine) showOffline();
    else syncAppStatusChip(true);

    window.WP = window.WP || {};
    window.WP.setLibraryMode = function(mode) {
      syncLibraryChip(mode);
    };
  })();


  (function setupInstalledOfflineLibrarySync() {
    function requestOfflineLibrarySync() {
      if (!("serviceWorker" in navigator)) return;
      if (!isStandaloneMode()) return;
      if (!navigator.onLine) return;
  
      navigator.serviceWorker.ready.then(function(reg) {
        if (reg.active) {
          reg.active.postMessage({ type: "SYNC_OFFLINE_LIBRARY" });
        }
      }).catch(function(err) {
        console.error("Offline library sync request failed", err);
      });
    }
  
    window.addEventListener("load", requestOfflineLibrarySync);
    window.addEventListener("online", requestOfflineLibrarySync);
  })();


  (function setupInstallPrompt() {
    var deferredPrompt = null;
    var storageKey = "wp_install_prompt_hidden";
    var confirmedKey = "wp_install_confirmed";
    var iosIntentKey = "wp_install_ios_intent";
    var lastStandaloneSeenKey = "wp_install_last_standalone_seen_at";
    var staleInstallMs = 7 * 24 * 60 * 60 * 1000;

    function isStandaloneMode() {
      return isStandaloneAppMode();
    }

    function isIosInstallMode() {
      var ua = window.navigator.userAgent || "";
      var isIos = /iphone|ipad|ipod/i.test(ua);
      var isSafari = /safari/i.test(ua) && !/crios|fxios|edgios/i.test(ua);
      return isIos && isSafari;
    }

    function ensureStyles() {
      if (document.getElementById("wpInstallStyles")) return;
      var style = document.createElement("style");
      style.id = "wpInstallStyles";
      style.textContent =
        ".wp-install{position:fixed;left:16px;right:16px;bottom:16px;z-index:100001;display:none;justify-content:space-between;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;background:rgba(18,24,32,.96);color:#fff;border:1px solid rgba(255,255,255,.14);box-shadow:0 12px 30px rgba(0,0,0,.35);font-family:Inter,system-ui,sans-serif}" +
        ".wp-install.show{display:flex}" +
        ".wp-install-text{font-size:13px;font-weight:700;line-height:1.3}" +
        ".wp-install-actions{display:flex;gap:8px;flex:0 0 auto}" +
        ".wp-install button{border:0;border-radius:10px;padding:8px 10px;cursor:pointer;font-weight:700;font-size:12px}" +
        ".wp-install-install{background:linear-gradient(135deg,#6b4eff,#f6c87a);color:#fff}" +
        ".wp-install-close{background:rgba(255,255,255,.14);color:#fff}" +
        "@media (min-width: 860px){.wp-install{left:auto;right:16px;max-width:360px}}";
      document.head.appendChild(style);
    }

    function ensureBanner() {
      var existing = document.getElementById("wpInstallBanner");
      if (existing) return existing;
      ensureStyles();
      var banner = document.createElement("div");
      banner.id = "wpInstallBanner";
      banner.className = "wp-install";
      banner.innerHTML =
        '<div class="wp-install-text">Ներբեռնեք Worship Platform ծրագիրը արագ մուտքի համար։</div>' +
        '<div class="wp-install-actions">' +
        '  <button class="wp-install-close" type="button" aria-label="Փակել">Հետո</button>' +
        '  <button class="wp-install-install" type="button">Ներբեռնել</button>' +
        "</div>";
      document.body.appendChild(banner);
      return banner;
    }

    function resetInstallPromptState() {
      try {
        localStorage.removeItem(storageKey);
        localStorage.removeItem(confirmedKey);
        localStorage.removeItem(iosIntentKey);
      } catch (err) {}
    }

    function shouldReofferInstall() {
      try {
        if (localStorage.getItem(confirmedKey) !== "1") {
          return false;
        }
        var lastSeen = Number(localStorage.getItem(lastStandaloneSeenKey) || "0");
        if (!lastSeen) {
          return true;
        }
        return (Date.now() - lastSeen) > staleInstallMs;
      } catch (err) {
        return false;
      }
    }

    function showPromptUI() {
      if (isStandaloneMode()) return;
      if (isAuthProgramPage()) return;
      if (shouldReofferInstall()) {
        resetInstallPromptState();
      }
      if (localStorage.getItem(storageKey) === "1") return;
      if (!deferredPrompt && !isIosInstallMode()) return;

      var banner = ensureBanner();
      var installBtn = banner.querySelector(".wp-install-install");
      var closeBtn = banner.querySelector(".wp-install-close");
      var text = banner.querySelector(".wp-install-text");
      if (!installBtn || !closeBtn) return;
      banner.style.bottom = getFloatingOverlayBottomOffset() + "px";

      if (text) {
        text.textContent = isIosInstallMode()
          ? "Ներբեռնեք ծրագիրը Safari-ի միջոցով և պահեք այն որպես առանձին հավելված։"
          : "Ներբեռնեք Worship Platform ծրագիրը արագ մուտքի համար։";
      }

      banner.classList.add("show");

      closeBtn.onclick = function() {
        localStorage.setItem(storageKey, "1");
        banner.classList.remove("show");
      };

      installBtn.onclick = async function() {
        if (!deferredPrompt && isIosInstallMode()) {
          try {
            localStorage.setItem(iosIntentKey, "1");
          } catch (err) {}
          window.alert("Safari-ում սեղմեք Share և ընտրեք Add to Home Screen։");
          return;
        }

        try {
          deferredPrompt.prompt();
          var choice = await deferredPrompt.userChoice;
          if (choice && choice.outcome === "accepted") {
            try {
              localStorage.setItem(confirmedKey, "1");
            } catch (err) {}
            banner.classList.remove("show");
          }
        } catch (err) {
          console.error("Install prompt failed", err);
        } finally {
          deferredPrompt = null;
        }
      };
    }

    window.addEventListener("beforeinstallprompt", function(e) {
      e.preventDefault();
      deferredPrompt = e;
      resetInstallPromptState();
      showPromptUI();
    });

    window.addEventListener("load", function() {
      showPromptUI();
    });

    window.addEventListener("appinstalled", function() {
      var banner = document.getElementById("wpInstallBanner");
      if (banner) banner.classList.remove("show");
      deferredPrompt = null;
      localStorage.removeItem(storageKey);
      try {
        localStorage.setItem(confirmedKey, "1");
        localStorage.removeItem(iosIntentKey);
      } catch (err) {}
    });
  })();

  (function setupOpenInAppPrompt() {
    if (isStandaloneAppMode()) return;
    if (isAuthProgramPage()) return;
    if (!isPageAppEnabled()) return;
    if (!isLikelyPhoneBrowser()) return;

    var hideKey = "wp_open_app_hidden_session";
    var cacheKey = "wp_open_app_detection_cache_v1";
    var cacheTtlMs = 6 * 60 * 60 * 1000;
    var confirmedKey = "wp_install_confirmed";
    var lastStandaloneSeenKey = "wp_install_last_standalone_seen_at";
    var hintTtlMs = 45 * 24 * 60 * 60 * 1000;

    function ensureStyles() {
      if (document.getElementById("wpOpenAppStyles")) return;
      var style = document.createElement("style");
      style.id = "wpOpenAppStyles";
      style.textContent =
        ".wp-open-app{position:fixed;left:16px;right:16px;bottom:16px;z-index:100001;display:none;justify-content:space-between;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;background:rgba(11,17,31,.94);color:#eef3ff;border:1px solid rgba(255,255,255,.12);box-shadow:0 16px 34px rgba(0,0,0,.28);backdrop-filter:blur(16px) saturate(130%);-webkit-backdrop-filter:blur(16px) saturate(130%);font-family:Inter,system-ui,sans-serif}" +
        ".wp-open-app.show{display:flex}" +
        ".wp-open-app-copy{display:flex;flex-direction:column;gap:4px;min-width:0}" +
        ".wp-open-app-kicker{font-size:11px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#8ea1ff}" +
        ".wp-open-app-text{font-size:13px;font-weight:700;line-height:1.35;color:#eef3ff}" +
        ".wp-open-app-actions{display:flex;gap:8px;flex:0 0 auto}" +
        ".wp-open-app-launch,.wp-open-app-close{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:9px 12px;cursor:pointer;text-decoration:none;font:800 12px/1 Inter,system-ui,sans-serif;white-space:nowrap}" +
        ".wp-open-app-launch{background:linear-gradient(135deg,#6b7cff,#8ea1ff);color:#fff;box-shadow:0 10px 20px rgba(82,104,228,.24)}" +
        ".wp-open-app-close{background:rgba(255,255,255,.1);color:#eef3ff}" +
        "@media (min-width: 860px){.wp-open-app{left:auto;right:16px;max-width:392px}}" +
        "@media (max-width: 720px){.wp-open-app{padding:11px 12px;gap:8px}.wp-open-app-text{font-size:12px}.wp-open-app-launch,.wp-open-app-close{padding:8px 10px;font-size:12px}}";
      document.head.appendChild(style);
    }

    function ensureBanner() {
      var existing = document.getElementById("wpOpenAppBanner");
      if (existing) return existing;
      ensureStyles();
      var banner = document.createElement("div");
      banner.id = "wpOpenAppBanner";
      banner.className = "wp-open-app";
      banner.innerHTML =
        '<div class="wp-open-app-copy">' +
        '  <div class="wp-open-app-kicker">Ծրագիրը տեղադրված է</div>' +
        '  <div class="wp-open-app-text">Եթե ուզում ես, այս էջը կարող ես բացել Worship ծրագրի մեջ։</div>' +
        '</div>' +
        '<div class="wp-open-app-actions">' +
        '  <button class="wp-open-app-close" type="button">Փակել</button>' +
        '  <a class="wp-open-app-launch" href="/">Բացել ծրագրում</a>' +
        '</div>';
      document.body.appendChild(banner);
      return banner;
    }

    function readCachedDetection() {
      try {
        var raw = localStorage.getItem(cacheKey);
        if (!raw) return null;
        var parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object") return null;
        if (!parsed.expires_at || parsed.expires_at < Date.now()) return null;
        return parsed.value === true;
      } catch (err) {
        return null;
      }
    }

    function writeCachedDetection(value) {
      try {
        localStorage.setItem(cacheKey, JSON.stringify({
          value: !!value,
          expires_at: Date.now() + cacheTtlMs
        }));
      } catch (err) {
        // ignore storage issues
      }
    }

    function hasRecentStandaloneHint() {
      try {
        if (localStorage.getItem(confirmedKey) !== "1") return false;
        var lastSeen = Number(localStorage.getItem(lastStandaloneSeenKey) || "0");
        return !!lastSeen && (Date.now() - lastSeen) <= hintTtlMs;
      } catch (err) {
        return false;
      }
    }

    function isInstalledWebAppMatch(app) {
      if (!app || typeof app !== "object") return false;
      var platform = String(app.platform || "").toLowerCase();
      var appId = String(app.id || "");
      var appUrl = String(app.url || "");
      if (platform !== "webapp") return false;
      if (appId === "/main.html?source=pwa") return true;
      return /\/manifest\.json(?:$|\?)/i.test(appUrl);
    }

    async function detectInstalledApp() {
      var cached = readCachedDetection();
      if (cached !== null) return cached;

      var installed = false;

      if (typeof navigator.getInstalledRelatedApps === "function") {
        try {
          var relatedApps = await navigator.getInstalledRelatedApps();
          installed = Array.isArray(relatedApps) && relatedApps.some(isInstalledWebAppMatch);
        } catch (err) {
          installed = false;
        }
      }

      if (!installed && hasRecentStandaloneHint()) {
        installed = true;
      }

      writeCachedDetection(installed);
      return installed;
    }

    function buildCanonicalAppUrl() {
      try {
        var url = new URL(window.location.href);
        url.searchParams.delete("source");
        return url.toString();
      } catch (err) {
        return window.location.href;
      }
    }

    function positionBanner(banner) {
      banner.style.bottom = getFloatingOverlayBottomOffset() + "px";
    }

    function showBanner() {
      try {
        if (sessionStorage.getItem(hideKey) === "1") return;
      } catch (err) {}

      var banner = ensureBanner();
      var launch = banner.querySelector(".wp-open-app-launch");
      var close = banner.querySelector(".wp-open-app-close");
      if (!launch || !close) return;

      launch.href = buildCanonicalAppUrl();
      positionBanner(banner);
      banner.classList.add("show");

      close.onclick = function() {
        try {
          sessionStorage.setItem(hideKey, "1");
        } catch (err) {}
        banner.classList.remove("show");
      };
    }

    function hideBanner() {
      var banner = document.getElementById("wpOpenAppBanner");
      if (banner) {
        banner.classList.remove("show");
      }
    }

    async function refreshOpenInAppPrompt() {
      if (isStandaloneAppMode() || !isPageAppEnabled() || !isLikelyPhoneBrowser()) {
        hideBanner();
        return;
      }

      var installed = await detectInstalledApp();
      if (installed) {
        showBanner();
      } else {
        hideBanner();
      }
    }

    window.addEventListener("load", function() {
      refreshOpenInAppPrompt();
    });
    window.addEventListener("pageshow", function() {
      refreshOpenInAppPrompt();
    });
    window.addEventListener("resize", function() {
      var banner = document.getElementById("wpOpenAppBanner");
      if (banner && banner.classList.contains("show")) {
        positionBanner(banner);
      }
    });
  })();

  (function setupInstallTracking() {
    if (!("fetch" in window)) return;

    var deviceKey = "wp_install_device_id";
    var deviceCookieKey = "wp_install_device_id";
    var deviceSignatureCookieKey = "wp_install_device_sig";
    var pingKey = "wp_install_last_ping_at";
    var confirmedKey = "wp_install_confirmed";
    var iosIntentKey = "wp_install_ios_intent";
    var lastStandaloneSeenKey = "wp_install_last_standalone_seen_at";
    var pingInterval = 12 * 60 * 60 * 1000;

    function isStandaloneMode() {
      return isStandaloneAppMode();
    }

    function escapeCookieName(name) {
      return String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function readCookie(name) {
      try {
        var match = document.cookie.match(new RegExp('(?:^|; )' + escapeCookieName(name) + '=([^;]*)'));
        return match ? decodeURIComponent(match[1]) : "";
      } catch (e) {
        return "";
      }
    }

    function writeCookie(name, value, days) {
      try {
        var maxAge = Math.max(1, Math.floor((days || 3650) * 24 * 60 * 60));
        document.cookie = name + "=" + encodeURIComponent(value) + "; path=/; max-age=" + maxAge + "; SameSite=Lax";
      } catch (e) {
        // ignore cookie errors
      }
    }

    function getDeviceId() {
      try {
        var existing = localStorage.getItem(deviceKey);
        if (existing) {
          writeCookie(deviceCookieKey, existing, 3650);
          return existing;
        }
        var cookieValue = readCookie(deviceCookieKey);
        if (cookieValue) {
          localStorage.setItem(deviceKey, cookieValue);
          return cookieValue;
        }
        var next = (window.crypto && crypto.randomUUID ? crypto.randomUUID() : ("wp-" + Math.random().toString(36).slice(2) + Date.now()));
        localStorage.setItem(deviceKey, next);
        writeCookie(deviceCookieKey, next, 3650);
        return next;
      } catch (e) {
        var fallbackCookie = readCookie(deviceCookieKey);
        if (fallbackCookie) return fallbackCookie;
        var fallback = "wp-" + Math.random().toString(36).slice(2) + Date.now();
        writeCookie(deviceCookieKey, fallback, 3650);
        return fallback;
      }
    }

    function hasConfirmedInstall() {
      try {
        if (isStandaloneMode()) {
          localStorage.setItem(confirmedKey, "1");
          localStorage.removeItem(iosIntentKey);
          return true;
        }

        if (localStorage.getItem(confirmedKey) === "1") {
          return true;
        }

        if (window.navigator.standalone === true && localStorage.getItem(iosIntentKey) === "1") {
          localStorage.setItem(confirmedKey, "1");
          localStorage.removeItem(iosIntentKey);
          return true;
        }
      } catch (e) {
        return false;
      }

      return false;
    }

    function shouldPing() {
      try {
        var last = Number(localStorage.getItem(pingKey) || "0");
        return !last || (Date.now() - last) > pingInterval;
      } catch (e) {
        return true;
      }
    }

    function markPinged() {
      try {
        localStorage.setItem(pingKey, String(Date.now()));
      } catch (e) {
        // ignore
      }
    }

    function markStandaloneSeen() {
      try {
        localStorage.setItem(lastStandaloneSeenKey, String(Date.now()));
      } catch (e) {
        // ignore
      }
    }

    function getInstallSignature() {
      try {
        var screenInfo = window.screen || {};
        var nav = window.navigator || {};
        var tz = "";
        try {
          tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
        } catch (err) {}

        var signatureParts = [
          "scope:main",
          "ua:" + (nav.userAgent || ""),
          "platform:" + (nav.platform || ""),
          "lang:" + (nav.language || ""),
          "langs:" + ((nav.languages || []).join(",")),
          "touch:" + String(nav.maxTouchPoints || 0),
          "cpu:" + String(nav.hardwareConcurrency || 0),
          "mem:" + String(nav.deviceMemory || 0),
          "screen:" + [screenInfo.width || 0, screenInfo.height || 0, screenInfo.colorDepth || 0].join("x"),
          "viewport:" + [window.innerWidth || 0, window.innerHeight || 0].join("x"),
          "dpr:" + String(window.devicePixelRatio || 1),
          "tz:" + tz
        ].join("|");

        var hash = 2166136261;
        for (var i = 0; i < signatureParts.length; i++) {
          hash ^= signatureParts.charCodeAt(i);
          hash = Math.imul(hash, 16777619);
        }

        var signature = ("00000000" + (hash >>> 0).toString(16)).slice(-8) + ("00000000" + signatureParts.length.toString(16)).slice(-8);
        writeCookie(deviceSignatureCookieKey, signature, 3650);
        return signature;
      } catch (err) {
        return "";
      }
    }

    function registerInstall(options) {
      options = options || {};
      var force = !!options.force;
      if (!isStandaloneMode() || !hasConfirmedInstall() || !navigator.onLine) return;
      markStandaloneSeen();
      if (!force && !shouldPing()) return;

      fetch("/install_api.php?action=register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-WP-App-Scope": "main",
          "X-WP-Install-Mode": "standalone"
        },
        credentials: "same-origin",
        keepalive: true,
        body: JSON.stringify({
          scope: "main",
          source: "main-app-verified",
          device_id: getDeviceId(),
          device_signature: getInstallSignature()
        })
      }).then(function(response) {
        if (response && response.ok) {
          markPinged();
        }
      }).catch(function() {
        // ignore network errors
      });
    }

    function syncInstallIdentity() {
      if (!isStandaloneMode() || !hasConfirmedInstall() || !navigator.onLine) return Promise.resolve(false);

      return fetch("/install_identity_api.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "same-origin",
        keepalive: true,
        body: JSON.stringify({
          source: getExpectedAppSource(),
          device_signature: getInstallSignature()
        })
      }).then(function(response) {
        if (response && response.ok) {
          markStandaloneSeen();
          markPinged();
          return true;
        }
        return false;
      }).catch(function() {
        return false;
      });
    }

    window.WPInstallTracker = window.WPInstallTracker || {};
    window.WPInstallTracker.forceSyncCurrentInstall = function() {
      syncInstallIdentity().then(function(ok) {
        if (!ok) {
          registerInstall({ force: true });
        }
      });
    };

    window.addEventListener("load", function() {
      if (isStandaloneMode()) {
        markStandaloneSeen();
      }
      setTimeout(function() {
        registerInstall({ force: true });
      }, 900);
    });
    window.addEventListener("online", registerInstall);
    window.addEventListener("appinstalled", function() {
      setTimeout(function() {
        registerInstall({ force: true });
      }, 1200);
    });
  })();

  (function setupPushPrompt() {
    if (!("Notification" in window) || !("serviceWorker" in navigator) || !("PushManager" in window)) return;

    var config = null;
    var sessionHideKey = "wp_push_prompt_hidden_session";
    var disabledKey = "wp_push_prompt_disabled";
    var accountDisabledKey = "wp_push_account_disabled";
    var autoAttemptKey = "wp_push_auto_attempted";
    var adminRemovedKey = "wp_push_admin_removed";
    var appConfirmedKey = "wp_install_confirmed";

    function hasConfirmedAppInstall() {
      try {
        return isStandaloneMode() || localStorage.getItem(appConfirmedKey) === "1";
      } catch (err) {
        return isStandaloneMode();
      }
    }

    async function cleanupWebsiteOnlySubscription() {
      try {
        var registration = await navigator.serviceWorker.ready;
        var subscription = await registration.pushManager.getSubscription();
        if (!subscription) return;

        await fetch("/push_api.php?action=unsubscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify({ endpoint: subscription.endpoint })
        });

        await subscription.unsubscribe();
      } catch (err) {
        console.error("Website push cleanup failed", err);
      }
    }

    if (!isStandaloneMode()) {
      if (!hasConfirmedAppInstall()) {
        window.addEventListener("load", function() {
          cleanupWebsiteOnlySubscription();
        });
      }
      return;
    }

    function ensureStyles() {
      if (document.getElementById("wpPushStyles")) return;
      var style = document.createElement("style");
      style.id = "wpPushStyles";
        style.textContent =
        ".wp-push{position:fixed;left:16px;right:16px;bottom:88px;z-index:100000;display:none;justify-content:space-between;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;background:rgba(18,24,32,.96);color:#fff;border:1px solid rgba(255,255,255,.14);box-shadow:0 12px 30px rgba(0,0,0,.35);font-family:Inter,system-ui,sans-serif}" +
        ".wp-push.show{display:flex}" +
        ".wp-push-text{font-size:13px;font-weight:700;line-height:1.35}" +
        ".wp-push-actions{display:flex;gap:8px;flex:0 0 auto}" +
        ".wp-push button{border:0;border-radius:10px;padding:8px 10px;cursor:pointer;font-weight:700;font-size:12px}" +
        ".wp-push-enable{background:linear-gradient(135deg,#18a957,#6b7cff);color:#fff}" +
        ".wp-push-close{background:rgba(255,255,255,.14);color:#fff}" +
        "@media (min-width: 860px){.wp-push{left:auto;right:16px;max-width:390px}}" +
        "body.wp-main-app .wp-push{left:50%;right:auto;transform:translateX(-50%);width:min(420px,calc(100vw - 36px));max-width:none}" +
        "body.wp-main-app .wp-push-text{flex:1 1 auto}" +
        "body.wp-main-app .wp-push-actions{align-self:flex-end}" +
        "@media (max-width:720px){body.wp-main-app .wp-push{width:min(340px,calc(100vw - 24px));padding:11px 12px;gap:8px}body.wp-main-app .wp-push-text{font-size:12px}body.wp-main-app .wp-push button{padding:8px 9px;font-size:12px}}";
      document.head.appendChild(style);
    }

    function ensureBanner() {
      var existing = document.getElementById("wpPushBanner");
      if (existing) {
        applyBannerLayout(existing);
        return existing;
      }
      ensureStyles();
      var banner = document.createElement("div");
      banner.id = "wpPushBanner";
      banner.className = "wp-push";
      banner.innerHTML =
        '<div class="wp-push-text">Ցանկանո՞ւմ եք միացնել push հաղորդագրությունները, որպեսզի ստանաք նորությունները, թարմացումներն ու հայտարարությունները։</div>' +
        '<div class="wp-push-actions">' +
        '  <button class="wp-push-close" type="button">Հետո</button>' +
        '  <button class="wp-push-enable" type="button">Միացնել</button>' +
        "</div>";
      document.body.appendChild(banner);
      applyBannerLayout(banner);
      return banner;
    }

    function applyBannerLayout(banner) {
      if (!banner) return;
      if (document.body && document.body.classList.contains("wp-main-app")) {
        var compact = !!(window.matchMedia && window.matchMedia("(max-width: 720px)").matches);
        banner.style.position = "fixed";
        banner.style.left = "50%";
        banner.style.right = "auto";
        banner.style.transform = "translateX(-50%)";
        banner.style.width = compact ? "min(340px, calc(100vw - 24px))" : "min(420px, calc(100vw - 36px))";
        banner.style.maxWidth = "none";
        banner.style.margin = "0";
      }
    }

    function setAdminRemoved(flag) {
      try {
        if (flag) {
          localStorage.setItem(adminRemovedKey, "1");
        } else {
          localStorage.removeItem(adminRemovedKey);
        }
      } catch (err) {}
    }

    function isAdminRemoved() {
      try {
        return localStorage.getItem(adminRemovedKey) === "1";
      } catch (err) {
        return false;
      }
    }

    function urlBase64ToUint8Array(base64String) {
      var padding = "=".repeat((4 - (base64String.length % 4)) % 4);
      var base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
      var rawData = window.atob(base64);
      var outputArray = new Uint8Array(rawData.length);
      for (var i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
      }
      return outputArray;
    }

    async function fetchConfig() {
      if (config) return config;
      try {
        var res = await fetch("/push_api.php?action=config", { cache: "no-store" });
        if (!res.ok) return null;
        config = await res.json();
        return config;
      } catch (err) {
        return null;
      }
    }

    async function handleAdminDisabled(subscription) {
      try {
        if (subscription) {
          await subscription.unsubscribe();
        }
      } catch (err) {
        console.error("Push local unsubscribe failed", err);
      }

      setAdminRemoved(true);
      setUserDisabled(false);
      setSessionHidden(false);
      hideBanner();
      setTimeout(function() {
        showBannerIfNeeded();
      }, 500);
    }

    async function registerSubscription(forceEnable) {
      var currentConfig = await fetchConfig();
      if (!currentConfig || !currentConfig.enabled || !currentConfig.publicKey) return false;

      try {
        var registration = await navigator.serviceWorker.ready;
        var subscription = await registration.pushManager.getSubscription();
        if (!subscription && !forceEnable) {
          return false;
        }
        if (!subscription) {
          subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(currentConfig.publicKey)
          });
        }

        var response = await fetch("/push_api.php?action=subscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify({
            subscription: subscription.toJSON(),
            force_enable: !!forceEnable
          })
        });
        var result = null;
        try {
          result = await response.json();
        } catch (err) {}

        if (!response.ok || !result || !result.ok) {
          if (result && result.disabled_by_admin) {
            await handleAdminDisabled(subscription);
          }
          return false;
        }
        setAdminRemoved(false);
        return true;
      } catch (err) {
        console.error("Push subscribe failed", err);
        return false;
      }
    }

    async function unregisterSubscription() {
      try {
        var registration = await navigator.serviceWorker.ready;
        var subscription = await registration.pushManager.getSubscription();
        if (!subscription) return true;

        await fetch("/push_api.php?action=unsubscribe", {
          method: "POST",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify({ endpoint: subscription.endpoint })
        });

        await subscription.unsubscribe();
        return true;
      } catch (err) {
        console.error("Push unsubscribe failed", err);
        return false;
      }
    }

    function setSessionHidden(hidden) {
      try {
        if (hidden) {
          sessionStorage.setItem(sessionHideKey, "1");
        } else {
          sessionStorage.removeItem(sessionHideKey);
        }
      } catch (err) {}
    }

    function isSessionHidden() {
      try {
        return sessionStorage.getItem(sessionHideKey) === "1";
      } catch (err) {
        return false;
      }
    }

    function setUserDisabled(disabled) {
      try {
        if (disabled) {
          localStorage.setItem(disabledKey, "1");
        } else {
          localStorage.removeItem(disabledKey);
        }
      } catch (err) {}
    }

    function setAccountDisabled(disabled) {
      try {
        if (disabled) {
          localStorage.setItem(accountDisabledKey, "1");
        } else {
          localStorage.removeItem(accountDisabledKey);
        }
      } catch (err) {}
    }

    function isUserDisabled() {
      try {
        return localStorage.getItem(disabledKey) === "1";
      } catch (err) {
        return false;
      }
    }

    function isAccountDisabled() {
      try {
        return localStorage.getItem(accountDisabledKey) === "1";
      } catch (err) {
        return false;
      }
    }

    function hideBanner() {
      var banner = document.getElementById("wpPushBanner");
      if (banner) banner.classList.remove("show");
    }

    function clearPromptSuppression() {
      setSessionHidden(false);
      setUserDisabled(false);
    }

    function clearLegacyPromptSuppressionForApp() {
      if (!isStandaloneMode()) return;
      if (isAccountDisabled()) return;
      if (Notification.permission === "denied") return;

      try {
        sessionStorage.removeItem(sessionHideKey);
      } catch (err) {}

      try {
        localStorage.removeItem(disabledKey);
      } catch (err) {}
    }

    async function getStatus() {
      var currentConfig = await fetchConfig();
      var registration = null;
      var subscription = null;

      try {
        registration = await navigator.serviceWorker.ready;
        subscription = await registration.pushManager.getSubscription();
      } catch (err) {
        registration = null;
        subscription = null;
      }

      return {
        supported: !!currentConfig && !!currentConfig.supported,
        enabledBySite: !!currentConfig && !!currentConfig.enabled,
        permission: Notification.permission,
        subscribed: !!subscription,
        suppressed: isSessionHidden(),
        userDisabled: isUserDisabled(),
        accountDisabled: isAccountDisabled(),
        adminRemoved: isAdminRemoved()
      };
    }

    async function enablePush(options) {
      options = options || {};
      clearPromptSuppression();

      try {
        var permission = await Notification.requestPermission();
        if (permission === "granted") {
          setAccountDisabled(false);
          var ok = await registerSubscription(true);
          if (ok) hideBanner();
          return { ok: ok, permission: permission };
        }

        if (permission === "denied") {
          setUserDisabled(true);
          hideBanner();
        } else if (options.persistOnDecline) {
          setSessionHidden(true);
          hideBanner();
        }
        return { ok: false, permission: permission };
      } catch (err) {
        console.error("Push permission request failed", err);
        return { ok: false, permission: Notification.permission, error: err };
      }
    }

    async function disablePush() {
      setAccountDisabled(true);
      setUserDisabled(true);
      setSessionHidden(true);
      hideBanner();
      var ok = await unregisterSubscription();
      return { ok: ok, permission: Notification.permission };
    }

    async function showBannerIfNeeded() {
      if (isAuthProgramPage()) {
        hideBanner();
        return;
      }
      var currentConfig = await fetchConfig();
      if (!currentConfig || !currentConfig.enabled) return;
      if (Notification.permission === "denied") return;
      if (isAccountDisabled()) return;
      if (isUserDisabled()) return;
      if (isSessionHidden()) return;

      var adminRemoved = isAdminRemoved();
      var hasSubscription = false;
      try {
        var registration = await navigator.serviceWorker.ready;
        hasSubscription = !!(await registration.pushManager.getSubscription());
      } catch (err) {
        hasSubscription = false;
      }
      if (Notification.permission === "granted" && hasSubscription && !adminRemoved) return;

      var banner = ensureBanner();
      var text = banner.querySelector(".wp-push-text");
      applyBannerLayout(banner);
      banner.style.bottom = getFloatingOverlayBottomOffset() + "px";
      if (text) {
        text.textContent = adminRemoved
          ? "Push հաղորդագրությունները անջատվել են այս սարքի համար։ Ցանկանո՞ւմ եք նորից միացնել դրանք։"
          : (Notification.permission === "granted"
            ? "Ծանուցումների թույլտվությունը կա, բայց այս ծրագրում push-ը դեռ ակտիվ չէ։ Ցանկանո՞ւմ եք միացնել այն։"
            : "Ցանկանո՞ւմ եք միացնել push հաղորդագրությունները, որպեսզի ստանաք նորությունները, թարմացումներն ու հայտարարությունները։");
      }
      banner.classList.add("show");

      var enableBtn = banner.querySelector(".wp-push-enable");
      var closeBtn = banner.querySelector(".wp-push-close");

      if (closeBtn && !closeBtn.dataset.bound) {
        closeBtn.dataset.bound = "1";
        closeBtn.onclick = function() {
          setSessionHidden(true);
          hideBanner();
        };
      }

      if (enableBtn && !enableBtn.dataset.bound) {
        enableBtn.dataset.bound = "1";
        enableBtn.onclick = async function() {
          await enablePush({ persistOnDecline: true });
        };
      }
    }

    window.addEventListener("resize", function() {
      var banner = document.getElementById("wpPushBanner");
      if (!banner) return;
      applyBannerLayout(banner);
      banner.style.bottom = getFloatingOverlayBottomOffset() + "px";
    });

    async function tryAutomaticPrompt() {
      var currentConfig = await fetchConfig();
      if (!currentConfig || !currentConfig.enabled) return;
      if (Notification.permission !== "default") return;
      if (isAccountDisabled()) return;
      if (isUserDisabled() || isSessionHidden()) return;
      if (isAdminRemoved()) return;

      try {
        var lastAttempt = Number(localStorage.getItem(autoAttemptKey) || "0");
        var retryAfter = isStandaloneMode() ? (12 * 60 * 60 * 1000) : (24 * 60 * 60 * 1000);
        if (lastAttempt && (Date.now() - lastAttempt) < retryAfter) return;
        localStorage.setItem(autoAttemptKey, String(Date.now()));
      } catch (err) {}

      var result = await enablePush({ persistOnDecline: false });

      if (!result.ok && Notification.permission === "default") {
        setTimeout(function() {
          showBannerIfNeeded();
        }, 1200);
      }
    }

    window.WPPushManager = {
      getStatus: getStatus,
      enable: function() {
        return enablePush({ persistOnDecline: false });
      },
      disable: disablePush,
      registerSubscription: registerSubscription,
      showPrompt: showBannerIfNeeded,
      suppressPrompt: function() {
        setSessionHidden(true);
        hideBanner();
      },
      clearSuppression: clearPromptSuppression
    };

    window.addEventListener("load", async function() {
      var currentConfig = await fetchConfig();
      if (!currentConfig || !currentConfig.enabled) return;

      clearLegacyPromptSuppressionForApp();

      if (Notification.permission === "granted") {
        var registered = await registerSubscription(false);
        if (!registered) {
          setTimeout(function() {
            showBannerIfNeeded();
          }, 800);
        }
        return;
      }

      setTimeout(function() {
        tryAutomaticPrompt();
      }, isStandaloneMode() ? 600 : 900);

      setTimeout(function() {
        showBannerIfNeeded();
      }, isStandaloneMode() ? 1400 : 2200);
    });
  })();
})();
