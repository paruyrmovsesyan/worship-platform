<?php
declare(strict_types=1);

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

require_once __DIR__ . '/auth_bootstrap.php';

$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=pmstudio_wolarm;charset=utf8mb4",
        "pmstudio_wolarm",
        "wolarm2026",
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $currentSessionId = session_id();

    if (!empty($_SESSION['user_id'])) {
        $uid = (int)$_SESSION['user_id'];

        $st = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = ? AND session_key = ?");
        $st->execute([$uid, $currentSessionId]);
    }

    if (!empty($_COOKIE['remember_me'])) {
        $parts = explode(':', (string)$_COOKIE['remember_me'], 2);
        $selector = $parts[0] ?? '';

        if ($selector !== '') {
            $st = $pdo->prepare("DELETE FROM user_sessions WHERE selector = ?");
            $st->execute([$selector]);
        }
    }
} catch (Throwable $e) {
    // նույնիսկ եթե DB fail լինի, logout-ը շարունակում ենք
}

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires'  => time() - 42000,
        'path'     => $params['path'] ?? '/',
        'domain'   => $params['domain'] ?? '',
        'secure'   => !empty($params['secure']),
        'httponly' => !empty($params['httponly']),
        'samesite' => 'Lax',
    ]);
}

setcookie('remember_me', '', [
    'expires'  => time() - 3600,
    'path'     => '/',
    'domain'   => '',
    'secure'   => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);

if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

if (isset($_GET['silent']) && $_GET['silent'] === '1') {
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode(["ok" => true], JSON_UNESCAPED_UNICODE);
    exit;
}

$source = strtolower((string)($_GET['source'] ?? ''));
$target = '/loginuser.php?logged_out=1';
if ($source !== '') {
    $target .= '&source=' . urlencode($source);
}
header('Location: ' . $target);
exit;
