<?php
declare(strict_types=1);

require_once __DIR__ . '/runtime_config.php';

/*
|--------------------------------------------------------------------------
| Unified session bootstrap
|--------------------------------------------------------------------------
*/

$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('WORSHIPSESSID');

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');

    session_start();
}

if (!function_exists('wp_auth_clear_remember_cookie')) {
    function wp_auth_clear_remember_cookie(): void {
        $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        setcookie('remember_me', '', [
            'expires'  => time() - 3600,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        unset($_COOKIE['remember_me']);
    }
}

if (!function_exists('wp_auth_open_pdo')) {
    function wp_auth_open_pdo(): ?PDO {
        try {
            return wp_runtime_open_pdo();
        } catch (Throwable $e) {
            return null;
        }
    }
}

if (!function_exists('wp_auth_touch_current_session')) {
    function wp_auth_touch_current_session(PDO $pdo): void {
        if (empty($_SESSION['user_id'])) return;

        $sessionKey = session_id();
        if ($sessionKey === '') return;

        try {
            $stmt = $pdo->prepare("
                UPDATE user_sessions
                SET last_used_at = NOW()
                WHERE user_id = ?
                  AND session_key = ?
                ORDER BY id DESC
                LIMIT 1
            ");
            $stmt->execute([
                (int)$_SESSION['user_id'],
                $sessionKey
            ]);
        } catch (Throwable $e) {
            // silently ignore
        }
    }
}

if (!function_exists('wp_auth_fill_session_user')) {
    function wp_auth_fill_session_user(array $row): void {
        $_SESSION['user_id']  = (int)$row['id'];
        $_SESSION['email']    = (string)($row['email'] ?? '');
        $_SESSION['name']     = trim((string)($row['name'] ?? '')) ?: (string)($row['email'] ?? 'User');
        $_SESSION['username'] = trim((string)($row['username'] ?? '')) ?: $_SESSION['name'];
    }
}

if (!function_exists('wp_auth_user_id')) {
    function wp_auth_user_id(): int {
        return !empty($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
    }
}

if (!function_exists('wp_auth_is_logged_in')) {
    function wp_auth_is_logged_in(): bool {
        return wp_auth_user_id() > 0;
    }
}

if (!empty($_SESSION['user_id'])) {
    $pdo = wp_auth_open_pdo();
    if ($pdo) {
        wp_auth_touch_current_session($pdo);
    }
    return;
}

if (empty($_COOKIE['remember_me'])) {
    return;
}

$pdo = wp_auth_open_pdo();
if (!$pdo) {
    return;
}

$parts = explode(':', (string)$_COOKIE['remember_me'], 2);
if (count($parts) !== 2) {
    wp_auth_clear_remember_cookie();
    return;
}

[$selector, $validator] = $parts;

if ($selector === '' || $validator === '') {
    wp_auth_clear_remember_cookie();
    return;
}

try {
    $st = $pdo->prepare("
        SELECT
            s.id AS session_row_id,
            s.user_id,
            s.selector,
            s.token_hash,
            s.remembered,
            s.expires_at,
            u.id,
            u.name,
            u.email
        FROM user_sessions s
        INNER JOIN users u ON u.id = s.user_id
        WHERE s.selector = ?
          AND s.remembered = 1
          AND s.expires_at IS NOT NULL
          AND s.expires_at > NOW()
        LIMIT 1
    ");
    $st->execute([$selector]);
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        wp_auth_clear_remember_cookie();
        return;
    }

    $expectedHash = (string)($row['token_hash'] ?? '');
    $actualHash   = hash('sha256', $validator);

    if (!hash_equals($expectedHash, $actualHash)) {
        $del = $pdo->prepare("DELETE FROM user_sessions WHERE selector = ?");
        $del->execute([$selector]);
        wp_auth_clear_remember_cookie();
        return;
    }

   
    wp_auth_fill_session_user($row);
    $_SESSION['auth_via_remember'] = 1;

    $upd = $pdo->prepare("
        UPDATE user_sessions
        SET last_used_at = NOW(), session_key = ?
        WHERE id = ?
        LIMIT 1
    ");
    $upd->execute([session_id(), (int)$row['session_row_id']]);

} catch (Throwable $e) {
    // silently fail
    return;
}
