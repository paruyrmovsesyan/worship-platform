// fav_bridge.js
let _authCache = null;

function markSessionLoginFromUrl(){
  try{
    const params = new URLSearchParams(location.search);

    if(params.get('session_login') === '1'){
      sessionStorage.setItem('wp_session_login', '1');
    }

    if(params.get('session_login') === '0'){
      sessionStorage.removeItem('wp_session_login');
    }

    if(params.has('session_login')){
      params.delete('session_login');
      const cleanUrl =
        location.pathname +
        (params.toString() ? '?' + params.toString() : '') +
        location.hash;

      history.replaceState({}, '', cleanUrl);
    }
  }catch(e){}
}

async function enforceSessionCloseLogout(){
  return;
}

markSessionLoginFromUrl();

export async function getAuth(){
  if(_authCache) return _authCache;

  await enforceSessionCloseLogout();

  const r = await fetch('/auth_me.php', {
    credentials: 'include',
    cache: 'no-store'
  });

  _authCache = await r.json();
  return _authCache;
}

export async function favApiBase(){
  const a = await getAuth();
  return a.loggedIn ? '/user_favorites_api.php' : '/favorites_api.php';
}

export async function initNavbarAuthUI(){
  // next param՝ որպեսզի login/register-ից հետո վերադառնա նույն էջը
  const next = location.pathname + location.search + location.hash;

  const loginBtn    = document.getElementById('loginBtn');
  const registerBtn = document.getElementById('registerBtn');
  const userBox     = document.getElementById('userBox');
  const userName    = document.getElementById('userName');
  const logoutBtn   = document.getElementById('logoutBtn');

  // եթե loginBtn չկա՝ nav չկա
  if(!loginBtn && !registerBtn && !userBox) return;

  if(loginBtn)    loginBtn.href    = (window.WP && typeof window.WP.withAppSource === 'function')
    ? window.WP.withAppSource('/loginuser.php?next=' + encodeURIComponent(next))
    : '/loginuser.php?next=' + encodeURIComponent(next);
  if(registerBtn) registerBtn.href = (window.WP && typeof window.WP.withAppSource === 'function')
    ? window.WP.withAppSource('/registeruser.php?next=' + encodeURIComponent(next))
    : '/registeruser.php?next=' + encodeURIComponent(next);

  let a = { loggedIn:false };
  try{ a = await getAuth(); }catch(e){}

  if(a.loggedIn){
    if(loginBtn) loginBtn.style.display = 'none';
    if(registerBtn) registerBtn.style.display = 'none';

    if(userBox){
      userBox.style.display = 'flex';
      userBox.style.alignItems = 'center';
      userBox.style.gap = '10px';
    }
    if(userName) userName.textContent = a.user?.name || a.user?.username || a.user?.email || 'User';

    if(logoutBtn){
      logoutBtn.onclick = () => { window.location.href = '/logout_users.php'; };
    }
  }else{
    if(loginBtn) loginBtn.style.display = '';
    if(registerBtn) registerBtn.style.display = '';
    if(userBox) userBox.style.display = 'none';
  }

  // ✅ unlock page only when auth state is resolved
  document.getElementById('menu')?.classList.remove('auth-pending');
  window.PageLoader?.hide?.();
  document.documentElement.classList.remove('auth-lock');

}
