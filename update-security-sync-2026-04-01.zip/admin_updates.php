<?php
declare(strict_types=1);

require_once __DIR__ . '/admin_access.php';
require_once __DIR__ . '/release_manager.php';
require_once __DIR__ . '/push_service.php';
require_once __DIR__ . '/install_service.php';

$access = wp_admin_require_access('/admin_updates.php');
$adminUser = $access['user'];
$config = $access['config'];
$releaseTypes = wp_version_release_types();
$packageModes = wp_version_package_modes();
$pageAppRegistry = wp_version_page_app_registry();
$pushConfig = wp_push_bootstrap_config();
$pushStats = wp_push_stats();
$installStats = wp_install_stats();
$activeMainInstallDevices = wp_install_list_devices('main', true, 100);
$activeAdminInstallDevices = wp_install_list_devices('admin', true, 100);
$pushSubscriptions = wp_push_load_subscriptions();
$accessMode = (string)($adminUser['access_mode'] ?? 'modern');
$message = '';
$messageType = 'success';

if (!empty($_SESSION['admin_updates_flash']) && is_array($_SESSION['admin_updates_flash'])) {
    $message = (string)($_SESSION['admin_updates_flash']['message'] ?? '');
    $messageType = (string)($_SESSION['admin_updates_flash']['type'] ?? 'success');
    unset($_SESSION['admin_updates_flash']);
}

function wp_admin_updates_preserve_actor_access(array $payload, array $adminUser): array {
    $email = strtolower(trim((string)($adminUser['email'] ?? '')));
    if ($email === '') {
        return $payload;
    }

    $hasDirectAdminRole = false;
    if (!empty($adminUser['is_admin'])) {
        $hasDirectAdminRole = true;
    }

    $role = strtolower(trim((string)($adminUser['role'] ?? '')));
    if (in_array($role, ['admin', 'superadmin', 'super_admin', 'owner'], true)) {
        $hasDirectAdminRole = true;
    }

    if ($hasDirectAdminRole) {
        return $payload;
    }

    $admins = wp_version_sanitize_email_list($payload['admin_emails'] ?? []);
    if (!in_array($email, $admins, true)) {
        $admins[] = $email;
    }
    $payload['admin_emails'] = $admins;

    return $payload;
}

function wp_admin_updates_actor_label(array $adminUser): string {
    return (string)($adminUser['email'] ?? $adminUser['name'] ?? 'admin');
}

function wp_admin_updates_push_identity(array $subscription): string {
    $name = trim((string)($subscription['user_name'] ?? ''));
    $email = trim((string)($subscription['user_email'] ?? ''));

    if ($name !== '' && $email !== '') {
        return $name . ' · ' . $email;
    }

    if ($email !== '') {
        return $email;
    }

    if ($name !== '') {
        return $name;
    }

    return 'Չճանաչված սարք';
}

function wp_admin_updates_push_endpoint_host(string $endpoint): string {
    $host = (string)(parse_url($endpoint, PHP_URL_HOST) ?? '');
    return $host !== '' ? $host : '—';
}

function wp_admin_updates_push_ip(array $subscription): string {
    $ip = trim((string)($subscription['ip_address'] ?? ''));
    return $ip !== '' ? $ip : '—';
}

function wp_admin_updates_install_ip(array $device): string {
    $ip = trim((string)($device['ip_address'] ?? ''));
    return $ip !== '' ? $ip : '—';
}

function wp_admin_updates_install_identity(array $device): string {
    $name = trim((string)($device['user_name'] ?? ''));
    $username = trim((string)($device['user_username'] ?? ''));
    $email = trim((string)($device['user_email'] ?? ''));

    if ($name !== '' && $email !== '') {
        return $name . ' · ' . $email;
    }

    if ($email !== '') {
        return $email;
    }

    if ($name !== '') {
        return $name;
    }

    if ($username !== '') {
        return '@' . $username;
    }

    return 'Սարք ' . wp_install_mask_device_id((string)($device['device_id'] ?? ''));
}

function wp_admin_updates_install_link_status(array $device): string {
    $userId = (int)($device['user_id'] ?? 0);
    $name = trim((string)($device['user_name'] ?? ''));
    $username = trim((string)($device['user_username'] ?? ''));
    $email = trim((string)($device['user_email'] ?? ''));

    if ($userId > 0 || $name !== '' || $username !== '' || $email !== '') {
        return 'Կապված է օգտահաշվին';
    }

    return 'User կապ չկա';
}

function wp_admin_updates_install_secondary(array $device): string {
    $name = trim((string)($device['user_name'] ?? ''));
    $username = trim((string)($device['user_username'] ?? ''));
    $email = trim((string)($device['user_email'] ?? ''));

    $parts = [];
    if ($username !== '') {
        $parts[] = '@' . $username;
    }
    if ($email !== '') {
        $parts[] = $email;
    }
    if ($name !== '' && $email === '') {
        $parts[] = $name;
    }

    if ($parts) {
        return implode(' • ', $parts);
    }

    return 'Օգտահաշվի տվյալ չի կապվել';
}

function wp_admin_updates_install_platform(string $userAgent): string {
    $ua = strtolower($userAgent);
    if ($ua === '') {
        return 'Անհայտ սարք';
    }
    if (str_contains($ua, 'iphone')) return 'iPhone';
    if (str_contains($ua, 'ipad')) return 'iPad';
    if (str_contains($ua, 'android')) return 'Android';
    if (str_contains($ua, 'mac os x') || str_contains($ua, 'macintosh')) return 'macOS';
    if (str_contains($ua, 'windows')) return 'Windows';
    if (str_contains($ua, 'linux')) return 'Linux';
    return 'Այլ սարք';
}

function wp_admin_updates_install_browser(string $userAgent): string {
    $ua = strtolower($userAgent);
    if ($ua === '') {
        return 'Անհայտ';
    }
    if (str_contains($ua, 'edg/')) return 'Edge';
    if (str_contains($ua, 'opr/') || str_contains($ua, 'opera')) return 'Opera';
    if (str_contains($ua, 'chrome/') && !str_contains($ua, 'edg/')) return 'Chrome';
    if (str_contains($ua, 'firefox/')) return 'Firefox';
    if (str_contains($ua, 'safari/') && !str_contains($ua, 'chrome/')) return 'Safari';
    return 'Այլ browser';
}

function wp_admin_updates_history_action_label(string $action): string {
    $action = trim($action);
    return match ($action) {
        'publish_release' => 'Հրապարակել և տեղադրել',
        'save_release' => 'Պահպանել թարմացումը',
        'save_maintenance' => 'Պահպանել տեխնիկական աշխատանքները',
        'save_page_modes' => 'Պահպանել ծրագրային էջերը',
        'save_access' => 'Պահպանել մուտքերն ու նշումները',
        'rollback' => 'Վերականգնել տարբերակը',
        'bootstrap_admin' => 'Սկզբնական ադմին մուտք',
        'save_general', 'save' => 'Պահպանել',
        default => $action !== '' ? $action : 'Պահպանել',
    };
}

function wp_admin_updates_csrf_token(): string {
    if (empty($_SESSION['admin_updates_csrf']) || !is_string($_SESSION['admin_updates_csrf'])) {
        $_SESSION['admin_updates_csrf'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['admin_updates_csrf'];
}

function wp_admin_updates_verify_csrf(?string $token): bool {
    $sessionToken = (string)($_SESSION['admin_updates_csrf'] ?? '');
    $token = (string)($token ?? '');
    return $sessionToken !== '' && $token !== '' && hash_equals($sessionToken, $token);
}

function wp_admin_updates_build_release_push_payload(array $previousConfig, array $nextConfig, string $actorLabel): array {
    $appVersion = trim((string)($nextConfig['app_version'] ?? $previousConfig['app_version'] ?? ''));
    $webVersion = trim((string)($nextConfig['web_version'] ?? $previousConfig['web_version'] ?? ''));
    $appChanged = $appVersion !== '' && $appVersion !== trim((string)($previousConfig['app_version'] ?? ''));
    $webChanged = $webVersion !== '' && $webVersion !== trim((string)($previousConfig['web_version'] ?? ''));

    $title = trim((string)($nextConfig['app_title'] ?? ''));
    if (!$appChanged && $webChanged) {
        $title = trim((string)($nextConfig['web_title'] ?? $title));
    }
    if ($title === '') {
        $title = 'Առկա է թարմացում';
    }

    $versionParts = [];
    if ($appChanged) {
        $versionParts[] = 'Ծրագիր ' . $appVersion;
    }
    if ($webChanged) {
        $versionParts[] = 'Կայք ' . $webVersion;
    }
    if (!$versionParts) {
        if ($appVersion !== '') {
            $versionParts[] = 'Ծրագիր ' . $appVersion;
        }
        if ($webVersion !== '') {
            $versionParts[] = 'Կայք ' . $webVersion;
        }
    }

    $summary = trim((string)($nextConfig['app_release_summary'] ?? ''));
    if ($summary === '') {
        $summary = trim((string)($nextConfig['web_release_summary'] ?? ''));
    }

    $body = 'Worship Platform-ում առկա է նոր թարմացում։';
    if ($versionParts) {
        $body .= ' ' . implode(' • ', $versionParts) . '։';
    }
    if ($summary !== '') {
        $body .= ' ' . $summary;
    }

    return [
        'title' => mb_substr($title, 0, 160),
        'body' => mb_substr($body, 0, 600),
        'url' => '/main.html',
        'icon' => '/wolarm_youth.png',
        'tag' => 'worship-release-update',
        'actor' => $actorLabel,
    ];
}

function wp_admin_updates_prepare_release_stamps(array $currentConfig, array $nextConfig, bool $withPackage): array {
    $stamp = wp_version_now_iso();

    $appFields = ['app_version', 'app_release_type', 'app_release_summary', 'app_title', 'app_message'];
    $webFields = ['web_version', 'web_release_type', 'web_release_summary', 'web_title', 'web_message'];

    $appChanged = $withPackage;
    foreach ($appFields as $field) {
        if ((string)($nextConfig[$field] ?? $currentConfig[$field] ?? '') !== (string)($currentConfig[$field] ?? '')) {
            $appChanged = true;
            break;
        }
    }

    $webChanged = $withPackage;
    foreach ($webFields as $field) {
        if ((string)($nextConfig[$field] ?? $currentConfig[$field] ?? '') !== (string)($currentConfig[$field] ?? '')) {
            $webChanged = true;
            break;
        }
    }

    if ($appChanged) {
        $nextConfig['app_release_stamp'] = $stamp;
    }

    if ($webChanged) {
        $nextConfig['web_release_stamp'] = $stamp;
    }

    return $nextConfig;
}

function wp_admin_updates_collect_input(array $config): array {
    return [
        'app_version' => $_POST['app_version'] ?? '',
        'web_version' => $_POST['web_version'] ?? '',
        'app_release_type' => $_POST['app_release_type'] ?? '',
        'web_release_type' => $_POST['web_release_type'] ?? '',
        'app_release_summary' => $_POST['app_release_summary'] ?? '',
        'web_release_summary' => $_POST['web_release_summary'] ?? '',
        'app_title' => $_POST['app_title'] ?? '',
        'app_message' => $_POST['app_message'] ?? '',
        'web_title' => $_POST['web_title'] ?? '',
        'web_message' => $_POST['web_message'] ?? '',
        'maintenance_enabled' => !empty($_POST['maintenance_enabled']),
        'maintenance_message' => $_POST['maintenance_message'] ?? '',
        'maintenance_start_at' => $_POST['maintenance_start_at'] ?? '',
        'maintenance_end_at' => $_POST['maintenance_end_at'] ?? '',
        'admin_emails' => $_POST['admin_emails'] ?? '',
        'page_app_modes' => $_POST['page_app_modes'] ?? ($config['page_app_modes'] ?? []),
        'meta_note' => $_POST['meta_note'] ?? '',
        'release_apply_mode' => $_POST['release_apply_mode'] ?? 'without_file',
        'server_package_mode' => $_POST['server_package_mode'] ?? ($config['server_package_mode'] ?? 'partial'),
    ];
}

function wp_admin_updates_has_package_upload(array $file): bool {
    if (empty($file) || !isset($file['error'])) {
        return false;
    }

    if ((int)$file['error'] === UPLOAD_ERR_NO_FILE) {
        return false;
    }

    return trim((string)($file['name'] ?? '')) !== '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!wp_admin_updates_verify_csrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['admin_updates_flash'] = [
            'message' => 'Անվտանգության ստուգումը չանցավ։ Խնդրում ենք էջը թարմացնել և կրկնել գործողությունը։',
            'type' => 'error',
        ];
        header('Location: /admin_updates.php');
        exit;
    }

    $action = (string)($_POST['form_action'] ?? 'apply_release');
    $removeSubscriptionId = '';
    if (strpos($action, 'remove_push_subscription:') === 0) {
        $removeSubscriptionId = trim((string)substr($action, strlen('remove_push_subscription:')));
        $action = 'remove_push_subscription';
    }
    $actorLabel = wp_admin_updates_actor_label($adminUser);
    $actorIp = (string)($_SERVER['REMOTE_ADDR'] ?? '');

    if ($action === 'save_push_settings') {
        $ok = wp_push_save_config([
            'enabled' => !empty($_POST['push_enabled']),
            'vapid_subject' => $_POST['push_subject'] ?? ($pushConfig['vapid_subject'] ?? ''),
        ]);

        if ($ok) {
            $message = 'Push ծանուցումների կարգավորումները պահպանվեցին։';
        } else {
            $message = 'Չհաջողվեց պահպանել push ծանուցումների կարգավորումները։';
            $messageType = 'error';
        }
    } elseif ($action === 'send_push') {
        $payload = [
            'title' => trim((string)($_POST['push_title'] ?? '')),
            'body' => trim((string)($_POST['push_body'] ?? '')),
            'url' => trim((string)($_POST['push_url'] ?? '/main.html')) ?: '/main.html',
            'icon' => trim((string)($_POST['push_icon'] ?? '/wolarm_youth.png')) ?: '/wolarm_youth.png',
            'tag' => trim((string)($_POST['push_tag'] ?? 'worship-admin')) ?: 'worship-admin',
            'actor' => $actorLabel,
        ];

        if ($payload['title'] === '' || $payload['body'] === '') {
            $message = 'Push ծանուցման վերնագիրն ու բովանդակությունը պարտադիր են։';
            $messageType = 'error';
        } else {
            $result = wp_push_send_notification($payload);
            $message = (string)($result['message'] ?? 'Push ուղարկման գործողությունն ավարտվեց։');
            $messageType = !empty($result['ok']) ? 'success' : 'error';
        }
    } elseif ($action === 'remove_push_subscription') {
        $subscriptionId = $removeSubscriptionId !== '' ? $removeSubscriptionId : trim((string)($_POST['push_subscription_id'] ?? ''));
        $subscription = wp_push_find_subscription_by_id($subscriptionId);

        if (!$subscription) {
            $message = 'Ընտրված push սարքը չգտնվեց։';
            $messageType = 'error';
        } else {
            wp_push_block_endpoint(
                (string)($subscription['endpoint'] ?? ''),
                $actorLabel,
                'removed_by_admin'
            );
            $removed = wp_push_remove_subscription_by_id($subscriptionId);
            if ($removed) {
                $message = 'Push սարքը հեռացվեց և տվյալ սարքի համար push-ը անջատվեց admin-ի կողմից։';
            } else {
                $message = 'Չհաջողվեց հեռացնել push սարքը։';
                $messageType = 'error';
            }
        }
    } elseif ($action === 'remove_install_device') {
        $scope = wp_install_normalize_scope((string)($_POST['install_scope'] ?? 'main'));
        $deviceId = wp_install_sanitize_device_id((string)($_POST['install_device_id'] ?? ''));
        $deviceSignature = wp_install_sanitize_signature((string)($_POST['install_device_signature'] ?? ''));

        if ($deviceId === '' && $deviceSignature === '') {
            $message = 'Սարքի տվյալը չգտնվեց։';
            $messageType = 'error';
        } else {
            $removed = wp_install_remove_device($scope, $deviceId, $deviceSignature);
            if ($removed) {
                $message = $scope === 'admin'
                    ? 'Ադմին ծրագրի սարքի տվյալը մաքրվեց։'
                    : 'Հիմնական ծրագրի սարքի տվյալը մաքրվեց։';
            } else {
                $message = 'Չհաջողվեց մաքրել սարքի տվյալը։';
                $messageType = 'error';
            }
        }
    } elseif ($action === 'apply_release') {
        $input = wp_admin_updates_collect_input($config);
        $input = wp_admin_updates_preserve_actor_access($input, $adminUser);
        $releaseApplyMode = trim((string)($input['release_apply_mode'] ?? 'without_file'));
        unset($input['release_apply_mode']);
        $withPackage = $releaseApplyMode === 'with_file';
        $input = wp_admin_updates_prepare_release_stamps($config, $input, $withPackage);

        if (!$withPackage) {
            $ok = wp_version_save($input, [
                'actor' => $actorLabel,
                'ip' => $actorIp,
                'action' => 'save_release',
            ]);

            if ($ok) {
                $saveResult = wp_version_last_save_result();
                if (!empty($saveResult['changed'])) {
                    $message = 'Թարմացման տվյալները պահպանվեցին առանց ֆայլի տեղադրման։';

                    $pushResult = wp_push_send_notification(
                        wp_admin_updates_build_release_push_payload($config, $input, $actorLabel)
                    );

                    if (!empty($pushResult['ok'])) {
                        $message .= ' Թարմացման push ծանուցումը նույնպես ուղարկվեց։ ' . (string)($pushResult['message'] ?? '');
                    } else {
                        $message .= ' Բայց ավտոմատ push ծանուցումը չուղարկվեց։ ' . (string)($pushResult['message'] ?? '');
                    }
                } else {
                    $message = 'Թարմացման բաժնում նոր փոփոխություն չկար, դրա համար պատմություն ու push նույնպես չավելացվեցին։';
                }
            } else {
                $message = 'Չհաջողվեց պահպանել թարմացման տվյալները։';
                $messageType = 'error';
            }
        } else {
            $packageFile = trim((string)($config['server_package_file'] ?? ''));

            if (wp_admin_updates_has_package_upload($_FILES['server_package_file'] ?? [])) {
                $upload = wp_release_store_uploaded_package($_FILES['server_package_file'] ?? []);
                if (!$upload['ok']) {
                    $message = (string)($upload['message'] ?? 'Չհաջողվեց upload անել server package-ը։');
                    $messageType = 'error';
                } else {
                    $packageFile = (string)$upload['file'];
                    $input['server_package_file'] = $packageFile;
                    $input['server_package_uploaded_at'] = wp_version_now_iso();
                    $input['server_package_uploaded_by'] = $actorLabel;
                }
            }

            if ($messageType !== 'error') {
                $packagePath = wp_release_resolve_package_path($packageFile);

                if (!$packagePath) {
                    $message = 'Ֆայլով թարմացման համար package չգտնվեց։ Ընտրեք ZIP package կամ օգտագործեք արդեն առկա փաթեթը։';
                    $messageType = 'error';
                } else {
                    $apply = wp_release_apply_package($packagePath);
                    if (empty($apply['ok'])) {
                        $message = (string)($apply['message'] ?? 'Չհաջողվեց կիրառել package-ը սերվերի վրա։');
                        $messageType = 'error';
                    } else {
                        $input['server_package_file'] = basename($packagePath);
                        $input['server_package_applied_at'] = wp_version_now_iso();
                        $input['server_package_applied_by'] = $actorLabel;
                        $input['server_package_last_backup'] = (string)($apply['backup_id'] ?? '');
                        $input['server_package_linked_app_version'] = (string)($input['app_version'] ?? $config['app_version'] ?? '');
                        $input['server_package_linked_web_version'] = (string)($input['web_version'] ?? $config['web_version'] ?? '');
                        $input['server_package_release_synced_at'] = wp_version_now_iso();

                        $ok = wp_version_save($input, [
                            'actor' => $actorLabel,
                            'ip' => $actorIp,
                            'action' => 'publish_release',
                        ]);

                        if ($ok) {
                            $message = 'Թարմացումը կիրառվեց ֆայլի կցումով։ Սերվերի վրա կիրառվել է ' . (int)($apply['applied_count'] ?? 0) . ' ֆայլ, backup ID՝ ' . (string)($apply['backup_id'] ?? '—') . '։';

                            $pushResult = wp_push_send_notification(
                                wp_admin_updates_build_release_push_payload($config, $input, $actorLabel)
                            );

                            if (!empty($pushResult['ok'])) {
                                $message .= ' Թարմացման push ծանուցումը նույնպես ուղարկվեց։ ' . (string)($pushResult['message'] ?? '');
                            } else {
                                $message .= ' Բայց ավտոմատ push ծանուցումը չուղարկվեց։ ' . (string)($pushResult['message'] ?? '');
                            }
                        } else {
                            $message = 'Package-ը կիրառվեց, բայց version publish save-ը չհաջողվեց։';
                            $messageType = 'error';
                        }
                    }
                }
            }
        }
    } elseif ($action === 'clear_history') {
        $ok = wp_version_history_clear();

        if ($ok) {
            $message = 'Update history-ը ամբողջությամբ ջնջվեց։';
        } else {
            $message = 'Չհաջողվեց ջնջել update history-ը։';
            $messageType = 'error';
        }
    } elseif ($action === 'clear_push_history') {
        $ok = wp_push_history_clear();

        if ($ok) {
            $message = 'Push պատմությունը ամբողջությամբ ջնջվեց։';
        } else {
            $message = 'Չհաջողվեց ջնջել push պատմությունը։';
            $messageType = 'error';
        }
    } elseif ($action === 'rollback') {
        $historyId = trim((string)($_POST['history_id'] ?? ''));
        $historyItem = wp_version_history_find($historyId);

        if (!$historyItem || empty($historyItem['snapshot']) || !is_array($historyItem['snapshot'])) {
            $message = 'Rollback-ի համար անհրաժեշտ snapshot-ը չգտնվեց։';
            $messageType = 'error';
        } else {
            $rollbackSnapshot = wp_admin_updates_preserve_actor_access($historyItem['snapshot'], $adminUser);

            $ok = wp_version_save($rollbackSnapshot, [
                'actor' => $actorLabel,
                'ip' => $actorIp,
                'action' => 'rollback',
            ]);

            if ($ok) {
                $saveResult = wp_version_last_save_result();
                $message = !empty($saveResult['changed'])
                    ? 'Configuration-ը վերականգնվեց ընտրած history entry-ից։'
                    : 'Ընտրված history entry-ն արդեն ընթացիկ վիճակն է, նոր փոփոխություն չկար։';
            } else {
                $message = 'Rollback-ը չհաջողվեց։';
                $messageType = 'error';
            }
        }
    } elseif (in_array($action, ['save_maintenance', 'save_page_modes', 'save_access'], true)) {
        $input = wp_admin_updates_collect_input($config);
        $input = wp_admin_updates_preserve_actor_access($input, $adminUser);
        unset($input['release_apply_mode']);

        $ok = wp_version_save($input, [
            'actor' => $actorLabel,
            'ip' => $actorIp,
            'action' => match ($action) {
                'save_maintenance' => 'save_maintenance',
                'save_page_modes' => 'save_page_modes',
                'save_access' => 'save_access',
                default => 'save',
            },
        ]);

        if ($ok) {
            $saveResult = wp_version_last_save_result();
            $changed = !empty($saveResult['changed']);
            if ($action === 'save_maintenance') {
                $message = $changed ? 'Տեխնիկական սպասարկման տվյալները պահպանվեցին։' : 'Տեխնիկական սպասարկման բաժնում նոր փոփոխություն չկար։';
            } elseif ($action === 'save_page_modes') {
                $message = $changed ? 'Ծրագրային էջերի կարգավորումները պահպանվեցին։' : 'Ծրագրային էջերի բաժնում նոր փոփոխություն չկար։';
            } else {
                $message = $changed ? 'Մուտքերի և նշումների տվյալները պահպանվեցին։' : 'Մուտքերի և նշումների բաժնում նոր փոփոխություն չկար։';
            }
        } else {
            $message = 'Չհաջողվեց պահպանել configuration-ը։';
            $messageType = 'error';
        }
    } else {
        $input = wp_admin_updates_collect_input($config);
        $input = wp_admin_updates_preserve_actor_access($input, $adminUser);
        unset($input['release_apply_mode']);

        $ok = wp_version_save($input, [
            'actor' => $actorLabel,
            'ip' => $actorIp,
            'action' => 'save_general',
        ]);

        if ($ok) {
            $saveResult = wp_version_last_save_result();
            $message = !empty($saveResult['changed'])
                ? 'Configuration-ը պահպանվեց։ Նոր version/maintenance տվյալները հասանելի են հաջորդ check-ից սկսած։'
                : 'Պահպանելու նոր փոփոխություն չկար։';
        } else {
            $message = 'Չհաջողվեց պահպանել configuration-ը։';
            $messageType = 'error';
        }
    }

    $config = wp_version_load();
    $pushConfig = wp_push_bootstrap_config();
    $pushStats = wp_push_stats();

    $_SESSION['admin_updates_flash'] = [
        'message' => $message,
        'type' => $messageType,
    ];

    header('Location: /admin_updates.php');
    exit;
}

$history = wp_version_history_load(25);
$isScheduledActive = wp_version_is_scheduled_maintenance_active($config);
$isMaintenanceActive = wp_version_is_maintenance_active($config);
$adminEmailsText = implode("\n", (array)($config['admin_emails'] ?? []));
$packageUploadedAt = wp_version_format_datetime_admin((string)($config['server_package_uploaded_at'] ?? ''));
$packageAppliedAt = wp_version_format_datetime_admin((string)($config['server_package_applied_at'] ?? ''));
$packageSyncedAt = wp_version_format_datetime_admin((string)($config['server_package_release_synced_at'] ?? ''));
$packageMode = (string)($config['server_package_mode'] ?? 'partial');
$packageLinkedAppVersion = trim((string)($config['server_package_linked_app_version'] ?? ''));
$packageLinkedWebVersion = trim((string)($config['server_package_linked_web_version'] ?? ''));
$isPackageSyncedToCurrentRelease =
    !empty($config['server_package_file']) &&
    $packageLinkedAppVersion !== '' &&
    $packageLinkedWebVersion !== '' &&
    $packageLinkedAppVersion === (string)($config['app_version'] ?? '') &&
    $packageLinkedWebVersion === (string)($config['web_version'] ?? '');
$pushLastSentAt = wp_version_format_datetime_admin((string)($pushConfig['last_sent_at'] ?? ''));
$pushHistory = wp_push_history_load(50);
$csrfToken = wp_admin_updates_csrf_token();
?>
<!doctype html>
<html lang="hy">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Թարմացումների Վահանակ</title>
  <style>
    :root{
      --bg:#06101c;
      --panel:rgba(13,20,35,.82);
      --panel-2:rgba(255,255,255,.04);
      --line:rgba(255,255,255,.08);
      --text:#eef2ff;
      --muted:#9ca9c8;
      --primary:#4f7cff;
      --primary-2:#7aa2ff;
      --success:#18a957;
      --warning:#ffb84d;
      --danger:#d24b5f;
      --radius:20px;
      --shadow:0 22px 60px rgba(0,0,0,.36);
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family:Inter,system-ui,sans-serif;
      background:
        radial-gradient(circle at top left, rgba(79,124,255,.16), transparent 24%),
        radial-gradient(circle at top right, rgba(24,169,87,.10), transparent 20%),
        linear-gradient(180deg,#0a1426 0%, #05070d 100%);
      color:var(--text);
    }
    .wrap{max-width:1380px;margin:0 auto;padding:28px 18px 60px}
    .topbar{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(300px,.85fr);gap:18px;align-items:stretch;margin-bottom:18px}
    .hero{
      position:relative;overflow:hidden;padding:28px;border-radius:26px;
      border:1px solid rgba(255,255,255,.08);
      background:
        radial-gradient(circle at top right, rgba(122,162,255,.22), transparent 28%),
        radial-gradient(circle at bottom left, rgba(24,169,87,.12), transparent 24%),
        linear-gradient(145deg, rgba(13,20,35,.96), rgba(7,12,24,.9));
      box-shadow:var(--shadow)
    }
    .hero::after{
      content:"";position:absolute;inset:auto -40px -40px auto;width:220px;height:220px;
      background:radial-gradient(circle, rgba(79,124,255,.22), transparent 70%);
      pointer-events:none
    }
    .eyebrow{
      display:inline-flex;align-items:center;gap:8px;
      padding:7px 12px;border-radius:999px;border:1px solid rgba(255,255,255,.1);
      background:rgba(255,255,255,.05);color:#dbe6ff;font-size:12px;font-weight:800;
      letter-spacing:.06em;text-transform:uppercase
    }
    .hero h1{margin:14px 0 0;font-size:40px;line-height:1.02;letter-spacing:-.03em}
    .hero p{margin:12px 0 0;color:var(--muted);max-width:760px;line-height:1.62;font-size:15px}
    .hero-meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:22px}
    .hero-stat{
      padding:14px 16px;border-radius:18px;border:1px solid rgba(255,255,255,.08);
      background:rgba(255,255,255,.04);backdrop-filter:blur(8px)
    }
    .hero-stat strong{display:block;font-size:22px;letter-spacing:-.02em}
    .hero-stat span{display:block;margin-top:4px;color:var(--muted);font-size:12px}
    .topbar-side{display:flex;flex-direction:column;gap:12px}
    .actions{
      display:flex;gap:10px;flex-wrap:wrap;align-items:center;padding:18px;border-radius:22px;
      border:1px solid var(--line);background:rgba(255,255,255,.04);box-shadow:var(--shadow)
    }
    .actions .btn{flex:1 1 180px}
    .workspace-note{
      padding:18px;border-radius:22px;border:1px solid var(--line);
      background:linear-gradient(160deg, rgba(255,255,255,.05), rgba(255,255,255,.02));
      color:var(--muted);line-height:1.6;font-size:14px
    }
    .workspace-note strong{display:block;margin-bottom:8px;color:var(--text);font-size:15px}
    .workspace-note ol{margin:0;padding-left:18px}
    .workspace-note li + li{margin-top:6px}
    .btn,.history-btn{
      display:inline-flex;align-items:center;justify-content:center;min-height:44px;
      padding:12px 16px;border-radius:14px;border:1px solid var(--line);color:var(--text);
      text-decoration:none;background:rgba(255,255,255,.05);font-weight:700;cursor:pointer;
      transition:transform .18s ease, background .18s ease, border-color .18s ease, box-shadow .18s ease;
    }
    .btn:hover,.history-btn:hover{transform:translateY(-1px);background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.16)}
    .btn-primary{background:linear-gradient(135deg,var(--primary),var(--primary-2));border-color:transparent;color:#fff;box-shadow:0 12px 28px rgba(79,124,255,.28)}
    .layout{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(360px,.8fr);gap:18px;align-items:start}
    .layout.layout-single,
    .layout.layout-focused{grid-template-columns:minmax(0,1fr)}
    .layout.layout-single > [data-section-container],
    .layout.layout-focused > [data-section-container]{grid-column:1 / -1}
    .stack{display:grid;gap:18px}
    .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
    .panel{
      position:relative;overflow:hidden;background:var(--panel);border:1px solid var(--line);
      border-radius:var(--radius);box-shadow:var(--shadow);backdrop-filter:blur(12px);padding:18px
    }
    .panel::before{
      content:"";position:absolute;left:18px;right:18px;top:0;height:1px;
      background:linear-gradient(90deg, rgba(122,162,255,.55), rgba(255,255,255,0));opacity:.75
    }
    .panel h2{margin:0 0 6px;font-size:20px;letter-spacing:-.02em}
    .panel p{margin:0 0 16px;color:var(--muted);line-height:1.55}
    .field{display:flex;flex-direction:column;gap:8px;margin-top:14px}
    label{font-size:13px;color:#d9e1ff;font-weight:700}
    input,textarea,select{
      width:100%;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.04);
      color:var(--text);padding:12px 14px;outline:none;font:inherit;
    }
    input:focus,textarea:focus,select:focus{
      border-color:rgba(122,162,255,.55);
      box-shadow:0 0 0 4px rgba(79,124,255,.12);
      background:rgba(255,255,255,.055)
    }
    textarea{min-height:120px;resize:vertical}
    .full{grid-column:1 / -1}
    .banner{margin-bottom:16px;padding:14px 16px;border-radius:14px;font-weight:700;border:1px solid var(--line)}
    .banner.success{background:rgba(24,169,87,.14);color:#bdf3cf}
    .banner.error{background:rgba(210,75,95,.14);color:#ffc8d0}
    .section-switcher{
      display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin:0 0 18px;
      padding:14px;border-radius:18px;border:1px solid var(--line);
      background:rgba(255,255,255,.04)
    }
    .section-tab{
      display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-height:72px;
      padding:14px 16px;border-radius:18px;border:1px solid var(--line);
      background:rgba(255,255,255,.04);color:var(--text);font-weight:700;cursor:pointer;text-align:left
    }
    .section-tab:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.16)}
    .section-tab.active{
      background:linear-gradient(135deg,var(--primary),var(--primary-2));
      border-color:transparent;color:#fff;box-shadow:0 12px 28px rgba(79,124,255,.22)
    }
    .section-tab span{display:block;font-size:15px;letter-spacing:-.01em}
    .section-tab small{display:block;margin-top:4px;font-size:12px;font-weight:600;opacity:.82;line-height:1.35}
    .stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
    .stat{background:var(--panel-2);border:1px solid var(--line);border-radius:16px;padding:14px}
    .stat strong{display:block;font-size:22px;margin-bottom:6px}
    .stat span{color:var(--muted);font-size:13px}
    .action-panel{
      display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;
      padding:18px 20px;border-radius:22px;
      background:
        linear-gradient(135deg, rgba(79,124,255,.14), rgba(122,162,255,.06)),
        rgba(255,255,255,.04);
      border:1px solid rgba(122,162,255,.18);
      position:sticky;bottom:14px;z-index:20;backdrop-filter:blur(14px)
    }
    .action-copy strong{display:block;font-size:18px;letter-spacing:-.02em}
    .action-copy span{display:block;margin-top:6px;color:var(--muted);line-height:1.5;font-size:14px}
    .action-buttons{display:flex;gap:10px;flex-wrap:wrap}
    .switch-row{display:flex;align-items:center;justify-content:space-between;gap:16px;border:1px solid var(--line);background:var(--panel-2);border-radius:16px;padding:14px;margin-top:10px}
    .switch-copy strong{display:block;font-size:15px;margin-bottom:4px}
    .switch-copy span{color:var(--muted);font-size:13px;line-height:1.4}
    .page-app-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:14px}
    .page-app-card{
      display:flex;align-items:center;justify-content:space-between;gap:14px;
      padding:16px;border-radius:18px;border:1px solid var(--line);background:var(--panel-2)
    }
    .page-app-copy strong{display:block;font-size:15px;margin-bottom:6px}
    .page-app-copy span{display:block;color:var(--muted);font-size:13px;line-height:1.45}
    .page-app-copy code{margin-top:8px;display:inline-flex}
    .switch{position:relative;width:62px;height:34px;flex:0 0 auto}
    .switch input{position:absolute;inset:0;opacity:0;cursor:pointer}
    .slider{position:absolute;inset:0;background:rgba(255,255,255,.12);border:1px solid var(--line);border-radius:999px;transition:.2s ease}
    .slider::after{content:"";position:absolute;width:26px;height:26px;left:3px;top:3px;border-radius:50%;background:#fff;transition:.2s ease}
    .switch input:checked + .slider{background:linear-gradient(135deg,var(--warning),#ff8a4d);border-color:transparent}
    .switch input:checked + .slider::after{transform:translateX(28px)}
    .row-2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .quick-stack{display:grid;gap:10px}
    .quick-strip{
      display:grid;gap:10px;padding:12px 14px;border:1px solid var(--line);
      background:var(--panel-2);border-radius:16px
    }
    .quick-strip-head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}
    .quick-strip-head strong{display:block;font-size:14px}
    .quick-strip-head span{display:block;color:var(--muted);font-size:12px;line-height:1.38;max-width:520px}
    .quick-actions-grid{display:flex;flex-wrap:wrap;gap:7px}
    .quick-actions-grid .btn{
      min-height:32px;padding:7px 10px;font-size:12px;border-radius:999px;
      background:rgba(255,255,255,.06)
    }
    .quick-actions-grid .btn-wide{flex-basis:auto}
    .panel-subgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .package-meta{display:grid;gap:10px}
    .package-mode-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:14px 0}
    .package-mode-card{padding:14px;border-radius:16px;border:1px solid var(--line);background:var(--panel-2)}
    .package-mode-card strong{display:block;font-size:14px;margin-bottom:6px}
    .package-mode-card span{display:block;color:var(--muted);font-size:13px;line-height:1.5}
    .package-helper{margin-top:10px;color:#cfe0ff;line-height:1.55;font-size:13px}
    .package-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
    .danger-note{margin-top:12px;padding:12px 14px;border-radius:14px;border:1px solid rgba(210,75,95,.28);background:rgba(210,75,95,.10);color:#ffd8de;line-height:1.55;font-size:13px}
    .history-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap}
    .history-list{display:grid;gap:12px;margin-top:12px}
    .history-item{border:1px solid var(--line);background:var(--panel-2);border-radius:16px;padding:14px}
    .device-list{display:grid;gap:14px;margin-top:12px}
    .device-card{
      border:1px solid rgba(255,255,255,.08);
      background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(255,255,255,.025));
      border-radius:20px;
      padding:16px;
      box-shadow:0 16px 34px rgba(0,0,0,.18)
    }
    .device-header{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap}
    .device-identity{display:grid;gap:6px}
    .device-title{font-weight:800;font-size:15px;letter-spacing:-.01em}
    .device-subtitle{color:var(--muted);font-size:12px;line-height:1.45}
    .device-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
    .device-meta-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
      gap:10px;
      margin-top:12px
    }
    .device-meta{
      padding:12px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.07);
      background:rgba(255,255,255,.035)
    }
    .device-meta strong{display:block;font-size:11px;color:#a8b7dc;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
    .device-meta span{display:block;font-size:13px;color:var(--text);line-height:1.45;word-break:break-word}
    .chip.success{background:rgba(24,169,87,.12);border-color:rgba(24,169,87,.28);color:#c5f5d5}
    .chip.warning{background:rgba(255,184,77,.12);border-color:rgba(255,184,77,.28);color:#ffe0ab}
    .history-more{margin-top:14px;display:flex;justify-content:center}
    .history-top{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;margin-bottom:8px}
    .history-title{font-weight:800;font-size:14px}
    .history-time{color:var(--muted);font-size:12px}
    .chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
    .chip{display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:999px;border:1px solid var(--line);background:rgba(255,255,255,.05);font-size:12px;color:#dce5ff}
    .note{margin-top:8px;color:var(--muted);line-height:1.5;white-space:pre-wrap;font-size:13px}
    .history-actions{margin-top:12px;display:flex;justify-content:flex-end}
    .history-btn{min-height:36px;padding:9px 12px;font-size:13px}
    .history-btn.danger{background:rgba(210,75,95,.16);border-color:rgba(210,75,95,.28);color:#ffd8de}
    .history-btn.danger:hover{background:rgba(210,75,95,.22);border-color:rgba(210,75,95,.38)}
    code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:rgba(255,255,255,.06);padding:2px 6px;border-radius:8px}
    @media(max-width:1050px){
      .layout,.topbar{grid-template-columns:1fr}
      .hero-meta{grid-template-columns:repeat(2,minmax(0,1fr))}
      .section-switcher{grid-template-columns:repeat(3,minmax(0,1fr))}
      .stats{grid-template-columns:repeat(2,minmax(0,1fr))}
    }
    @media(max-width:860px){
      .wrap{padding:16px 12px 40px}
      .grid,.row-2,.panel-subgrid,.package-mode-grid,.package-actions,.hero-meta{grid-template-columns:1fr}
      .page-app-grid{grid-template-columns:1fr}
      .full{grid-column:auto}
      .topbar{gap:12px}
      .hero{padding:18px;border-radius:20px}
      .hero h1{font-size:30px}
      .hero p{font-size:14px;line-height:1.5}
      .hero-stat{padding:12px 14px}
      .hero-stat strong{font-size:18px}
      .actions{padding:12px;border-radius:18px}
      .actions .btn{flex:1 1 100%}
      .workspace-note{padding:14px;border-radius:18px;font-size:13px}
      .panel{padding:14px;border-radius:18px}
      .panel::before{left:14px;right:14px}
      .panel h2{font-size:18px}
      .panel p{font-size:13px;line-height:1.45}
      .section-switcher{grid-template-columns:repeat(2,minmax(0,1fr));padding:10px}
      .section-tab{min-height:64px;padding:12px;border-radius:16px}
      .section-tab span{font-size:13px}
      .section-tab small{font-size:11px}
      .stats{grid-template-columns:1fr}
      .stat{padding:12px}
      .stat strong{font-size:18px}
      .field{margin-top:12px}
      input,textarea,select{padding:11px 12px}
      textarea{min-height:100px}
      .quick-strip{padding:10px 12px}
      .quick-strip-head{gap:6px}
      .quick-strip-head span{font-size:11px}
      .quick-actions-grid{overflow:auto;flex-wrap:nowrap;padding-bottom:2px}
      .quick-actions-grid .btn{flex:0 0 auto;white-space:nowrap}
      .action-buttons{width:100%}
      .action-buttons .btn{flex:1 1 100%}
      .action-panel{position:static;bottom:auto;padding:14px 16px}
      .history-item{padding:12px}
      .device-card{padding:13px;border-radius:18px}
      .device-meta-grid{grid-template-columns:1fr}
      .chip{font-size:11px;padding:5px 8px}
    }
  </style>
</head>
<body>
  <main class="wrap">
    <div class="topbar">
      <div class="hero">
        <div class="eyebrow">Թարմացում և տեղադրում</div>
        <h1>Թարմացումների Վահանակ</h1>
        <p>Սա update-ների, deploy-ի և maintenance-ի կառավարման հիմնական վահանակն է։ Աշխատանքը բաժանված է պարզ փուլերի, որպեսզի phone-ից ու computer-ից արագ գտնես ուզած գործողությունը և սխալ publish չանես։</p>
        <div class="hero-meta">
          <div class="hero-stat">
            <strong><?= htmlspecialchars((string)$config['app_version'], ENT_QUOTES) ?></strong>
            <span>Ծրագրի ընթացիկ տարբերակ</span>
          </div>
          <div class="hero-stat">
            <strong><?= htmlspecialchars((string)$config['web_version'], ENT_QUOTES) ?></strong>
            <span>Կայքի ընթացիկ տարբերակ</span>
          </div>
          <div class="hero-stat">
            <strong><?= $isPackageSyncedToCurrentRelease ? 'ՊԱՏՐԱՍՏ' : 'ՍՊԱՍՄԱՆ ՄԵՋ' ?></strong>
            <span>Փաթեթի կապի վիճակ</span>
          </div>
          <div class="hero-stat">
            <strong><?= (int)($installStats['main']['known_count'] ?? 0) ?></strong>
            <span>Ծրագրի ընդհանուր ճանաչված տեղադրումներ</span>
          </div>
        </div>
      </div>
      <div class="topbar-side">
        <div class="actions">
          <a class="btn" href="/songs.php">Վերադառնալ ադմին վահանակ</a>
          <a class="btn" href="/version_manifest.php" target="_blank" rel="noopener">Բացել տարբերակի տվյալները</a>
          <a class="btn" href="/admin_logout.php">Դուրս գալ admin-ից</a>
        </div>
        <div class="workspace-note">
          <strong>Արագ հոսք</strong>
          <ol>
            <li>Լրացրու version/message դաշտերը `Թարմացում և տեղադրում` բաժնում։</li>
            <li>Ընտրիր կիրառման տարբերակը` առանց ֆայլի կամ ֆայլով։</li>
            <li>Սեղմիր `Կիրառել թարմացումը` ու ավարտիր գործընթացը։</li>
          </ol>
        </div>
      </div>
    </div>

    <?php if ($message !== ''): ?>
      <div class="banner <?= htmlspecialchars($messageType, ENT_QUOTES) ?>"><?= htmlspecialchars($message, ENT_QUOTES) ?></div>
    <?php endif; ?>

    <div class="section-switcher" role="tablist" aria-label="Admin բաժիններ">
      <button class="section-tab active" type="button" data-section-tab="release"><span>1. Թարմացում և տեղադրում</span><small>Տարբերակներ, հաղորդագրություններ, ZIP փաթեթ և հրապարակում</small></button>
      <button class="section-tab" type="button" data-section-tab="maintenance"><span>2. Տեխնիկական աշխատանքներ</span><small>Միացնել, ժամանակացույց, հաղորդագրություն</small></button>
      <button class="section-tab" type="button" data-section-tab="push"><span>3. Push ծանուցումներ</span><small>Բաժանորդագրումներ, ուղարկում և push settings</small></button>
      <button class="section-tab" type="button" data-section-tab="devices"><span>4. Սարքեր</span><small>Ծրագրի ակտիվ սարքեր և install տվյալներ</small></button>
      <button class="section-tab" type="button" data-section-tab="history"><span>5. Պատմություն</span><small>Հետ գնալ, փոփոխությունների հետք, ավելին բացել</small></button>
      <button class="section-tab" type="button" data-section-tab="access"><span>6. Մուտքեր</span><small>Admin email-ներ, նշումներ, session տվյալներ</small></button>
    </div>

    <div class="layout" id="adminLayout">
      <form id="releaseControlForm" method="post" enctype="multipart/form-data" class="stack" data-section-container>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
        <div class="stats" data-admin-section="release maintenance all">
          <div class="stat">
            <strong><?= htmlspecialchars((string)$config['app_version'], ENT_QUOTES) ?></strong>
            <span><?= htmlspecialchars(wp_version_release_label((string)$config['app_release_type']), ENT_QUOTES) ?></span>
          </div>
          <div class="stat">
            <strong><?= htmlspecialchars((string)$config['web_version'], ENT_QUOTES) ?></strong>
            <span><?= htmlspecialchars(wp_version_release_label((string)$config['web_release_type']), ENT_QUOTES) ?></span>
          </div>
          <div class="stat">
            <strong><?= $isMaintenanceActive ? 'ՄԻԱՑՎԱԾ' : 'ԱՆՋԱՏՎԱԾ' ?></strong>
            <span><?= $isScheduledActive ? 'Ժամանակացույցով տեխնիկական աշխատանքը ակտիվ է' : 'Տեխնիկական աշխատանքների վիճակ' ?></span>
          </div>
          <div class="stat">
            <strong><?= htmlspecialchars(wp_version_format_datetime_admin((string)$config['updated_at']) ?: '—', ENT_QUOTES) ?></strong>
            <span>Վերջին թարմացումը (UTC+4)</span>
          </div>
        </div>

        <div class="grid">
          <section class="panel" data-admin-section="release all">
            <h2>Ծրագիր / PWA</h2>
            <p>Այս տարբերակը standalone ծրագրի համար է։ Փոխելիս ծրագիրը կառաջարկի ամբողջական թարմացում և նոր offline sync։ Թարմացման տեսակը բացատրում է փոփոխության բնույթը, իսկ կարճ նկարագրությունը ցույց է տալիս ինչ է փոխվել։</p>
            <div class="field">
              <label for="app_version">Ծրագրի տարբերակ</label>
              <input id="app_version" name="app_version" value="<?= htmlspecialchars((string)$config['app_version'], ENT_QUOTES) ?>" required>
            </div>
            <div class="field">
              <label for="app_release_type">Թարմացման տեսակ</label>
              <select id="app_release_type" name="app_release_type">
                <?php foreach ($releaseTypes as $releaseTypeValue => $releaseTypeLabel): ?>
                  <option value="<?= htmlspecialchars($releaseTypeValue, ENT_QUOTES) ?>" <?= (string)$config['app_release_type'] === $releaseTypeValue ? 'selected' : '' ?>>
                    <?= htmlspecialchars($releaseTypeLabel, ENT_QUOTES) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label for="app_release_summary">Կարճ նկարագրություն</label>
              <input id="app_release_summary" name="app_release_summary" maxlength="240" value="<?= htmlspecialchars((string)$config['app_release_summary'], ENT_QUOTES) ?>" placeholder="Օր.` Offline sync improvements և performance fix-եր">
            </div>
            <div class="field">
              <label for="app_title">Թարմացման վերնագիր</label>
              <input id="app_title" name="app_title" value="<?= htmlspecialchars((string)$config['app_title'], ENT_QUOTES) ?>" required>
            </div>
            <div class="field">
              <label for="app_message">Թարմացման հաղորդագրություն</label>
              <textarea id="app_message" name="app_message" required><?= htmlspecialchars((string)$config['app_message'], ENT_QUOTES) ?></textarea>
            </div>
          </section>

          <section class="panel" data-admin-section="release all">
            <h2>Կայք / Web</h2>
            <p>Այս տարբերակը browser տարբերակի համար է։ Փոխելիս կայքը կբերի refresh պատուհան և կվերբեռնի օնլայն տարբերակը։ Թարմացման տեսակը օգնում է տարբերակել բովանդակության թարմացումը, արագ շտկումը կամ մեծ փոփոխությունը։</p>
            <div class="field">
              <label for="web_version">Կայքի տարբերակ</label>
              <input id="web_version" name="web_version" value="<?= htmlspecialchars((string)$config['web_version'], ENT_QUOTES) ?>" required>
            </div>
            <div class="field">
              <label for="web_release_type">Թարմացման տեսակ</label>
              <select id="web_release_type" name="web_release_type">
                <?php foreach ($releaseTypes as $releaseTypeValue => $releaseTypeLabel): ?>
                  <option value="<?= htmlspecialchars($releaseTypeValue, ENT_QUOTES) ?>" <?= (string)$config['web_release_type'] === $releaseTypeValue ? 'selected' : '' ?>>
                    <?= htmlspecialchars($releaseTypeLabel, ENT_QUOTES) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label for="web_release_summary">Կարճ նկարագրություն</label>
              <input id="web_release_summary" name="web_release_summary" maxlength="240" value="<?= htmlspecialchars((string)$config['web_release_summary'], ENT_QUOTES) ?>" placeholder="Օր.` UI refresh և content update">
            </div>
            <div class="field">
              <label for="web_title">Թարմացման վերնագիր</label>
              <input id="web_title" name="web_title" value="<?= htmlspecialchars((string)$config['web_title'], ENT_QUOTES) ?>" required>
            </div>
            <div class="field">
              <label for="web_message">Թարմացման հաղորդագրություն</label>
              <textarea id="web_message" name="web_message" required><?= htmlspecialchars((string)$config['web_message'], ENT_QUOTES) ?></textarea>
            </div>
          </section>

          <section class="panel full" data-admin-section="release maintenance all">
            <h2>Արագ գործողություններ</h2>
            <p>Սրանք արագ լրացման և միացման կոճակներ են։ Վերջնական կիրառումը մնում է մեկ հիմնական <code>Կիրառել թարմացումը</code> կոճակով` ըստ ընտրված կիրառման ձևի։</p>

            <div class="quick-stack">
              <div class="quick-strip">
                <div class="quick-strip-head">
                  <strong>Տարբերակներ</strong>
                  <span>Մի քանի սեղմումով փոխիր տարբերակները կամ լրացրու հիմնական տեքստերը։</span>
                </div>
                <div class="quick-actions-grid">
                  <button class="btn" type="button" data-bump-target="app" data-bump-kind="patch">Ծրագիր +1 patch</button>
                  <button class="btn" type="button" data-bump-target="web" data-bump-kind="patch">Կայք +1 patch</button>
                  <button class="btn" type="button" data-bump-target="both" data-bump-kind="patch">Երկուսն էլ +1 patch</button>
                  <button class="btn" type="button" data-bump-target="both" data-bump-kind="minor">Երկուսն էլ +1 minor</button>
                  <button class="btn" type="button" data-bump-target="both" data-bump-kind="major">Երկուսն էլ +1 major</button>
                  <button class="btn" type="button" id="fillDefaultTextsBtn">Լրացնել տեքստերը</button>
                  <button class="btn" type="button" id="copyAppContentToWebBtn">Ծրագիր -> Կայք</button>
                  <button class="btn btn-wide" type="button" id="syncVersionsBtn">Նույն տարբերակը երկուսի համար</button>
                </div>
              </div>

              <div class="quick-strip">
                <div class="quick-strip-head">
                  <strong>Տեխնիկական աշխատանքներ</strong>
                  <span>Արագ միացրու կամ ժամ տուր տեխնիկական աշխատանքներին՝ առանց schedule դաշտերը ձեռքով լրացնելու։</span>
                </div>
                <div class="quick-actions-grid">
                  <button class="btn" type="button" data-maintenance-hours="0.5">30 րոպե</button>
                  <button class="btn" type="button" data-maintenance-hours="1">1 ժամ</button>
                  <button class="btn" type="button" data-maintenance-hours="2">2 ժամ</button>
                  <button class="btn" type="button" data-maintenance-hours="4">4 ժամ</button>
                  <button class="btn" type="button" id="startMaintenanceNowBtn">Միացնել հիմա</button>
                  <button class="btn" type="button" id="clearScheduleBtn">Մաքրել schedule-ը</button>
                  <button class="btn" type="button" id="disableMaintenanceBtn">Անջատել տեխնիկական աշխատանքները</button>
                </div>
              </div>
            </div>
          </section>

          <section class="panel full" data-admin-section="release all">
            <h2>Թարմացման տրամաբանություն</h2>
            <p><code>major.minor.patch</code> մոտեցումը պահպանում է թարմացման իմաստը։ Major-ը մեծ փոփոխություն է, Minor-ը նոր հնարավորություն կամ նկատելի թարմացում, Patch-ը փոքր ուղղում։ Թարմացման տեսակը տալիս է հասկանալի բացատրություն, իսկ կարճ նկարագրությունը երևում է update modal-ում։</p>
          </section>

          <section class="panel full" data-admin-section="release all">
            <h2>Փաթեթ և տեղադրում</h2>
            <p>Այստեղ ընտրում եք ինչպես կիրառել տարբերակը. միայն version/message թարմացմամբ կամ ZIP ֆայլի կցումով։ Եթե ընտրեք ֆայլով տարբերակը, նույն հոսքի մեջ կկատարվի նաև սերվերի ֆայլերի թարմացումը։</p>

            <div class="package-meta">
              <div class="chip">Ընթացիկ փաթեթ <?= htmlspecialchars((string)($config['server_package_file'] ?: '—'), ENT_QUOTES) ?></div>
              <div class="chip">Ռեժիմ <?= htmlspecialchars(wp_version_package_mode_label($packageMode), ENT_QUOTES) ?></div>
              <div class="chip">Ներբեռնվել է <?= htmlspecialchars($packageUploadedAt ?: '—', ENT_QUOTES) ?></div>
              <div class="chip">Կիրառվել է <?= htmlspecialchars($packageAppliedAt ?: '—', ENT_QUOTES) ?></div>
              <div class="chip"><?= $isPackageSyncedToCurrentRelease ? 'Կապը պատրաստ է' : 'Կապը սպասման մեջ է' ?></div>
              <div class="chip">Կապվել է <?= htmlspecialchars($packageSyncedAt ?: '—', ENT_QUOTES) ?></div>
              <div class="chip">Կապված ծրագիր <?= htmlspecialchars($packageLinkedAppVersion ?: '—', ENT_QUOTES) ?></div>
              <div class="chip">Կապված կայք <?= htmlspecialchars($packageLinkedWebVersion ?: '—', ENT_QUOTES) ?></div>
              <div class="chip">Վերջին պահուստավորում <?= htmlspecialchars((string)($config['server_package_last_backup'] ?: '—'), ENT_QUOTES) ?></div>
            </div>

            <div class="package-mode-grid">
              <div class="package-mode-card">
                <strong>Մասամբ ֆայլերի թարմացում</strong>
                <span>Փոխվում են միայն ZIP-ի ներսում եղած ֆայլերը։ Հարմար է, երբ թարմացնում եք մեկ կամ մի քանի կոնկրետ ֆայլ։</span>
              </div>
              <div class="package-mode-card">
                <strong>Ամբողջական փաթեթի տեղադրում</strong>
                <span>Փաթեթը դիտարկվում է որպես ամբողջ release package։ Հարմար է մեծ deploy-երի համար, երբ նույն release-ի հետ շատ ֆայլեր եք թարմացնում։</span>
              </div>
            </div>

            <div class="row-2">
              <div class="field">
                <label for="release_apply_mode">Կիրառման տարբերակ</label>
                <select id="release_apply_mode" name="release_apply_mode">
                  <option value="without_file">Առանց ֆայլի կցման</option>
                  <option value="with_file">Ֆայլի կցումով</option>
                </select>
              </div>
              <div class="field">
                <label for="server_package_mode">Տեղադրման ռեժիմ</label>
                <select id="server_package_mode" name="server_package_mode">
                  <?php foreach ($packageModes as $packageModeValue => $packageModeLabel): ?>
                    <option value="<?= htmlspecialchars($packageModeValue, ENT_QUOTES) ?>" <?= $packageMode === $packageModeValue ? 'selected' : '' ?>>
                      <?= htmlspecialchars($packageModeLabel, ENT_QUOTES) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="field">
                <label for="server_package_file">ZIP թարմացման փաթեթ</label>
                <input id="server_package_file" name="server_package_file" type="file" accept=".zip,application/zip">
              </div>
            </div>

            <div id="packageModeHelper" class="package-helper"></div>

            <div class="danger-note">Եթե ընտրեք `ֆայլի կցումով` տարբերակը և նոր ZIP չընտրեք, համակարգը կօգտագործի արդեն ներբեռնված ընթացիկ փաթեթը։ `Առանց ֆայլի կցման` տարբերակում ZIP դաշտը պարզապես անտեսվում է։</div>
          </section>

          <section class="panel full" data-admin-section="maintenance all">
            <h2>Տեխնիկական աշխատանքներ</h2>
            <p>Կարող եք միացնել maintenance-ը ձեռքով կամ schedule-ով։ Երբ scheduled interval-ը հասնի, <code>status.php</code>-ը ինքն է maintenance տալու նույնիսկ եթե toggle-ը off է։</p>
            <div class="switch-row">
              <div class="switch-copy">
                <strong>Ձեռքով միացնել տեխնիկական աշխատանքները</strong>
                <span>Միացրու անմիջապես maintenance ռեժիմը՝ անկախ schedule-ից։</span>
              </div>
              <label class="switch" for="maintenance_enabled">
                <input id="maintenance_enabled" name="maintenance_enabled" type="checkbox" <?= !empty($config['maintenance_enabled']) ? 'checked' : '' ?>>
                <span class="slider"></span>
              </label>
            </div>

            <div class="row-2">
              <div class="field">
                <label for="maintenance_start_at">Պլանավորված սկիզբ</label>
                <input id="maintenance_start_at" name="maintenance_start_at" type="datetime-local" value="<?= htmlspecialchars(wp_version_format_datetime_local((string)$config['maintenance_start_at']), ENT_QUOTES) ?>">
              </div>
              <div class="field">
                <label for="maintenance_end_at">Պլանավորված ավարտ</label>
                <input id="maintenance_end_at" name="maintenance_end_at" type="datetime-local" value="<?= htmlspecialchars(wp_version_format_datetime_local((string)$config['maintenance_end_at']), ENT_QUOTES) ?>">
              </div>
            </div>

            <div class="field">
              <label for="maintenance_message">Ցուցադրվող հաղորդագրություն</label>
              <textarea id="maintenance_message" name="maintenance_message"><?= htmlspecialchars((string)$config['maintenance_message'], ENT_QUOTES) ?></textarea>
            </div>

            <div class="action-buttons" style="margin-top:14px">
              <button class="btn" type="submit" name="form_action" value="save_maintenance">Պահպանել տեխնիկական սպասարկումը</button>
            </div>
          </section>

          <section class="panel full" data-admin-section="maintenance all">
            <h2>Ծրագրային էջեր</h2>
            <p>Այստեղ admin-ից ընտրում ես որ էջերը աշխատեն որպես ծրագրային էջեր։ Անջատելու դեպքում տվյալ էջի վրա manifest/app shell/PWA behavior-ը չի միանա, նույնիսկ եթե էջը բացվում է ծրագրից։</p>

            <div class="page-app-grid">
              <?php foreach ($pageAppRegistry as $pageKey => $pageMeta): ?>
                <?php $pageEnabled = !empty(($config['page_app_modes'] ?? [])[$pageKey]); ?>
                <label class="page-app-card">
                  <div class="page-app-copy">
                    <strong><?= htmlspecialchars((string)($pageMeta['label'] ?? $pageKey), ENT_QUOTES) ?></strong>
                    <span><?= htmlspecialchars((string)($pageMeta['description'] ?? ''), ENT_QUOTES) ?></span>
                    <code><?= htmlspecialchars((string)($pageMeta['path'] ?? ''), ENT_QUOTES) ?></code>
                  </div>
                  <span class="switch">
                    <input type="checkbox" name="page_app_modes[<?= htmlspecialchars($pageKey, ENT_QUOTES) ?>]" value="1" <?= $pageEnabled ? 'checked' : '' ?>>
                    <span class="slider"></span>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>

            <div class="action-buttons" style="margin-top:14px">
              <button class="btn" type="submit" name="form_action" value="save_page_modes">Պահպանել ծրագրային էջերը</button>
            </div>
          </section>

          <section class="panel" data-admin-section="access all">
            <h2>Admin մուտքեր</h2>
            <p>Եթե DB-ում չկա role/is_admin, այստեղի email whitelist-ը կորոշի ով ունի admin access։ Մեկ email ամեն տողում։</p>
            <div class="field">
              <label for="admin_emails">Admin email-ներ</label>
              <textarea id="admin_emails" name="admin_emails"><?= htmlspecialchars($adminEmailsText, ENT_QUOTES) ?></textarea>
            </div>
          </section>

          <section class="panel" data-admin-section="access all">
            <h2>Նշումներ</h2>
            <p>Ներքին նշում է։ Պատմության մեջ նույնպես կերևա։</p>
            <div class="field">
              <label for="meta_note">Ներքին նշում</label>
              <textarea id="meta_note" name="meta_note"><?= htmlspecialchars((string)$config['meta_note'], ENT_QUOTES) ?></textarea>
            </div>

            <div class="action-buttons" style="margin-top:14px">
              <button class="btn" type="submit" name="form_action" value="save_access">Պահպանել մուտքերն ու նշումները</button>
            </div>
          </section>

          <section class="panel full" data-admin-section="release">
            <div class="action-panel">
              <div class="action-copy">
                <strong>Թարմացման գործողություններ</strong>
                <span>Ընտրիր կիրառման տարբերակը և սեղմիր մեկ հիմնական կոճակը։ Առանց ֆայլի կցման կփոխվեն միայն version/settings տվյալները, իսկ ֆայլի կցումով նաև սերվերի ֆայլերը։</span>
              </div>
              <div class="action-buttons">
                <button class="btn btn-primary" type="submit" name="form_action" value="apply_release">Կիրառել թարմացումը</button>
              </div>
            </div>
          </section>
        </div>
      </form>

      <form method="post" class="stack" data-section-container>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
        <div class="stats" data-admin-section="push devices all">
          <div class="stat">
            <strong><?= !empty($pushConfig['enabled']) ? 'ՄԻԱՑՎԱԾ' : 'ԱՆՋԱՏՎԱԾ' ?></strong>
            <span>Push ծանուցումների վիճակ</span>
          </div>
          <div class="stat">
            <strong><?= (int)($installStats['main']['known_count'] ?? 0) ?></strong>
            <span>Ծրագրի ընդհանուր ճանաչված տեղադրումներ</span>
          </div>
          <div class="stat">
            <strong><?= (int)($installStats['main']['count'] ?? 0) ?></strong>
            <span>Վերջին <?= (int)($installStats['window_days'] ?? 60) ?> օրում ակտիվ երևացած սարքեր</span>
          </div>
          <div class="stat">
            <strong><?= (int)($pushStats['subscriptions'] ?? 0) ?></strong>
            <span>Push միացրած սարքեր</span>
          </div>
          <div class="stat">
            <strong><?= htmlspecialchars($pushLastSentAt ?: '—', ENT_QUOTES) ?></strong>
            <span>Վերջին ուղարկումը</span>
          </div>
        </div>

        <section class="panel full" data-admin-section="push all">
          <h2>Push ծանուցումներ</h2>
          <p>Այս բաժնից կարող եք միացնել browser/app push ծանուցումները, տեսնել քանի սարք է բաժանորդագրված, և ուղարկել ձեռքով նորություն, թարմացում կամ հայտարարություն։ Push-ը հասնում է բոլոր այն տեղադրված ծրագրերին, որոնք թույլ են տվել ծանուցումները։ <code>Ծրագրի ընդհանուր ճանաչված տեղադրումներ</code> թիվը կայուն ընդհանուր հաշվիչն է, իսկ <code>վերջին <?= (int)($installStats['window_days'] ?? 60) ?> օրում ակտիվ երևացած սարքեր</code>-ը ժամանակավոր activity հաշվիչն է և կարող է պակասել, եթե ծրագիրը երկար ժամանակ չի բացվել օնլայն։</p>

          <div class="switch-row">
            <div class="switch-copy">
              <strong>Միացնել push ծանուցումները</strong>
              <span><?= !empty($pushConfig['supported']) ? 'Եթե սա ակտիվ է, կայքի և ծրագրի user-ները կարող են բաժանորդագրվել push ծանուցումներին։' : 'Սերվերի վրա OpenSSL աջակցություն չկա, դրա համար push notifications-ը չի կարող ամբողջությամբ աշխատել։' ?></span>
            </div>
            <label class="switch" for="push_enabled">
              <input id="push_enabled" name="push_enabled" type="checkbox" <?= !empty($pushConfig['enabled']) ? 'checked' : '' ?> <?= empty($pushConfig['supported']) ? 'disabled' : '' ?>>
              <span class="slider"></span>
            </label>
          </div>

          <div class="row-2">
            <div class="field">
              <label for="push_subject">Կապի հասցե (VAPID subject)</label>
              <input id="push_subject" name="push_subject" value="<?= htmlspecialchars((string)($pushConfig['vapid_subject'] ?? ''), ENT_QUOTES) ?>" placeholder="mailto:admin@example.com">
            </div>
            <div class="field">
              <label for="push_public_key_preview">Հանրային բանալի</label>
              <input id="push_public_key_preview" value="<?= htmlspecialchars((string)($pushConfig['vapid_public_key'] ?? ''), ENT_QUOTES) ?>" readonly>
            </div>
          </div>

          <div class="action-buttons" style="margin-top:14px">
            <button class="btn" type="submit" name="form_action" value="save_push_settings" formnovalidate>Պահպանել push կարգավորումները</button>
          </div>
        </section>

        <section class="panel full" data-admin-section="devices all">
          <div class="history-head">
            <div>
              <h2>Ծրագրի ակտիվ սարքեր</h2>
              <p>Այս բաժնում երևում են ինչպես հիմնական ծրագրի, այնպես էլ admin ծրագրի ակտիվ սարքերը։ Տվյալները թարմացվում են, երբ տեղադրված ծրագիրը օնլայն բացվում է և install հաշվիչին activity է ուղարկում։</p>
            </div>
          </div>

          <div class="stats" style="margin-top:16px">
            <div class="stat">
              <strong><?= (int)($installStats['main']['count'] ?? 0) ?></strong>
              <span>Հիմնական ծրագիր ակտիվ սարքեր (<?= (int)($installStats['window_days'] ?? 60) ?> օր)</span>
            </div>
            <div class="stat">
              <strong><?= (int)($installStats['main']['known_count'] ?? 0) ?></strong>
              <span>Հիմնական ծրագիր ընդհանուր ճանաչված</span>
            </div>
            <div class="stat">
              <strong><?= (int)($installStats['admin']['count'] ?? 0) ?></strong>
              <span>Ադմին ծրագիր ակտիվ սարքեր (<?= (int)($installStats['window_days'] ?? 60) ?> օր)</span>
            </div>
            <div class="stat">
              <strong><?= (int)($installStats['admin']['known_count'] ?? 0) ?></strong>
              <span>Ադմին ծրագիր ընդհանուր ճանաչված</span>
            </div>
            <div class="stat">
              <strong><?= htmlspecialchars(wp_version_format_datetime_admin((string)($installStats['main']['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></strong>
              <span>Վերջին ակտիվություն` հիմնական</span>
            </div>
            <div class="stat">
              <strong><?= htmlspecialchars(wp_version_format_datetime_admin((string)($installStats['admin']['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></strong>
              <span>Վերջին ակտիվություն` ադմին</span>
            </div>
          </div>

          <div class="history-head" style="margin-top:18px">
            <div>
              <h2>Հիմնական ծրագրի սարքեր</h2>
              <p>Վերջին <?= (int)($installStats['window_days'] ?? 60) ?> օրում օնլայն երևացած հիմնական ծրագրի սարքերը։</p>
            </div>
          </div>

          <?php if (!$activeMainInstallDevices): ?>
            <div class="history-item">
              <div class="history-title">Հիմնական ծրագրի ակտիվ սարքեր դեռ չկան</div>
              <div class="note">Երբ user-ը տեղադրված հիմնական ծրագիրը օնլայն բացի, սարքը կհայտնվի այստեղ։</div>
            </div>
          <?php else: ?>
            <div class="device-list">
              <?php foreach ($activeMainInstallDevices as $device): ?>
                <div class="device-card">
                  <div class="device-header">
                    <div class="device-identity">
                      <div class="device-title"><?= htmlspecialchars(wp_admin_updates_install_identity($device), ENT_QUOTES) ?></div>
                      <div class="device-subtitle"><?= htmlspecialchars(wp_admin_updates_install_secondary($device), ENT_QUOTES) ?></div>
                      <div class="history-time">Վերջին ակտիվությունը <?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    </div>
                    <div class="device-actions">
                      <div class="chip <?= !empty($device['user_id']) || !empty($device['user_name']) || !empty($device['user_username']) || !empty($device['user_email']) ? 'success' : 'warning' ?>"><?= htmlspecialchars(wp_admin_updates_install_link_status($device), ENT_QUOTES) ?></div>
                      <form method="post" style="margin:0" onsubmit="return window.confirm('Վստա՞հ եք, որ ուզում եք մաքրել այս սարքի տվյալը։');">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
                        <input type="hidden" name="form_action" value="remove_install_device">
                        <input type="hidden" name="install_scope" value="main">
                        <input type="hidden" name="install_device_id" value="<?= htmlspecialchars((string)($device['device_id'] ?? ''), ENT_QUOTES) ?>">
                        <input type="hidden" name="install_device_signature" value="<?= htmlspecialchars((string)($device['device_signature'] ?? ''), ENT_QUOTES) ?>">
                        <button class="history-btn danger" type="submit">Մաքրել տվյալը</button>
                      </form>
                    </div>
                  </div>

                  <div class="chips">
                      <?php if (!empty($device['user_id'])): ?>
                        <div class="chip">Օգտատեր #<?= (int)$device['user_id'] ?></div>
                      <?php endif; ?>
                      <?php if (!empty($device['user_username'])): ?>
                        <div class="chip">@<?= htmlspecialchars((string)$device['user_username'], ENT_QUOTES) ?></div>
                      <?php endif; ?>
                      <?php if (!empty($device['user_email'])): ?>
                        <div class="chip">Email <?= htmlspecialchars((string)$device['user_email'], ENT_QUOTES) ?></div>
                      <?php endif; ?>
                  </div>

                  <div class="device-meta-grid">
                    <div class="device-meta"><strong>Սարքի ID</strong><span><?= htmlspecialchars(wp_install_mask_device_id((string)($device['device_id'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>IP հասցե</strong><span><?= htmlspecialchars(wp_admin_updates_install_ip($device), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Աղբյուր</strong><span><?= htmlspecialchars((string)($device['source'] ?? '—'), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Հարթակ</strong><span><?= htmlspecialchars(wp_admin_updates_install_platform((string)($device['user_agent'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Browser</strong><span><?= htmlspecialchars(wp_admin_updates_install_browser((string)($device['user_agent'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Առաջին գրանցում</strong><span><?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['installed_at'] ?? '')) ?: '—', ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Վերջին կապ</strong><span><?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></span></div>
                  </div>

                  <?php if (!empty($device['user_agent'])): ?>
                    <div class="note" style="margin-top:10px;word-break:break-word"><?= htmlspecialchars((string)$device['user_agent'], ENT_QUOTES) ?></div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div class="history-head" style="margin-top:18px">
            <div>
              <h2>Ադմին ծրագրի սարքեր</h2>
              <p>Այստեղ երևում են admin panel-ը որպես առանձին ծրագիր բացող ակտիվ սարքերը։</p>
            </div>
          </div>

          <?php if (!$activeAdminInstallDevices): ?>
            <div class="history-item">
              <div class="history-title">Ադմին ծրագրի ակտիվ սարքեր դեռ չկան</div>
              <div class="note">Երբ admin ծրագիրը առանձին PWA-ով օնլայն բացվի, սարքը կհայտնվի այստեղ։</div>
            </div>
          <?php else: ?>
            <div class="device-list">
              <?php foreach ($activeAdminInstallDevices as $device): ?>
                <div class="device-card">
                  <div class="device-header">
                    <div class="device-identity">
                      <div class="device-title"><?= htmlspecialchars(wp_admin_updates_install_identity($device), ENT_QUOTES) ?></div>
                      <div class="device-subtitle"><?= htmlspecialchars(wp_admin_updates_install_secondary($device), ENT_QUOTES) ?></div>
                      <div class="history-time">Վերջին ակտիվությունը <?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    </div>
                    <div class="device-actions">
                      <div class="chip <?= !empty($device['user_id']) || !empty($device['user_name']) || !empty($device['user_username']) || !empty($device['user_email']) ? 'success' : 'warning' ?>"><?= htmlspecialchars(wp_admin_updates_install_link_status($device), ENT_QUOTES) ?></div>
                      <form method="post" style="margin:0" onsubmit="return window.confirm('Վստա՞հ եք, որ ուզում եք մաքրել այս սարքի տվյալը։');">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
                        <input type="hidden" name="form_action" value="remove_install_device">
                        <input type="hidden" name="install_scope" value="admin">
                        <input type="hidden" name="install_device_id" value="<?= htmlspecialchars((string)($device['device_id'] ?? ''), ENT_QUOTES) ?>">
                        <input type="hidden" name="install_device_signature" value="<?= htmlspecialchars((string)($device['device_signature'] ?? ''), ENT_QUOTES) ?>">
                        <button class="history-btn danger" type="submit">Մաքրել տվյալը</button>
                      </form>
                    </div>
                  </div>

                  <div class="chips">
                      <?php if (!empty($device['user_id'])): ?>
                        <div class="chip">Օգտատեր #<?= (int)$device['user_id'] ?></div>
                      <?php endif; ?>
                      <?php if (!empty($device['user_username'])): ?>
                        <div class="chip">@<?= htmlspecialchars((string)$device['user_username'], ENT_QUOTES) ?></div>
                      <?php endif; ?>
                      <?php if (!empty($device['user_email'])): ?>
                        <div class="chip">Email <?= htmlspecialchars((string)$device['user_email'], ENT_QUOTES) ?></div>
                      <?php endif; ?>
                  </div>

                  <div class="device-meta-grid">
                    <div class="device-meta"><strong>Սարքի ID</strong><span><?= htmlspecialchars(wp_install_mask_device_id((string)($device['device_id'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>IP հասցե</strong><span><?= htmlspecialchars(wp_admin_updates_install_ip($device), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Աղբյուր</strong><span><?= htmlspecialchars((string)($device['source'] ?? '—'), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Հարթակ</strong><span><?= htmlspecialchars(wp_admin_updates_install_platform((string)($device['user_agent'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Browser</strong><span><?= htmlspecialchars(wp_admin_updates_install_browser((string)($device['user_agent'] ?? '')), ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Առաջին գրանցում</strong><span><?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['installed_at'] ?? '')) ?: '—', ENT_QUOTES) ?></span></div>
                    <div class="device-meta"><strong>Վերջին կապ</strong><span><?= htmlspecialchars(wp_version_format_datetime_admin((string)($device['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></span></div>
                  </div>

                  <?php if (!empty($device['user_agent'])): ?>
                    <div class="note" style="margin-top:10px;word-break:break-word"><?= htmlspecialchars((string)$device['user_agent'], ENT_QUOTES) ?></div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </section>

        <section class="panel full" data-admin-section="push all">
          <h2>Ուղարկել Push ծանուցում</h2>
          <p>Այս գործողությունը հերթագրում է ծանուցումը բոլոր բաժանորդագրված սարքերի համար և անմիջապես ուղարկում է push signal-ը, որպեսզի notification-ը երևա user-ի սարքում։</p>

          <div class="row-2">
            <div class="field">
              <label for="push_title">Վերնագիր</label>
              <input id="push_title" name="push_title" maxlength="160" value="Worship Platform" required>
            </div>
            <div class="field">
              <label for="push_tag">Խումբ (tag)</label>
              <input id="push_tag" name="push_tag" maxlength="120" value="worship-update">
            </div>
          </div>

          <div class="field">
            <label for="push_body">Բովանդակություն</label>
            <textarea id="push_body" name="push_body" required>Նոր թարմացում կամ հայտարարություն կա։ Բացեք Worship Platform-ը մանրամասների համար։</textarea>
          </div>

          <div class="row-2">
            <div class="field">
              <label for="push_url">Բացվող հղում</label>
              <input id="push_url" name="push_url" value="/main.html" placeholder="/main.html">
            </div>
            <div class="field">
              <label for="push_icon">Նշան (icon)</label>
              <input id="push_icon" name="push_icon" value="/wolarm_youth.png" placeholder="/wolarm_youth.png">
            </div>
          </div>

          <div class="action-buttons" style="margin-top:14px">
            <button class="btn btn-primary" type="submit" name="form_action" value="send_push" <?= empty($pushConfig['supported']) ? 'disabled' : '' ?>>Ուղարկել Push ծանուցումը</button>
          </div>
        </section>

        <section class="panel full" data-admin-section="push all">
            <div class="history-head">
            <div>
              <h2>Push միացրած սարքերի տվյալներ</h2>
              <p>Այստեղ երևում են բաժանորդագրված սարքերի տվյալները` օգտահաշիվը, IP-ն, browser/device signature-ը, endpoint host-ը և վերջին ակտիվությունը։</p>
            </div>
          </div>

          <?php if (!$pushSubscriptions): ?>
            <div class="history-item">
              <div class="history-title">Բաժանորդագրված սարքեր դեռ չկան</div>
              <div class="note">Երբ user-ը միացնի push ծանուցումները, նրա սարքը կհայտնվի այստեղ։</div>
            </div>
          <?php else: ?>
            <div class="history-list">
              <?php foreach ($pushSubscriptions as $subscription): ?>
                <div class="history-item">
                  <div class="history-top">
                    <div>
                      <div class="history-title"><?= htmlspecialchars(wp_admin_updates_push_identity($subscription), ENT_QUOTES) ?></div>
                      <div class="history-time">Գրանցվել է <?= htmlspecialchars(wp_version_format_datetime_admin((string)($subscription['created_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end;">
                      <div class="chip">ID <?= htmlspecialchars(substr((string)($subscription['id'] ?? ''), 0, 12) ?: '—', ENT_QUOTES) ?></div>
                      <button
                        class="history-btn danger"
                        type="submit"
                        name="form_action"
                        value="remove_push_subscription:<?= htmlspecialchars((string)($subscription['id'] ?? ''), ENT_QUOTES) ?>"
                        onclick="return confirm('Վստա՞հ եք, որ ուզում եք հեռացնել այս push սարքը։');"
                      >Հեռացնել</button>
                    </div>
                  </div>

                  <div class="chips">
                    <div class="chip">Endpoint <?= htmlspecialchars(wp_admin_updates_push_endpoint_host((string)($subscription['endpoint'] ?? '')), ENT_QUOTES) ?></div>
                    <div class="chip">IP <?= htmlspecialchars(wp_admin_updates_push_ip($subscription), ENT_QUOTES) ?></div>
                    <div class="chip">Վերջին կապ <?= htmlspecialchars(wp_version_format_datetime_admin((string)($subscription['last_seen_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    <div class="chip">Թարմացվել է <?= htmlspecialchars(wp_version_format_datetime_admin((string)($subscription['updated_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    <?php if (!empty($subscription['user_id'])): ?>
                      <div class="chip">User ID <?= (int)$subscription['user_id'] ?></div>
                    <?php endif; ?>
                  </div>

                  <?php if (!empty($subscription['user_agent'])): ?>
                    <div class="note"><?= htmlspecialchars((string)$subscription['user_agent'], ENT_QUOTES) ?></div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </section>

        <section class="panel full" data-admin-section="push all">
          <div class="history-head">
            <div>
              <h2>Push հաղորդագրությունների պատմություն</h2>
              <p>Այստեղ պահվում են վերջին ուղարկված push հաղորդագրությունները, ուղարկող ադմինը և ուղարկման արդյունքը ըստ սարքերի։</p>
            </div>
            <?php if ($pushHistory): ?>
              <button
                class="history-btn"
                type="submit"
                name="form_action"
                value="clear_push_history"
                onclick="return confirm('Վստա՞հ եք, որ ուզում եք ամբողջությամբ ջնջել push պատմությունը։');"
              >Մաքրել push պատմությունը</button>
            <?php endif; ?>
          </div>

          <?php if (!$pushHistory): ?>
            <div class="history-item">
              <div class="history-title">Push պատմություն դեռ չկա</div>
              <div class="note">Առաջին ուղարկումից հետո այստեղ կտեսնեք ուղարկված հաղորդագրությունները և դրանց արդյունքը։</div>
            </div>
          <?php else: ?>
            <div class="history-list" id="pushHistoryList">
              <?php foreach ($pushHistory as $item): ?>
                <div class="history-item" data-push-history-item>
                  <div class="history-top">
                    <div>
                      <div class="history-title"><?= htmlspecialchars((string)($item['title'] ?? 'Push հաղորդագրություն'), ENT_QUOTES) ?></div>
                      <div class="history-time"><?= htmlspecialchars(wp_version_format_datetime_admin((string)($item['created_at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    </div>
                    <div class="chip">Ուղարկել է <?= htmlspecialchars((string)($item['actor'] ?? 'admin'), ENT_QUOTES) ?></div>
                  </div>

                  <div class="chips">
                    <div class="chip">Հերթագրվել է <?= (int)($item['queued'] ?? 0) ?></div>
                    <div class="chip">Հասել է <?= (int)($item['success'] ?? 0) ?></div>
                    <div class="chip">Ձախողվել է <?= (int)($item['failed'] ?? 0) ?></div>
                    <?php if (!empty($item['removed'])): ?>
                      <div class="chip">Հեռացվել է <?= (int)$item['removed'] ?></div>
                    <?php endif; ?>
                    <?php if (!empty($item['tag'])): ?>
                      <div class="chip">Tag <?= htmlspecialchars((string)$item['tag'], ENT_QUOTES) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($item['url'])): ?>
                      <div class="chip">Հղում <?= htmlspecialchars((string)$item['url'], ENT_QUOTES) ?></div>
                    <?php endif; ?>
                  </div>

                  <?php if (!empty($item['body'])): ?>
                    <div class="note"><?= htmlspecialchars((string)$item['body'], ENT_QUOTES) ?></div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
            <?php if (count($pushHistory) > 5): ?>
              <div class="history-more">
                <button class="history-btn" id="loadMorePushHistoryBtn" type="button">Բեռնել ևս 5-ը</button>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </section>
      </form>

      <aside class="stack" data-section-container>
        <section class="panel" data-admin-section="history all">
          <div class="history-head">
            <div>
              <h2>Թարմացումների պատմություն</h2>
          <p>Այստեղ պահվում են միայն իրական փոփոխությունները` ամբողջ snapshot-ով, որպեսզի հետո հնարավոր լինի վերականգնել ցանկացած տարբերակ մեկ սեղմումով։</p>
            </div>
            <?php if ($history): ?>
              <form method="post" onsubmit="return confirm('Վստա՞հ եք, որ ուզում եք ամբողջությամբ ջնջել update history-ը։');">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
                <input type="hidden" name="form_action" value="clear_history">
                <button class="history-btn" type="submit">Ջնջել ամբողջ պատմությունը</button>
              </form>
            <?php endif; ?>
          </div>

          <?php if (!$history): ?>
            <div class="history-item">
              <div class="history-title">Պատմություն դեռ չկա</div>
              <div class="note">Առաջին save-ից հետո այստեղ կտեսնեք ով, երբ և ինչ է փոխել։</div>
            </div>
          <?php else: ?>
            <div class="history-list" id="historyList">
              <?php foreach ($history as $item): ?>
                <div class="history-item" data-history-item>
                  <div class="history-top">
                    <div>
                      <div class="history-title"><?= htmlspecialchars((string)($item['actor'] ?? 'admin'), ENT_QUOTES) ?> · <?= htmlspecialchars(wp_admin_updates_history_action_label((string)($item['action'] ?? 'save')), ENT_QUOTES) ?></div>
                      <div class="history-time"><?= htmlspecialchars(wp_version_format_datetime_admin((string)($item['at'] ?? '')) ?: '—', ENT_QUOTES) ?></div>
                    </div>
                    <div class="chip"><?= !empty($item['snapshot']['maintenance_enabled']) ? 'Ձեռքով միացված է' : 'Ձեռքով անջատված է' ?></div>
                  </div>

                  <div class="chips">
                    <div class="chip">App <?= htmlspecialchars((string)($item['snapshot']['app_version'] ?? '—'), ENT_QUOTES) ?></div>
                    <div class="chip">Web <?= htmlspecialchars((string)($item['snapshot']['web_version'] ?? '—'), ENT_QUOTES) ?></div>
                    <div class="chip">App Type <?= htmlspecialchars(wp_version_release_label((string)($item['snapshot']['app_release_type'] ?? 'feature')), ENT_QUOTES) ?></div>
                    <div class="chip">Web Type <?= htmlspecialchars(wp_version_release_label((string)($item['snapshot']['web_release_type'] ?? 'content')), ENT_QUOTES) ?></div>
                    <?php if (!empty($item['snapshot']['server_package_file'])): ?>
                      <div class="chip">Փաթեթ <?= htmlspecialchars((string)$item['snapshot']['server_package_file'], ENT_QUOTES) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($item['snapshot']['server_package_linked_app_version']) || !empty($item['snapshot']['server_package_linked_web_version'])): ?>
                      <div class="chip">
                        Կապված <?= htmlspecialchars((string)($item['snapshot']['server_package_linked_app_version'] ?? '—'), ENT_QUOTES) ?>/<?= htmlspecialchars((string)($item['snapshot']['server_package_linked_web_version'] ?? '—'), ENT_QUOTES) ?>
                      </div>
                    <?php endif; ?>
                    <?php if (!empty($item['ip'])): ?>
                      <div class="chip">IP <?= htmlspecialchars((string)$item['ip'], ENT_QUOTES) ?></div>
                    <?php endif; ?>
                  </div>

                  <?php if (!empty($item['snapshot']['app_release_summary']) || !empty($item['snapshot']['web_release_summary'])): ?>
                    <div class="note"><?=
                      htmlspecialchars(
                        trim(
                          'App: ' . ((string)($item['snapshot']['app_release_summary'] ?? '') ?: '—') .
                          "\n" .
                          'Web: ' . ((string)($item['snapshot']['web_release_summary'] ?? '') ?: '—')
                        ),
                        ENT_QUOTES
                      )
                    ?></div>
                  <?php endif; ?>

                  <?php if (!empty($item['changed_fields']) && is_array($item['changed_fields'])): ?>
                    <div class="chips">
                      <?php foreach ($item['changed_fields'] as $field): ?>
                        <div class="chip"><?= htmlspecialchars((string)$field, ENT_QUOTES) ?></div>
                      <?php endforeach; ?>
                    </div>
                  <?php endif; ?>

                  <?php if (!empty($item['note'])): ?>
                    <div class="note"><?= htmlspecialchars((string)$item['note'], ENT_QUOTES) ?></div>
                  <?php endif; ?>

                  <?php if (!empty($item['snapshot']) && is_array($item['snapshot'])): ?>
                    <div class="history-actions">
                      <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES) ?>">
                        <input type="hidden" name="form_action" value="rollback">
                        <input type="hidden" name="history_id" value="<?= htmlspecialchars((string)($item['id'] ?? ''), ENT_QUOTES) ?>">
                        <button class="history-btn" type="submit">Rollback այս տարբերակին</button>
                      </form>
                    </div>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
            <?php if (count($history) > 5): ?>
              <div class="history-more">
                <button class="history-btn" id="loadMoreHistoryBtn" type="button">Բեռնել ևս 5-ը</button>
              </div>
            <?php endif; ?>
          <?php endif; ?>
        </section>

        <section class="panel" data-admin-section="access all">
          <h2>Ադմին session</h2>
          <p>Այս էջը բացվել է նոր admin login հարթակով։ Access-ը ստուգվում է user login + <code>role/is_admin</code> կամ admin email whitelist-ով, և նույն login/logout հոսքն է կիսում <code>/songs.php</code>-ի հետ։</p>
          <div class="chips">
            <div class="chip"><?= $accessMode === 'modern' ? 'Դերային մուտք' : 'Admin մուտք' ?></div>
            <div class="chip">Օգտատեր <?= htmlspecialchars((string)($adminUser['name'] ?? 'Օգտատեր'), ENT_QUOTES) ?></div>
            <div class="chip">Ծրագիր <?= (int)($installStats['main']['known_count'] ?? 0) ?></div>
            <div class="chip">Ակտիվ <?= (int)($installStats['main']['count'] ?? 0) ?></div>
            <div class="chip">Ադմին ծրագիր <?= (int)($installStats['admin']['known_count'] ?? 0) ?></div>
            <?php if (!empty($adminUser['email'])): ?>
              <div class="chip"><?= htmlspecialchars((string)$adminUser['email'], ENT_QUOTES) ?></div>
            <?php endif; ?>
          </div>
        </section>
      </aside>
    </div>
  </main>
  <script>
    (function(){
      const appVersionInput = document.getElementById('app_version');
      const webVersionInput = document.getElementById('web_version');
      const appReleaseTypeInput = document.getElementById('app_release_type');
      const webReleaseTypeInput = document.getElementById('web_release_type');
      const appReleaseSummaryInput = document.getElementById('app_release_summary');
      const webReleaseSummaryInput = document.getElementById('web_release_summary');
      const appTitleInput = document.getElementById('app_title');
      const appMessageInput = document.getElementById('app_message');
      const webTitleInput = document.getElementById('web_title');
      const webMessageInput = document.getElementById('web_message');
      const maintenanceEnabledInput = document.getElementById('maintenance_enabled');
      const maintenanceStartInput = document.getElementById('maintenance_start_at');
      const maintenanceEndInput = document.getElementById('maintenance_end_at');
      const maintenanceMessageInput = document.getElementById('maintenance_message');
      const adminLayout = document.getElementById('adminLayout');
      const releaseControlForm = document.getElementById('releaseControlForm');
      const releaseApplyModeInput = document.getElementById('release_apply_mode');
      const packageModeInput = document.getElementById('server_package_mode');
      const packageFileInput = document.getElementById('server_package_file');
      const packageModeHelper = document.getElementById('packageModeHelper');
      const fillDefaultTextsBtn = document.getElementById('fillDefaultTextsBtn');
      const copyAppContentToWebBtn = document.getElementById('copyAppContentToWebBtn');
      const syncVersionsBtn = document.getElementById('syncVersionsBtn');
      const startMaintenanceNowBtn = document.getElementById('startMaintenanceNowBtn');
      const clearScheduleBtn = document.getElementById('clearScheduleBtn');
      const disableMaintenanceBtn = document.getElementById('disableMaintenanceBtn');
      const historyItems = Array.from(document.querySelectorAll('[data-history-item]'));
      const loadMoreHistoryBtn = document.getElementById('loadMoreHistoryBtn');
      const pushHistoryItems = Array.from(document.querySelectorAll('[data-push-history-item]'));
      const loadMorePushHistoryBtn = document.getElementById('loadMorePushHistoryBtn');
      const sectionTabs = Array.from(document.querySelectorAll('[data-section-tab]'));
      const sectionPanels = Array.from(document.querySelectorAll('[data-admin-section]'));
      const sectionContainers = Array.from(document.querySelectorAll('[data-section-container]'));
      const sectionStorageKey = 'worship-admin-updates-section';
      const devicesRefreshDelay = 15000;
      let devicesRefreshTimer = 0;
      const historyPageSize = 5;
      let visibleHistoryCount = historyPageSize;
      let visiblePushHistoryCount = historyPageSize;
      const releaseTypeLabels = {
        major: 'Մեծ թարմացում',
        feature: 'Նոր հնարավորություն',
        patch: 'Փոքր ուղղում',
        hotfix: 'Արագ շտկում',
        maintenance: 'Տեխնիկական թարմացում',
        content: 'Բովանդակության թարմացում'
      };

      function parseVersion(value) {
        const match = String(value || '').trim().match(/^(\d+)\.(\d+)\.(\d+)$/);
        if (!match) return [1, 0, 0];
        return [Number(match[1]), Number(match[2]), Number(match[3])];
      }

      function formatVersion(parts) {
        return parts.join('.');
      }

      function bumpVersion(value, kind) {
        const parts = parseVersion(value);
        if (kind === 'major') {
          parts[0] += 1;
          parts[1] = 0;
          parts[2] = 0;
        } else if (kind === 'minor') {
          parts[1] += 1;
          parts[2] = 0;
        } else {
          parts[2] += 1;
        }
        return formatVersion(parts);
      }

      function nowLocalDate() {
        return new Date();
      }

      function toDatetimeLocal(date) {
        const pad = (n) => String(n).padStart(2, '0');
        return [
          date.getFullYear(),
          '-',
          pad(date.getMonth() + 1),
          '-',
          pad(date.getDate()),
          'T',
          pad(date.getHours()),
          ':',
          pad(date.getMinutes())
        ].join('');
      }

      function ensureDefaultUpdateTexts() {
        const appTypeLabel = releaseTypeLabels[appReleaseTypeInput.value] || 'Ծրագրի թարմացում';
        const webTypeLabel = releaseTypeLabels[webReleaseTypeInput.value] || 'Կայքի թարմացում';
        const appVersion = appVersionInput.value.trim() || '1.0.0';
        const webVersion = webVersionInput.value.trim() || '1.0.0';

        if (!appReleaseSummaryInput.value.trim()) {
          appReleaseSummaryInput.value = appTypeLabel + ' ' + appVersion + ' տարբերակի համար';
        }
        if (!webReleaseSummaryInput.value.trim()) {
          webReleaseSummaryInput.value = webTypeLabel + ' ' + webVersion + ' տարբերակի համար';
        }

        if (!appTitleInput.value.trim()) {
          appTitleInput.value = 'Ծրագրի ' + appTypeLabel;
        }
        if (!webTitleInput.value.trim()) {
          webTitleInput.value = 'Կայքի ' + webTypeLabel;
        }
        if (!appMessageInput.value.trim()) {
          appMessageInput.value = 'Հասանելի է ծրագրի ' + appTypeLabel + ' ' + appVersion + ' տարբերակը։ Սեղմեք թարմացնել, որպեսզի օֆֆլայն և օնլայն բովանդակությունը նորացվի։';
        }
        if (!webMessageInput.value.trim()) {
          webMessageInput.value = 'Հասանելի է կայքի ' + webTypeLabel + ' ' + webVersion + ' տարբերակը։ Սեղմեք թարմացնել, որպեսզի բացվի նոր տարբերակը։';
        }
      }

      function renderHistoryPage() {
        if (!historyItems.length) {
          return;
        }

        historyItems.forEach((item, index) => {
          item.hidden = index >= visibleHistoryCount;
        });

        if (loadMoreHistoryBtn) {
          const hasMore = visibleHistoryCount < historyItems.length;
          loadMoreHistoryBtn.hidden = !hasMore;
          if (hasMore) {
            loadMoreHistoryBtn.textContent = `Բեռնել ևս ${Math.min(historyPageSize, historyItems.length - visibleHistoryCount)}-ը`;
          }
        }
      }

      function renderPushHistoryPage() {
        if (!pushHistoryItems.length) {
          return;
        }

        pushHistoryItems.forEach((item, index) => {
          item.hidden = index >= visiblePushHistoryCount;
        });

        if (loadMorePushHistoryBtn) {
          const hasMore = visiblePushHistoryCount < pushHistoryItems.length;
          loadMorePushHistoryBtn.hidden = !hasMore;
          if (hasMore) {
            loadMorePushHistoryBtn.textContent = `Բեռնել ևս ${Math.min(historyPageSize, pushHistoryItems.length - visiblePushHistoryCount)}-ը`;
          }
        }
      }

      function renderPackageModeHelp() {
        if (!packageModeInput || !packageModeHelper || !releaseApplyModeInput) {
          return;
        }

        var applyMode = releaseApplyModeInput.value || 'without_file';
        var mode = packageModeInput.value;
        var withFile = applyMode === 'with_file';

        packageModeInput.disabled = !withFile;
        if (packageFileInput) {
          packageFileInput.disabled = !withFile;
        }

        if (!withFile) {
          packageModeHelper.textContent = 'Այս տարբերակում կպահպանվեն version/message/settings տվյալները առանց սերվերի ֆայլերի փոխարինման։ ZIP փաթեթ ընտրել պետք չէ։';
          return;
        }

        if (mode === 'full') {
          packageModeHelper.textContent = 'Ամբողջական փաթեթի ռեժիմը լավ է, երբ ZIP-ը ամբողջ release/build package-ն է։ Կիրառման պահին նոր ZIP չընտրելու դեպքում կօգտագործվի ընթացիկ փաթեթը։';
          return;
        }

        packageModeHelper.textContent = 'Մասամբ թարմացման ռեժիմը լավ է, երբ ուզում եք փոխել միայն կոնկրետ ֆայլեր, օրինակ `main.html`, `sw.js` կամ որևէ առանձին script։ Կիրառումը կօգտագործի ընտրված նոր ZIP-ը կամ արդեն ներբեռնված ընթացիկ փաթեթը։';
      }

      function panelMatchesSection(panel, section) {
        const value = String(panel.getAttribute('data-admin-section') || '').trim();
        if (!value) {
          return true;
        }

        const sections = value.split(/\s+/).filter(Boolean);
        return section === 'all' || sections.includes(section);
      }

      function setActiveSection(section) {
        if (section === 'deploy') {
          section = 'release';
        }

        const nextSection = sectionTabs.some((tab) => tab.getAttribute('data-section-tab') === section) ? section : 'release';

        sectionTabs.forEach((tab) => {
          const active = tab.getAttribute('data-section-tab') === nextSection;
          tab.classList.toggle('active', active);
          tab.setAttribute('aria-selected', active ? 'true' : 'false');
        });

        sectionPanels.forEach((panel) => {
          panel.hidden = !panelMatchesSection(panel, nextSection);
        });

        sectionContainers.forEach((container) => {
          const visiblePanels = Array.from(container.querySelectorAll('[data-admin-section]')).some((panel) => !panel.hidden);
          container.hidden = !visiblePanels;
        });

        if (adminLayout) {
          const visibleContainers = sectionContainers.filter((container) => !container.hidden).length;
          adminLayout.classList.toggle('layout-single', visibleContainers <= 1);
          adminLayout.classList.toggle('layout-focused', nextSection !== 'all');
        }

        try {
          window.localStorage.setItem(sectionStorageKey, nextSection);
        } catch (error) {
        }

        scheduleDevicesRefresh(nextSection);
      }

      function stopDevicesRefresh() {
        if (devicesRefreshTimer) {
          window.clearTimeout(devicesRefreshTimer);
          devicesRefreshTimer = 0;
        }
      }

      function scheduleDevicesRefresh(section) {
        stopDevicesRefresh();
        if (section !== 'devices' || document.hidden) {
          return;
        }

        devicesRefreshTimer = window.setTimeout(() => {
          const activeElement = document.activeElement;
          const tagName = activeElement && activeElement.tagName ? activeElement.tagName.toLowerCase() : '';
          const isEditable = tagName === 'input' || tagName === 'textarea' || (activeElement && activeElement.isContentEditable);
          if (!document.hidden && !isEditable) {
            window.location.reload();
            return;
          }
          scheduleDevicesRefresh('devices');
        }, devicesRefreshDelay);
      }

      document.querySelectorAll('[data-bump-target]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const target = btn.getAttribute('data-bump-target');
          const kind = btn.getAttribute('data-bump-kind') || 'patch';

          if (target === 'app' || target === 'both') {
            appVersionInput.value = bumpVersion(appVersionInput.value, kind);
            if (appReleaseTypeInput && (kind === 'patch' || kind === 'minor' || kind === 'major')) {
              appReleaseTypeInput.value = kind === 'major' ? 'major' : (kind === 'minor' ? 'feature' : 'patch');
            }
          }
          if (target === 'web' || target === 'both') {
            webVersionInput.value = bumpVersion(webVersionInput.value, kind);
            if (webReleaseTypeInput && (kind === 'patch' || kind === 'minor' || kind === 'major')) {
              webReleaseTypeInput.value = kind === 'major' ? 'major' : (kind === 'minor' ? 'content' : 'patch');
            }
          }
        });
      });

      syncVersionsBtn?.addEventListener('click', () => {
        const version = appVersionInput.value.trim() || webVersionInput.value.trim() || '1.0.0';
        appVersionInput.value = version;
        webVersionInput.value = version;
        ensureDefaultUpdateTexts();
      });

      fillDefaultTextsBtn?.addEventListener('click', () => {
        ensureDefaultUpdateTexts();
      });

      copyAppContentToWebBtn?.addEventListener('click', () => {
        if (appVersionInput.value.trim() && !webVersionInput.value.trim()) {
          webVersionInput.value = appVersionInput.value.trim();
        }
        if (appReleaseTypeInput.value) {
          webReleaseTypeInput.value = appReleaseTypeInput.value;
        }
        if (appReleaseSummaryInput.value.trim()) {
          webReleaseSummaryInput.value = appReleaseSummaryInput.value.trim();
        }
        if (appTitleInput.value.trim()) {
          webTitleInput.value = appTitleInput.value.trim();
        }
        if (appMessageInput.value.trim()) {
          webMessageInput.value = appMessageInput.value.trim();
        }
      });

      document.querySelectorAll('[data-maintenance-hours]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const hours = Number(btn.getAttribute('data-maintenance-hours') || '0');
          const start = nowLocalDate();
          const end = new Date(start.getTime() + hours * 60 * 60 * 1000);

          maintenanceEnabledInput.checked = false;
          maintenanceStartInput.value = toDatetimeLocal(start);
          maintenanceEndInput.value = toDatetimeLocal(end);

          if (!maintenanceMessageInput.value.trim()) {
            maintenanceMessageInput.value = 'Կայքում ընթացքի մեջ են տեխնիկական աշխատանքներ։ Խնդրում ենք փորձել մի փոքր հետո։';
          }
        });
      });

      startMaintenanceNowBtn?.addEventListener('click', () => {
        maintenanceEnabledInput.checked = true;
        maintenanceStartInput.value = '';
        maintenanceEndInput.value = '';

        if (!maintenanceMessageInput.value.trim()) {
          maintenanceMessageInput.value = 'Կայքում ընթացքի մեջ են տեխնիկական աշխատանքներ։ Խնդրում ենք փորձել մի փոքր հետո։';
        }
      });

      clearScheduleBtn?.addEventListener('click', () => {
        maintenanceStartInput.value = '';
        maintenanceEndInput.value = '';
      });

      disableMaintenanceBtn?.addEventListener('click', () => {
        maintenanceEnabledInput.checked = false;
        maintenanceStartInput.value = '';
        maintenanceEndInput.value = '';
      });

      releaseApplyModeInput?.addEventListener('change', renderPackageModeHelp);
      packageModeInput?.addEventListener('change', renderPackageModeHelp);

      sectionTabs.forEach((tab) => {
        tab.addEventListener('click', () => {
          setActiveSection(tab.getAttribute('data-section-tab') || 'release');
        });
      });

      releaseControlForm?.addEventListener('submit', (event) => {
        const submitter = event.submitter;
        if (!submitter) {
          return;
        }

        const action = submitter.value || '';
        if (action === 'apply_release') {
          const applyMode = releaseApplyModeInput ? releaseApplyModeInput.value : 'without_file';
          if (applyMode !== 'with_file') {
            if (!window.confirm('Վստա՞հ եք, որ ուզում եք կիրառել թարմացումը առանց ֆայլի կցման։ Կփոխվեն միայն version/settings տվյալները։')) {
              event.preventDefault();
            }
            return;
          }

          const usingNewPackage = !!(packageFileInput && packageFileInput.files && packageFileInput.files.length > 0);
          const prompt = usingNewPackage
            ? 'Վստա՞հ եք, որ ուզում եք կիրառել թարմացումը և նոր ZIP package-ը տեղադրել սերվերի վրա։'
            : 'Վստա՞հ եք, որ ուզում եք կիրառել թարմացումը և արդեն առկա package-ը տեղադրել սերվերի վրա։';

          if (!window.confirm(prompt)) {
            event.preventDefault();
          }
          return;
        }
      });

      loadMoreHistoryBtn?.addEventListener('click', () => {
        visibleHistoryCount += historyPageSize;
        renderHistoryPage();
      });

      loadMorePushHistoryBtn?.addEventListener('click', () => {
        visiblePushHistoryCount += historyPageSize;
        renderPushHistoryPage();
      });

      window.addEventListener('focus', () => {
        const activeSection = sectionTabs.find((tab) => tab.classList.contains('active'))?.getAttribute('data-section-tab') || 'release';
        if (activeSection === 'devices') {
          window.location.reload();
        }
      });

      document.addEventListener('visibilitychange', () => {
        const activeSection = sectionTabs.find((tab) => tab.classList.contains('active'))?.getAttribute('data-section-tab') || 'release';
        if (document.hidden) {
          stopDevicesRefresh();
          return;
        }
        if (activeSection === 'devices') {
          window.location.reload();
        }
      });

      let initialSection = 'release';
      try {
        initialSection = window.localStorage.getItem(sectionStorageKey) || 'release';
      } catch (error) {
      }

      setActiveSection(initialSection);
      renderPackageModeHelp();
      renderHistoryPage();
      renderPushHistoryPage();
    })();
  </script>
</body>
</html>
